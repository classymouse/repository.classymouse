# -*- coding: utf-8 -*-
import sys
from resources.lib.router import Router

Router(sys.argv).run()
