# -*- coding: utf-8 -*-
"""
sourcesdialog.py — Source picker WindowXMLDialog

Usage:
    from resources.lib.sourcesdialog import SourcesDialog

    url = SourcesDialog.show(
        sources=[
            {'label': 'Streamtape', 'url': 'https://...', 'quality': '1080p'},
            {'label': 'Dood',       'url': 'https://...', 'quality': 'HD'},
            {'label': 'Magnet',     'url': 'magnet:?...',  'quality': ''},
        ],
        title='Movie Title',
        fanart='https://image.tmdb.org/...',   # optional
        poster='https://image.tmdb.org/...',   # optional
    )
    if url:
        # user picked a source → resolve and play

The dialog is a full-screen WindowXMLDialog with:
  - Fanart as blurred background (control 1)
  - Movie poster on the left    (control 3)
  - Movie title                 (control 4)
  - "N sources available"       (control 5)
  - Scrollable source list      (control 100)
  - Close button                (control 200)
"""
import os
import re

import xbmcgui

from resources.lib.log import log

# Paths used by WindowXMLDialog.__init__
_ADDON_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
)
_SKIN_NAME  = 'DefaultSkin'
_XML_NAME   = 'sources.xml'

# Kodi action IDs
_ACTION_BACK      = 10
_ACTION_PREV_MENU = 110
_ACTION_NAV_BACK  = 92
_ACTION_SELECT    = 7

# Rough quality-icon mapping (filename in media/ dir)
_QUALITY_ICONS = {
    '4k':    '4k.png',
    '2160':  '4k.png',
    '1080':  '1080p.png',
    '720':   '720.png',
    '480':   '480.png',
    '360':   '360.png',
    'hd':    'hd.png',
    'sd':    'sd.png',
}

_RE_QUALITY = re.compile(r'(4k|2160p?|1080p?|720p?|480p?|360p?)\b', re.IGNORECASE)


def _quality_icon(label, quality=''):
    """Return media-relative icon filename for the best quality hint found."""
    text = (label + ' ' + quality).lower()
    if '4k' in text or '2160' in text:
        return '4k.png'
    if '1080' in text:
        return '1080p.png'
    if '720' in text:
        return '720.png'
    if '480' in text:
        return '480.png'
    if '360' in text:
        return '360.png'
    if 'hd' in text:
        return 'hd.png'
    if 'sd' in text:
        return 'sd.png'
    return 'unk.png'


def _host_label(url):
    """Derive a friendly display label from a raw URL."""
    if url.lower().startswith('magnet:'):
        return 'Magnet (debrid)'
    try:
        from urllib.parse import urlparse
        host = urlparse(url).netloc.lower()
        # strip www. / subdomains and .com/.net/etc
        host = re.sub(r'^www\.', '', host)
        host = re.sub(r'\.[a-z]{2,6}$', '', host)
        return host.title() or url[:60]
    except Exception:
        return url[:60]


class SourcesDialog(xbmcgui.WindowXMLDialog):
    """Custom source-picker dialog."""

    def __init__(self, *args, **kwargs):
        self._sources  = kwargs.pop('sources',  [])
        self._title    = kwargs.pop('title',    'Select Source')
        self._fanart   = kwargs.pop('fanart',   '')
        self._poster   = kwargs.pop('poster',   '')
        self.selected  = None
        xbmcgui.WindowXMLDialog.__init__(self, *args, **kwargs)

    # ── Public factory ──────────────────────────────────────────────────

    @classmethod
    def show(cls, sources, title='', fanart='', poster=''):
        """
        Show the dialog and return the selected URL string, or None.

        `sources` is a list of dicts:
            {'label': str, 'url': str, 'quality': str (optional)}
        """
        if not sources:
            return None

        # Auto-label any source that has no label
        for s in sources:
            if not s.get('label'):
                s['label'] = _host_label(s['url'])

        try:
            dlg = cls(
                _XML_NAME, _ADDON_PATH, _SKIN_NAME,
                sources=sources,
                title=title,
                fanart=fanart,
                poster=poster,
            )
            dlg.doModal()
            return dlg.selected
        except Exception as e:
            log('SourcesDialog.show error: %s' % e, level='error')
            # Graceful fallback: plain select dialog
            return _fallback_select(sources, title)

    # ── WindowXMLDialog callbacks ────────────────────────────────────────

    def onInit(self):
        try:
            # Background fanart
            if self._fanart:
                self.getControl(1).setImage(self._fanart)

            # Movie poster
            if self._poster:
                self.getControl(3).setImage(self._poster)

            # Title label
            self.getControl(4).setLabel(self._title or 'Select Source')

            # Subtitle: source count
            n = len(self._sources)
            self.getControl(5).setLabel(
                '%d source%s available' % (n, 's' if n != 1 else '')
            )

            # Populate source list
            lst = self.getControl(100)
            lst.reset()

            media_dir = os.path.join(
                _ADDON_PATH, 'resources', 'skins', _SKIN_NAME, 'media'
            )

            for src in self._sources:
                label   = src.get('label') or _host_label(src['url'])
                quality = src.get('quality', '')
                icon_fn = _quality_icon(label, quality)
                icon    = os.path.join(media_dir, icon_fn)

                li = xbmcgui.ListItem(label, quality)
                li.setArt({'icon': icon, 'thumb': icon})
                li.setProperty('url', src['url'])
                lst.addItem(li)

            # Set initial focus to the list
            self.setFocus(lst)

        except Exception as e:
            log('SourcesDialog.onInit error: %s' % e, level='error')

    def onAction(self, action):
        aid = action.getId()
        if aid in (_ACTION_BACK, _ACTION_PREV_MENU, _ACTION_NAV_BACK):
            self.selected = None
            self.close()

    def onClick(self, control_id):
        if control_id == 100:
            try:
                lst = self.getControl(100)
                pos = lst.getSelectedPosition()
                self.selected = self._sources[pos]['url']
            except Exception as e:
                log('SourcesDialog.onClick error: %s' % e, level='error')
                self.selected = None
            self.close()
        elif control_id == 200:   # close button
            self.selected = None
            self.close()


# ── Fallback: plain Dialog().select() ───────────────────────────────────

def _fallback_select(sources, title=''):
    """Plain built-in select dialog used when WindowXMLDialog fails."""
    labels = [s.get('label') or _host_label(s['url']) for s in sources]
    idx = xbmcgui.Dialog().select(title or 'Select Source', labels)
    if idx < 0:
        return None
    return sources[idx]['url']
