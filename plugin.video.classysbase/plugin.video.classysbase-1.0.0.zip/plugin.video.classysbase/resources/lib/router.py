# -*- coding: utf-8 -*-
"""
URL router — the single entry point for every addon call.

Responsibilities:
  • Parse argv[2] into a params dict
  • Dispatch to the correct handler by mode=
  • Guarantee endOfDirectory is always called (try/finally)
  • Keep play and dev_panel outside that guarantee (they manage their own response)
"""
import sys
import traceback
from urllib.parse import parse_qsl

import xbmc
import xbmcplugin

from resources.lib.log import log


class Router:
    def __init__(self, argv):
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip('?')))

    def run(self):
        mode = self.params.get('mode', 'main')

        # ── modes that manage their own response ──────────────────────────────

        if mode == 'play':
            from resources.lib.player import play
            play(self.handle, self.params)
            return

        if mode == 'scrape':
            from resources.lib.player import scrape_and_play
            scrape_and_play(self.handle, self.params)
            return

        if mode == 'dev_panel':
            from resources.lib.keys import dev_panel
            dev_panel()
            return

        if mode == 'settings':
            import xbmcaddon
            xbmcaddon.Addon().openSettings()
            # settings is dialog-only; signal empty directory so Kodi doesn't error
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        # ── directory modes — endOfDirectory guaranteed via finally ───────────

        succeeded = True
        try:
            if mode == 'main':
                from resources.lib.menus import main_menu
                main_menu(self.handle)

            elif mode == 'jen':
                url = self.params.get('url', '')
                from resources.lib.parser import browse
                browse(self.handle, url)

            elif mode == 'tmdb':
                from resources.lib.tmdb import render as tmdb_render
                tmdb_render(self.handle, self.params)

            else:
                log('Unknown mode: %s' % mode, level='warning')
                succeeded = False

        except Exception:
            log(traceback.format_exc(), level='error')
            succeeded = False

        finally:
            xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded)
