# -*- coding: utf-8 -*-
import xbmcgui


def notify(msg, heading="Classy's Base", icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
    xbmcgui.Dialog().notification(heading, msg, icon, ms)


def ok(msg, heading="Classy's Base"):
    xbmcgui.Dialog().ok(heading, msg)
