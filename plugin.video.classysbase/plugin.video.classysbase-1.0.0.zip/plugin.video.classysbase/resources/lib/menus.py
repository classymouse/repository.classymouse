# -*- coding: utf-8 -*-
"""
Main menu — Chains' curated playlist endpoints.

Each entry points directly to one of his live .txt files on thechains24.com.
When Chains updates a file, users see the change immediately — no addon
update required.
"""
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.utils import build_url

_ADDON = xbmcaddon.Addon()
_ADDON_URL = sys.argv[0]
_SETTINGS_ICON = 'special://home/addons/plugin.video.classysbase/resources/artwork/settings.png'

# ── playlist catalogue ────────────────────────────────────────────────────────
# (display_name, playlist_url, thumb_url, fanart_url)
_PLAYLISTS = [
    (
        'One Click Media',
        'https://thechains24.com/ABSOLUTION/ONECLICK%20MAIN.txt',
        'https://thechains24.com/2/ONECLICK/icon.png',
        'https://thechains24.com/2/ONECLICK/fanart.png',
    ),
    (
        'Marvel & DC',
        'https://thechains24.com/MARVEL%20AND%20DC%20MAIN/MAIN%20DIR.txt',
        'https://thechains24.com/2/MARVEL%20DC/icon.png',
        'https://thechains24.com/2/MARVEL%20DC/fanart.png',
    ),
    (
        'Chain Reaction',
        'https://thechains24.com/ONE%20CLICK%20CHAINS/MAIN%20DIR.txt',
        'https://thechains24.com/2/CHAINS/icon.png',
        'https://thechains24.com/2/CHAINS/fanart.jpg',
    ),
    (
        'Kids Zone',
        'https://thechains24.com/broken%20chains/KIDS/kids%20main.txt',
        'https://thechains24.com/2/KIDSZONE/icon.png',
        'https://thechains24.com/2/KIDSZONE/Untitled.png',
    ),
    (
        'WWE',
        'https://thechains24.com/ABSOLUTION/NONE%20DEBRID/WWE/WWE%20MAIN.txt',
        'https://thechains24.com/2/WWE/icon.png',
        'https://thechains24.com/2/WWE/fanart.jpg',
    ),
    (
        'Killer Frequency',
        'https://thechains24.com/THE%20CRYPT/HORROR%20MAIN.txt',
        'https://thechains24.com/2/HORROR/icon.png',
        'https://thechains24.com/2/HORROR/fanart.jpg',
    ),
    (
        'Siren',
        'https://thechains24.com/SIREN/Siren%20TMDB%20lists.txt',
        'https://thechains24.com/2/CHAINS/siren.png',
        'https://thechains24.com/ART/MAIN/Sirenfanart.png',
    ),
    (
        'Retrowave',
        'https://thechains24.com/broken%20chains/RETROWAVE/MAIN%20DIR.txt',
        'https://thechains24.com/2/RETROWAVE/icon.png',
        'https://thechains24.com/2/RETROWAVE/fanart.png',
    ),
    (
        'Crimewave',
        'https://thechains24.com/CRIME%20LOCKER/CRIME%20VAULT.txt',
        'https://thechains24.com/2/TRUE%20CRIME/icon.png',
        'https://thechains24.com/2/TRUE%20CRIME/fanart.jpg',
    ),
    (
        'Science Fiction',
        'https://thechains24.com/SCIENCE%20FICTION/MAIN%20DIR.txt',
        'https://thechains24.com/2/SCI%20FI/icon.png',
        'https://thechains24.com/2/SCI%20FI/fanart.jpg',
    ),
]


def main_menu(handle):
    items = []

    for name, url, thumb, fanart in _PLAYLISTS:
        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': thumb, 'fanart': fanart})
        li.setInfo('video', {'title': name})
        items.append((build_url(_ADDON_URL, mode='jen', url=url), li, True))

    # Settings shortcut at the bottom
    li = xbmcgui.ListItem('[COLOR dimgray]Settings[/COLOR]')
    li.setArt({'thumb': _SETTINGS_ICON, 'icon': _SETTINGS_ICON})
    items.append((build_url(_ADDON_URL, mode='settings'), li, True))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.setContent(handle, 'files')
