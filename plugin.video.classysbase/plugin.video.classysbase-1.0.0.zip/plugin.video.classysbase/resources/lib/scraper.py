# -*- coding: utf-8 -*-
"""
scraper.py — External scraper module adapter
=============================================

Bridges Classy's Base with installed third-party scraper modules so that
TMDB movie items can be resolved to actual stream URLs.

Supported module families
-------------------------
Convention A  (top-level sources() function, identical API):
    script.module.gearsscrapers
    script.module.viperscrapers
    script.module.homelanderscrapers

Convention B  (CocoScrapers flat provider list):
    script.module.cocoscrapers

Each individual provider class exposes:
    source().sources(data, hostDict) → list of source dicts

Returned source dict keys of interest:
    url      — magnet: URI or direct stream URL
    quality  — '4K' | '1080p' | '720p' | 'SD' | 'CAM'
    provider — scraper name string
    seeders  — int (torrent sources)
"""

import sys
import os
import importlib
from threading import Thread, Lock

import xbmcaddon

from resources.lib.log import log

# ── Known scraper modules ──────────────────────────────────────────────────────

_SCRAPERS = {
    'script.module.gearsscrapers': {
        'label':      'GearScrapers',
        'pkg':        'gearsscrapers',
        'convention': 'A',
    },
    'script.module.viperscrapers': {
        'label':      'ViperScrapers',
        'pkg':        'viperscrapers',
        'convention': 'A',
    },
    'script.module.homelanderscrapers': {
        'label':      'HomelanderScrapers',
        'pkg':        'homelanderscrapers',
        'convention': 'A',
    },
    'script.module.cocoscrapers': {
        'label':      'CocoScrapers',
        'pkg':        'cocoscrapers',
        'convention': 'B',
    },
}

_QUALITY_RANK    = {'4K': 0, '2160p': 0, '1080p': 1, '720p': 2, 'SD': 3, 'CAM': 4}
_PROVIDER_TIMEOUT = 20   # seconds — per-module join timeout

# ── Public API ─────────────────────────────────────────────────────────────────

def detect_installed():
    """Return addon IDs of recognised scraper modules that are installed."""
    out = []
    for addon_id in _SCRAPERS:
        try:
            xbmcaddon.Addon(addon_id)
            out.append(addon_id)
        except Exception:
            pass
    return out


def scrape(title, year, media_type='movie', tmdb_id=None,
           addon_ids=None, progress_dialog=None):
    """
    Scrape stream sources for a movie using installed scraper modules.

    Parameters
    ----------
    title           : str
    year            : str or int
    media_type      : 'movie'  (TV scraping is future work)
    tmdb_id         : str or None
    addon_ids       : list of addon IDs to use, or None → all installed
    progress_dialog : xbmcgui.DialogProgress or None (for live progress updates)

    Returns
    -------
    list of {'label': str, 'url': str, 'quality': str}
        Sorted best quality first (4K → 1080p → 720p → SD).
        Empty list when nothing was found or no scrapers are active.
    """
    if addon_ids is None:
        addon_ids = detect_installed()

    if not addon_ids:
        log('scraper: no scraper modules active', level='warning')
        return []

    data = {
        'title':   str(title),
        'year':    str(year),
        'aliases': [str(title)],
    }

    all_raw = []
    lock    = Lock()
    total   = len(addon_ids)

    def _run(idx, addon_id):
        label = _SCRAPERS[addon_id]['label']
        if progress_dialog:
            progress_dialog.update(
                max(5, int(idx / total * 80)),
                'Searching: %s …' % label,
            )
        try:
            raw = _scrape_one(addon_id, data)
            if raw:
                with lock:
                    all_raw.extend(raw)
        except Exception as exc:
            log('scraper [%s] error: %s' % (addon_id, exc), level='warning')
        finally:
            if progress_dialog:
                progress_dialog.update(int((idx + 1) / total * 90))

    threads = [Thread(target=_run, args=(i, aid)) for i, aid in enumerate(addon_ids)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    if progress_dialog:
        progress_dialog.update(100, 'Done')

    return _normalise(all_raw)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _lib_path(addon_id):
    """Return the lib/ directory for a Kodi addon, or None."""
    try:
        path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
        lib  = os.path.join(path, 'lib')
        return lib if os.path.isdir(lib) else path
    except Exception:
        return None


def _ensure_path(lib_path):
    if lib_path and lib_path not in sys.path:
        sys.path.insert(0, lib_path)


def _scrape_one(addon_id, data):
    """Return raw source dicts from one scraper module.  Never raises."""
    info = _SCRAPERS.get(addon_id)
    if not info:
        return []

    lib_path = _lib_path(addon_id)
    if not lib_path:
        return []

    _ensure_path(lib_path)

    try:
        if info['convention'] == 'A':
            return _scrape_convention_a(info['pkg'], data)
        elif info['convention'] == 'B':
            return _scrape_convention_b(lib_path, data)
    except Exception as exc:
        log('_scrape_one [%s] error: %s' % (addon_id, exc), level='warning')

    return []


def _scrape_convention_a(pkg_name, data):
    """
    Convention A: call pkg.sources(ret_all=True) to get all providers as
    (name, class) tuples, then thread over each provider's sources(data, []).
    """
    try:
        pkg       = importlib.import_module(pkg_name)
        providers = pkg.sources(ret_all=True)
    except Exception as exc:
        log('convention-A import [%s]: %s' % (pkg_name, exc), level='warning')
        return []

    results = []
    lock    = Lock()

    def _run_provider(cls):
        try:
            raw = cls().sources(data, [])
            if raw:
                with lock:
                    results.extend(raw)
        except Exception:
            pass    # silent per-provider failures

    threads = [Thread(target=_run_provider, args=(cls,)) for _, cls in providers]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=_PROVIDER_TIMEOUT)

    return results


def _scrape_convention_b(lib_path, data):
    """
    Convention B: CocoScrapers — enumerate torrent providers from the
    all_providers list and import each one individually.
    """
    _ensure_path(lib_path)

    try:
        from cocoscrapers.sources_cocoscrapers import all_providers
    except Exception as exc:
        log('convention-B import (cocoscrapers): %s' % exc, level='warning')
        return []

    results = []
    lock    = Lock()

    def _run_provider(name):
        try:
            mod = importlib.import_module(
                'cocoscrapers.sources_cocoscrapers.torrents.' + name
            )
            raw = mod.source().sources(data, [])
            if raw:
                with lock:
                    results.extend(raw)
        except Exception:
            pass

    threads = [Thread(target=_run_provider, args=(n,)) for n in all_providers]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=_PROVIDER_TIMEOUT)

    return results


def _normalise(raw_sources):
    """
    Convert raw scraper dicts to uniform {'label', 'url', 'quality'} items.
    Deduplicates by URL and sorts by quality (best first).
    """
    out  = []
    seen = set()

    for r in raw_sources:
        url = r.get('url', '')
        if not url or url in seen:
            continue
        seen.add(url)

        quality  = r.get('quality', 'SD')
        provider = r.get('provider', '?')
        seeders  = r.get('seeders')
        label    = '[%s]  %s' % (quality, provider)
        if seeders:
            label += '  (%s seeds)' % seeders

        out.append({'label': label, 'url': url, 'quality': quality})

    out.sort(key=lambda x: _QUALITY_RANK.get(x['quality'], 99))
    return out
