# -*- coding: utf-8 -*-
"""
HTTP client — one session, modern User-Agent, clean error handling.
Uses script.module.requests (always available in Kodi 19+).
"""
import requests

_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:126.0) '
    'Gecko/20100101 Firefox/126.0'
)

_SESSION = requests.Session()
_SESSION.headers.update({
    'User-Agent':      _UA,
    'Accept':          'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Connection':      'keep-alive',
})


def get(url, **kwargs):
    """GET request. Returns response or None on failure."""
    kwargs.setdefault('timeout', 15)
    try:
        r = _SESSION.get(url, **kwargs)
        r.raise_for_status()
        return r
    except Exception as e:
        from resources.lib.log import log
        log('GET %s — %s' % (url, e), level='error')
        return None


def post(url, **kwargs):
    """POST request. Returns response or None on failure."""
    kwargs.setdefault('timeout', 15)
    try:
        r = _SESSION.post(url, **kwargs)
        r.raise_for_status()
        return r
    except Exception as e:
        from resources.lib.log import log
        log('POST %s — %s' % (url, e), level='error')
        return None
