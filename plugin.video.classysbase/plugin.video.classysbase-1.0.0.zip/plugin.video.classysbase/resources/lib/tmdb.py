# -*- coding: utf-8 -*-
"""
tmdb.py — The Movie Database (TMDB) API client
===============================================

Thin, well-documented wrapper around the TMDB v3 REST API.
All HTTP calls are cached via resources.lib.cache.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Quick-start
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Register a free account at https://www.themoviedb.org/
2. Go to  Settings → API → Create → Developer
3. Copy your *v3 API key* (the long hex string, NOT the v4 read token)
4. In Kodi: Classy's Base → Settings → TMDB → API Key → paste it

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supported Jen  <tmdb>  tag values
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  <tmdb>collection/{id}</tmdb>   →  all movies in a TMDB collection
  <tmdb>list/{id}</tmdb>         →  items in a custom TMDB list (mixed types)
  <tmdb>movie/{id}</tmdb>        →  single movie (detail page)
  <tmdb>tv/{id}</tmdb>           →  single TV show (detail page)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Returned item dict keys  (from all public functions)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  tmdb_id     int         TMDB numeric ID
  media_type  str         'movie' or 'tv'
  title       str         Display title
  year        str         4-digit year string, or ''
  plot        str         Overview / synopsis
  rating      float       Average vote (0.0–10.0)
  thumb       str         Full poster URL  (w342)
  fanart      str         Full backdrop URL (w780)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Error policy
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
All public functions return  None  (or empty list) on ANY error.
They never raise.  Errors are written to the Kodi log.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Cache lifetimes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Browse (collection / list)  :  6 hours
  Item detail (movie / tv)    :  24 hours
"""

import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.cache import get as cached
from resources.lib.client import get as http_get
from resources.lib.log import log
from resources.lib.utils import build_url

# ── API constants ──────────────────────────────────────────────────────────────

TMDB_BASE     = 'https://api.themoviedb.org/3'
IMAGE_BASE    = 'https://image.tmdb.org/t/p'

# Image size presets — use the smallest that still looks sharp
POSTER_SIZE   = 'w342'       # ~342 px wide  — thumbnail / list view
BACKDROP_SIZE = 'w780'       # ~780 px wide  — fanart / background

# Cache lifetimes (hours)
_CACHE_BROWSE = 6
_CACHE_ITEM   = 24

# ── Image helper ───────────────────────────────────────────────────────────────

def img_url(path, size=POSTER_SIZE):
    """
    Build a full TMDB image CDN URL from a relative path.

    Parameters
    ----------
    path : str
        Relative path as returned by the API, e.g. '/abc123.jpg'.
        Pass an empty string or None to get ''.
    size : str
        One of the TMDB image size constants, e.g. 'w342', 'w780',
        'original'.  Default: POSTER_SIZE ('w342').

    Returns
    -------
    str
        Full URL, e.g. 'https://image.tmdb.org/t/p/w342/abc123.jpg'
        or '' if path is falsy.

    Examples
    --------
    >>> img_url('/abc123.jpg')
    'https://image.tmdb.org/t/p/w342/abc123.jpg'
    >>> img_url('/abc123.jpg', size='original')
    'https://image.tmdb.org/t/p/original/abc123.jpg'
    >>> img_url('')
    ''
    """
    if not path:
        return ''
    return '%s/%s%s' % (IMAGE_BASE, size, path)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _api_key():
    """
    Read the TMDB v3 API key from addon settings.

    Returns empty string if the setting is missing or blank.
    The caller is responsible for checking and notifying the user.
    """
    return xbmcaddon.Addon().getSetting('tmdb_api_key').strip()


def _get(endpoint, extra_params=None):
    """
    Make an authenticated GET request to the TMDB v3 API.

    Parameters
    ----------
    endpoint : str
        Path relative to TMDB_BASE, e.g. '/collection/151'.
    extra_params : dict, optional
        Extra query parameters merged on top of api_key and language.

    Returns
    -------
    dict | None
        Parsed JSON response body, or None on any error.

    Notes
    -----
    - Returns None and logs a warning if no API key is configured.
    - Returns None and logs specific messages for 401 / 404 / other errors.
    - Does NOT raise; all exceptions are caught and logged.
    """
    key = _api_key()
    if not key:
        log('TMDB: no API key — open Settings and add your TMDB v3 key',
            level='warning')
        return None

    params = {'api_key': key, 'language': 'en-US'}
    if extra_params:
        params.update(extra_params)

    try:
        from urllib.parse import urlencode
        url = '%s%s?%s' % (TMDB_BASE, endpoint, urlencode(params))
    except Exception as e:
        log('TMDB: URL build error: %s' % e, level='error')
        return None

    response = http_get(url)
    if response is None:
        log('TMDB: network request failed for %s' % endpoint, level='error')
        return None

    if response.status_code == 401:
        log('TMDB: 401 Unauthorized — API key is wrong or expired. '
            'Update it in Settings.', level='error')
        xbmcgui.Dialog().notification(
            "Classy's Base",
            'TMDB: invalid API key — check Settings',
            xbmcgui.NOTIFICATION_ERROR, 6000
        )
        return None

    if response.status_code == 404:
        log('TMDB: 404 Not Found — %s' % endpoint, level='warning')
        return None

    if not response.ok:
        log('TMDB: HTTP %s for %s' % (response.status_code, endpoint),
            level='error')
        return None

    try:
        return response.json()
    except Exception as e:
        log('TMDB: JSON decode error for %s: %s' % (endpoint, e),
            level='error')
        return None


# ── Normalisation ─────────────────────────────────────────────────────────────

def _norm_movie(m):
    """
    Normalise a raw TMDB movie object to our flat item dict.

    Parameters
    ----------
    m : dict
        Raw movie object as returned by the TMDB API.

    Returns
    -------
    dict
        Keys: tmdb_id, media_type, title, year, plot, rating, thumb, fanart.
    """
    return {
        'tmdb_id':    m.get('id', ''),
        'media_type': 'movie',
        'title':      m.get('title') or m.get('original_title') or 'Unknown',
        'year':       (m.get('release_date') or '')[:4],
        'plot':       m.get('overview') or '',
        'rating':     float(m.get('vote_average') or 0.0),
        'thumb':      img_url(m.get('poster_path'),   POSTER_SIZE),
        'fanart':     img_url(m.get('backdrop_path'), BACKDROP_SIZE),
    }


def _norm_tv(t):
    """
    Normalise a raw TMDB TV show object to our flat item dict.

    Parameters
    ----------
    t : dict
        Raw TV show object as returned by the TMDB API.

    Returns
    -------
    dict
        Same keys as _norm_movie but media_type='tv'.
    """
    return {
        'tmdb_id':    t.get('id', ''),
        'media_type': 'tv',
        'title':      t.get('name') or t.get('original_name') or 'Unknown',
        'year':       (t.get('first_air_date') or '')[:4],
        'plot':       t.get('overview') or '',
        'rating':     float(t.get('vote_average') or 0.0),
        'thumb':      img_url(t.get('poster_path'),   POSTER_SIZE),
        'fanart':     img_url(t.get('backdrop_path'), BACKDROP_SIZE),
    }


def _norm_any(item):
    """
    Normalise a TMDB item that may be a movie or TV show.

    Checks the 'media_type' field, falling back to presence of 'name'
    (TV shows use 'name'; movies use 'title').
    """
    mt = item.get('media_type', '')
    if mt == 'tv' or (not mt and 'name' in item and 'title' not in item):
        return _norm_tv(item)
    return _norm_movie(item)


# ── Public API ─────────────────────────────────────────────────────────────────

def collection(collection_id):
    """
    Fetch all movies in a TMDB collection, sorted by release date.

    A 'collection' groups related movies (e.g. a film franchise).
    Example: collection 151 = "Star Trek: The Original Movies"

    Parameters
    ----------
    collection_id : int | str
        TMDB collection ID.

    Returns
    -------
    list[dict] | None
        Sorted list of normalised movie dicts, or None on error.
        Each dict has keys: tmdb_id, media_type, title, year,
        plot, rating, thumb, fanart.
    """
    data = _get('/collection/%s' % collection_id)
    if not data:
        return None
    movies = data.get('parts') or []
    movies.sort(key=lambda m: m.get('release_date') or '')
    return [_norm_movie(m) for m in movies]


def tmdb_list(list_id):
    """
    Fetch all items from a custom TMDB list.

    Custom lists can mix movies and TV shows.
    Example: list 8580589 = a Star Trek TV shows list.

    Parameters
    ----------
    list_id : int | str
        TMDB list ID.

    Returns
    -------
    list[dict] | None
        List of normalised item dicts (media_type is 'movie' or 'tv'),
        or None on error.
    """
    data = _get('/list/%s' % list_id)
    if not data:
        return None
    return [_norm_any(item) for item in (data.get('items') or [])]


def movie(movie_id):
    """
    Fetch details for a single TMDB movie.

    Parameters
    ----------
    movie_id : int | str
        TMDB movie ID.

    Returns
    -------
    dict | None
        Normalised movie dict, or None on error.
    """
    data = _get('/movie/%s' % movie_id)
    return _norm_movie(data) if data else None


def tv(tv_id):
    """
    Fetch details for a single TMDB TV show.

    Parameters
    ----------
    tv_id : int | str
        TMDB TV show ID.

    Returns
    -------
    dict | None
        Normalised TV show dict, or None on error.
    """
    data = _get('/tv/%s' % tv_id)
    return _norm_tv(data) if data else None


# ── Browse dispatcher ──────────────────────────────────────────────────────────

# Maps <tmdb> type strings to (fetch_function, cache_hours)
_FETCHERS = {
    'collection': (collection,  _CACHE_BROWSE),
    'list':       (tmdb_list,   _CACHE_BROWSE),
    'movie':      (movie,       _CACHE_ITEM),
    'tv':         (tv,          _CACHE_ITEM),
}


def browse(tmdb_type, tmdb_id):
    """
    Resolve a Jen <tmdb> tag to a list of items, with caching.

    This is the single entry point called by the router's 'tmdb' mode.
    It wraps the individual fetch functions with cache.get() so results
    are re-used within the configured lifetime.

    Parameters
    ----------
    tmdb_type : str
        One of: 'collection', 'list', 'movie', 'tv'.
        Matches the prefix in a Jen <tmdb> tag value.
    tmdb_id : str | int
        The TMDB numeric ID.

    Returns
    -------
    list[dict] | None
        List of normalised item dicts, or None on error / unknown type.

    Examples
    --------
    browse('collection', 151)    →  Star Trek original movie series
    browse('list', 8580589)      →  custom Star Trek TV list
    """
    entry = _FETCHERS.get(tmdb_type)
    if not entry:
        log('TMDB: unknown type %r — supported: %s'
            % (tmdb_type, ', '.join(_FETCHERS)), level='warning')
        return None

    fetch_fn, hours = entry
    return cached(fetch_fn, hours, tmdb_id)


# ── Kodi directory renderer ────────────────────────────────────────────────────

def render(handle, params):
    """
    Fetch a TMDB resource and populate the Kodi directory listing.

    Called by the router when mode='tmdb'.  Reads tmdb_type and tmdb_id
    from params, fetches data via browse(), and adds ListItems to Kodi.

    Items are rendered as non-playable directory stubs for now.
    Future: wire each item to a scraper search so it becomes playable.

    Parameters
    ----------
    handle : int
        Kodi plugin handle (sys.argv[1]).
    params : dict
        URL params from the plugin call.  Expected keys:
            tmdb_type  — 'collection' | 'list' | 'movie' | 'tv'
            tmdb_id    — TMDB numeric ID (as string)
            name       — display title of the parent item (optional)
    """
    tmdb_type = params.get('tmdb_type', '')
    tmdb_id   = params.get('tmdb_id', '')

    if not tmdb_type or not tmdb_id:
        log('TMDB render: missing tmdb_type or tmdb_id in params', level='error')
        return

    if not _api_key():
        # Surface the missing-key problem as a visible item in the list
        _render_no_key(handle)
        return

    items = browse(tmdb_type, tmdb_id)

    if not items:
        log('TMDB: browse returned nothing for %s/%s' % (tmdb_type, tmdb_id),
            level='warning')
        return

    addon_url = sys.argv[0]
    list_items = []

    for item in items:
        title  = item['title']
        year   = item['year']
        label  = '%s (%s)' % (title, year) if year else title

        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': item['thumb'], 'fanart': item['fanart'],
                   'poster': item['thumb']})
        li.setInfo('video', {
            'title':   title,
            'year':    int(item['year']) if item['year'].isdigit() else 0,
            'plot':    item['plot'],
            'rating':  item['rating'],
            'mediatype': item['media_type'],
        })

        media = item['media_type']
        if media == 'movie':
            # Playable item — hand off to the scraper for source discovery.
            li.setProperty('IsPlayable', 'true')
            target    = build_url(
                addon_url,
                mode='scrape',
                title=title,
                year=year,
                tmdb_id=item['tmdb_id'],
                media_type=media,
                fanart=item['fanart'],
                thumb=item['thumb'],
            )
            is_folder = False
        else:
            # TV / unknown — stub folder until TV scraping is implemented.
            target    = build_url(
                addon_url,
                mode='tmdb',
                tmdb_type=media,
                tmdb_id=item['tmdb_id'],
                name=title,
            )
            is_folder = True

        list_items.append((target, li, is_folder))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'movies' if tmdb_type == 'collection' else 'files')


def _render_no_key(handle):
    """Show a single explanatory item when no API key is configured."""
    li = xbmcgui.ListItem(
        '[COLOR yellow]No TMDB API key — open Settings to add one[/COLOR]'
    )
    xbmcplugin.addDirectoryItem(handle, '', li, False)
