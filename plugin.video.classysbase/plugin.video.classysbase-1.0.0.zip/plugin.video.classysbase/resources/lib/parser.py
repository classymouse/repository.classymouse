# -*- coding: utf-8 -*-
"""
Jen / RSS playlist parser.

Reads Chains' .txt playlist files.  Three tag types are supported:

  <item>   — playable media link
  <dir>    — sub-playlist directory (another .txt or plugin:// URL)
  <plugin> — external plugin call (treated as directory)

Uses regex rather than ElementTree so it survives slightly malformed XML.
"""
import json
import re
import sys

import xbmcgui
import xbmcplugin

from resources.lib.client import get
from resources.lib.log import log
from resources.lib.utils import build_url

_ADDON_URL = sys.argv[0]

# Match any of the three block types, capturing tag name + body
_BLOCK_RE = re.compile(
    r'<(item|dir|plugin)>(.*?)</(?:item|dir|plugin)>',
    re.DOTALL | re.IGNORECASE
)


def browse(handle, url):
    """Fetch a Jen playlist URL and populate the Kodi directory."""
    response = get(url)
    if response is None:
        log('Failed to fetch playlist: %s' % url, level='error')
        return   # endOfDirectory is called by the router's finally block

    items = _parse(response.text)
    if not items:
        log('No items parsed from: %s' % url, level='warning')

    _render(handle, items)


# ── parser ─────────────────────────────────────────────────────────────────────

def _parse(content):
    """Return a list of item dicts from a Jen payload."""
    if content.startswith('\ufeff'):          # strip BOM
        content = content[1:]

    items = []
    for tag, body in _BLOCK_RE.findall(content):
        title = _tag(body, 'title') or _tag(body, 'name')
        if not title:
            continue

        # ── TMDB tag (<tmdb>collection/151</tmdb>) ──────────────────────
        tmdb_ref = _tag(body, 'tmdb')   # e.g. "collection/151" or "list/8580589"
        urls     = _extract_urls(body) if not tmdb_ref else []

        # Skip items that have neither a URL nor a TMDB ref
        if not urls and not tmdb_ref:
            continue

        items.append({
            'tag':      tag.lower(),
            'title':    title,
            'urls':     urls,       # list — 1+ elements, OR empty when tmdb_ref set
            'tmdb_ref': tmdb_ref,   # e.g. "collection/151", or '' when urls set
            'thumb':    _tag(body, 'thumbnail') or _tag(body, 'thumb') or _tag(body, 'icon'),
            'fanart':   _tag(body, 'fanart'),
            'plot':     _tag(body, 'summary') or _tag(body, 'description') or _tag(body, 'plot'),
        })
    return items


def _extract_urls(body):
    """
    Extract ALL URLs from an item/dir block and return them as a list.

    Chains' format has three URL patterns:
      1. <link>http://direct.url/video.mp4</link>          → [url]
      2. <link><sublink>url1</sublink>...</link>           → [url1, url2, ...]
      3. Standalone <sublink>url</sublink> (no <link>)     → [url]
      4. <url>http://...</url>                             → [url]

    Returns [] if nothing is found (item should be skipped).
    """
    link = _tag(body, 'link')
    if link:
        if '<sublink>' in link.lower():
            # <link> wraps multiple <sublink> tags — return ALL of them
            sublinks = re.findall(
                r'<sublink>(.*?)</sublink>', link, re.DOTALL | re.IGNORECASE
            )
            urls = [u.strip() for u in sublinks if u.strip()]
            if urls:
                return urls
        # plain <link>url</link>
        if link.strip():
            return [link.strip()]

    # Standalone <sublink> elements outside any <link>
    sublinks = re.findall(
        r'<sublink>(.*?)</sublink>', body, re.DOTALL | re.IGNORECASE
    )
    urls = [u.strip() for u in sublinks if u.strip()]
    if urls:
        return urls

    # Final fallback: <url>
    url = _tag(body, 'url')
    return [url] if url else []


def _tag(body, name, default=''):
    """Extract the text content of the first matching tag in a block body."""
    m = re.search(r'<%s>(.*?)</%s>' % (name, name), body,
                  re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else default


# ── renderer ───────────────────────────────────────────────────────────────────

def _render(handle, items):
    list_items = []

    for item in items:
        tag      = item['tag']
        urls     = item['urls']
        tmdb_ref = item.get('tmdb_ref', '')
        title    = item['title']

        # ── TMDB directory entries (<tmdb>collection/151</tmdb>) ────────
        if tmdb_ref:
            parts = tmdb_ref.split('/', 1)
            if len(parts) == 2:
                tmdb_type, tmdb_id = parts
                target = build_url(
                    _ADDON_URL, mode='tmdb',
                    tmdb_type=tmdb_type, tmdb_id=tmdb_id, name=title
                )
                is_dir = True
            else:
                continue  # malformed tmdb_ref — skip

        elif tag in ('dir', 'plugin'):
            # Use the first URL for directory navigation
            url = urls[0]
            target = url if url.startswith('plugin://') \
                         else build_url(_ADDON_URL, mode='jen', url=url)
            is_dir = True
        else:
            # <item> — playable
            is_dir = False
            if len(urls) == 1:
                # Single source — play directly, no dialog needed
                target = build_url(
                    _ADDON_URL, mode='play',
                    url=urls[0], name=title,
                    thumb=item['thumb'] or '', fanart=item['fanart'] or ''
                )
            else:
                # Multiple sources — show the source picker dialog
                target = build_url(
                    _ADDON_URL, mode='play',
                    urls=json.dumps(urls), name=title,
                    thumb=item['thumb'] or '', fanart=item['fanart'] or ''
                )

        li = xbmcgui.ListItem(title)
        li.setArt({
            'thumb':  item['thumb'],
            'fanart': item['fanart'] or item['thumb'],
        })
        li.setInfo('video', {'title': title, 'plot': item['plot']})
        if not is_dir:
            li.setProperty('IsPlayable', 'true')

        list_items.append((target, li, is_dir))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'files')
