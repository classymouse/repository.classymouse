# Restart Kodi Clean — plugin.video.classysbase
# Kills Kodi, clears .pyc/__pycache__, optionally clears addon cache + log, then restarts Kodi

param(
    [switch]$ClearCache,      # Also clear cache.db
    [switch]$NoRestart,       # Don't restart Kodi after cleanup
    [switch]$Silent           # Minimal output
)

$ErrorActionPreference = "SilentlyContinue"

if (-not $Silent) {
    Write-Host "=== Kodi Restart & Clean ===" -ForegroundColor Cyan
    Write-Host ""
}

# Step 1: Kill Kodi process
Write-Host "[1/4] Stopping Kodi..." -ForegroundColor Yellow
$kodiProcess = Get-Process -Name "kodi" -ErrorAction SilentlyContinue

if ($kodiProcess) {
    Stop-Process -Name "kodi" -Force
    Start-Sleep -Seconds 2

    # Verify it's stopped
    $stillRunning = Get-Process -Name "kodi" -ErrorAction SilentlyContinue
    if ($stillRunning) {
        Write-Host "      WARNING: Kodi still running, waiting..." -ForegroundColor Yellow
        Start-Sleep -Seconds 3
    }
    Write-Host "      ✓ Kodi stopped" -ForegroundColor Green
} else {
    Write-Host "      ℹ Kodi not running" -ForegroundColor Gray
}

# Step 2: Clear .pyc files
Write-Host "[2/4] Clearing Python cache..." -ForegroundColor Yellow
$addonsPath = "$env:APPDATA\Kodi\addons"

$pycFiles = Get-ChildItem -Path $addonsPath -Filter "*.pyc" -Recurse -File -ErrorAction SilentlyContinue
$pycCount = ($pycFiles | Measure-Object).Count

if ($pycCount -gt 0) {
    $pycFiles | Remove-Item -Force -ErrorAction SilentlyContinue
}

$pycacheDirs = Get-ChildItem -Path $addonsPath -Filter "__pycache__" -Recurse -Directory -ErrorAction SilentlyContinue
$pycacheDirCount = ($pycacheDirs | Measure-Object).Count

if ($pycacheDirCount -gt 0) {
    $pycacheDirs | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}

Write-Host "      ✓ Removed $pycCount .pyc files and $pycacheDirCount __pycache__ dirs" -ForegroundColor Green

# Step 3: Clear addon cache if requested
if ($ClearCache) {
    Write-Host "[3/4] Clearing addon cache..." -ForegroundColor Yellow

    # Our SQLite cache
    $addonData = "$env:APPDATA\Kodi\userdata\addon_data\plugin.video.classysbase"
    $cacheDb   = Join-Path $addonData "cache.db"
    if (Test-Path $cacheDb) {
        Remove-Item $cacheDb -Force
        Write-Host "      ✓ cache.db cleared" -ForegroundColor Green
    } else {
        Write-Host "      ℹ cache.db not found" -ForegroundColor Gray
    }

    # Kodi thumbnail / texture cache
    $thumbCache = "$env:APPDATA\Kodi\userdata\Thumbnails"
    if (Test-Path $thumbCache) {
        Get-ChildItem -Path $thumbCache -Recurse -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Host "      ✓ Thumbnails cache cleared" -ForegroundColor Green
    }

    # Kodi temp dir
    $kodiTemp = "$env:APPDATA\Kodi\temp"
    if (Test-Path $kodiTemp) {
        Get-ChildItem -Path $kodiTemp -Recurse -File -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
        Write-Host "      ✓ Kodi temp cleared" -ForegroundColor Green
    }

    # Truncate kodi.log so it's fresh on next run
    $kodiLog = "$env:APPDATA\Kodi\kodi.log"
    if (Test-Path $kodiLog) {
        Clear-Content $kodiLog
        Write-Host "      ✓ kodi.log truncated" -ForegroundColor Green
    }

    # Truncate our own addon log
    $addonLog = "$env:APPDATA\Kodi\classysbase.log"
    if (Test-Path $addonLog) {
        Clear-Content $addonLog
        Write-Host "      ✓ classysbase.log truncated" -ForegroundColor Green
    }
} else {
    Write-Host "[3/4] Skipping cache clear (use -ClearCache to clear)" -ForegroundColor Gray
}

# Step 4: Restart Kodi
if (-not $NoRestart) {
    Write-Host "[4/4] Starting Kodi..." -ForegroundColor Yellow

    # Find Kodi executable
    $kodiPaths = @(
        "$env:ProgramFiles\Kodi\kodi.exe",
        "${env:ProgramFiles(x86)}\Kodi\kodi.exe",
        "$env:LOCALAPPDATA\Kodi\kodi.exe"
    )

    $kodiExe = $kodiPaths | Where-Object { Test-Path $_ } | Select-Object -First 1

    if ($kodiExe) {
        Start-Process $kodiExe
        Write-Host "      ✓ Kodi started" -ForegroundColor Green
    } else {
        Write-Host "      ⚠ Could not find Kodi executable" -ForegroundColor Yellow
        Write-Host "      Please start Kodi manually" -ForegroundColor Yellow
    }
} else {
    Write-Host "[4/4] Skipping restart (use without -NoRestart to auto-start)" -ForegroundColor Gray
}

Write-Host ""
Write-Host "✓ Done!" -ForegroundColor Green
Write-Host ""

# Show usage examples
if (-not $Silent) {
    Write-Host "Quick reference:" -ForegroundColor Cyan
    Write-Host "  .\restart_kodi_clean.ps1                    # Clean pyc and restart"
    Write-Host "  .\restart_kodi_clean.ps1 -ClearCache        # Also clear cache.db + log"
    Write-Host "  .\restart_kodi_clean.ps1 -NoRestart         # Clean only, don't restart"
    Write-Host "  .\restart_kodi_clean.ps1 -Silent            # Minimal output"
    Write-Host ""
}
