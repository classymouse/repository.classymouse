#Requires -Version 5.1
<#
.SYNOPSIS
    Package plugin.video.classysbase and publish it to the distribution repo.

.DESCRIPTION
    1. Updates addon.xml to the new version
    2. Commits the version bump + pushes the source repo
    3. Creates a release zip  (excludes .git, __pycache__, tools/, *.pyc, *.db)
    4. Copies zip + addon.xml into a local clone of repository.classymouse
    5. Regenerates addons.xml and addons.xml.md5
    6. Commits + pushes the distribution repo
    7. Tags the source repo with v<Version>

    GitHub Pages URL (once Pages is enabled on repository.classymouse):
        https://classymouse.github.io/repository.classymouse/

.PARAMETER Version
    Target version string, e.g. "1.0.1".
    Omit to auto-increment the patch number of the current version.

.PARAMETER DistRepoPath
    Local path to a clone of classymouse/repository.classymouse.
    Defaults to the sibling directory: ..\repository.classymouse

.EXAMPLE
    .\tools\publish.ps1                      # 1.0.0 -> 1.0.1 (auto-increment)
    .\tools\publish.ps1 -Version 1.1.0
    .\tools\publish.ps1 -Version 1.0.1 -DistRepoPath C:\repos\repository.classymouse
#>
param(
    [string]$Version      = '',
    [string]$DistRepoPath = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$AddonId    = 'plugin.video.classysbase'
$SourceRoot = Split-Path $PSScriptRoot -Parent

if (-not $DistRepoPath) {
    $DistRepoPath = Join-Path (Split-Path $SourceRoot -Parent) 'repository.classymouse'
}

$NoBom = New-Object System.Text.UTF8Encoding $false

# ── 1. Determine new version ───────────────────────────────────────────────────

[xml]$addonXml     = Get-Content "$SourceRoot\addon.xml" -Encoding UTF8
$currentVersion    = $addonXml.addon.version

if (-not $Version) {
    $p    = $currentVersion.Split('.')
    $p[2] = [string]([int]$p[2] + 1)
    $Version = $p -join '.'
}

Write-Host ""
Write-Host ("  Publishing {0}   {1} → {2}" -f $AddonId, $currentVersion, $Version) -ForegroundColor Cyan
Write-Host ""

# ── 2. Update addon.xml ────────────────────────────────────────────────────────

$addonXml.addon.SetAttribute('version', $Version)
$writer = New-Object System.IO.StreamWriter("$SourceRoot\addon.xml", $false, $NoBom)
$addonXml.Save($writer)
$writer.Close()
Write-Host "  [1/7] addon.xml updated to v$Version"

# ── 3. Commit + tag + push source repo ────────────────────────────────────────

git -C $SourceRoot add addon.xml
git -C $SourceRoot commit -m "release: v$Version"
git -C $SourceRoot tag "v$Version"
git -C $SourceRoot push origin master
git -C $SourceRoot push origin "v$Version"
Write-Host "  [2/7] source repo: committed, tagged v$Version, pushed"

# ── 4. Build zip ──────────────────────────────────────────────────────────────

$ZipName = "$AddonId-$Version.zip"
$ZipPath = Join-Path $env:TEMP $ZipName
if (Test-Path $ZipPath) { Remove-Item $ZipPath }

Add-Type -AssemblyName System.IO.Compression.FileSystem
$zip     = [System.IO.Compression.ZipFile]::Open($ZipPath, 'Create')
$exclude = @('\\\.git\\', '[/\\]__pycache__[/\\]', '\\tools\\',
             '\.pyc$', '\.pyo$', '\.db$', '\\\.vs\\', '\\\.vscode\\')

Get-ChildItem $SourceRoot -Recurse -File | Where-Object {
    $fp = $_.FullName
    -not ($exclude | Where-Object { $fp -match $_ })
} | ForEach-Object {
    # Forward slashes required — Kodi rejects zips with backslash entry names
    $entry = $AddonId + '/' + $_.FullName.Substring($SourceRoot.Length + 1).Replace('\', '/')
    [void][System.IO.Compression.ZipFileExtensions]::CreateEntryFromFile(
        $zip, $_.FullName, $entry)
}
$zip.Dispose()
Write-Host "  [3/7] zip built: $ZipPath"

# ── 5. Ensure local dist repo clone is up to date ─────────────────────────────

if (-not (Test-Path "$DistRepoPath\.git")) {
    Write-Host "  [4/7] cloning repository.classymouse to $DistRepoPath …"
    git clone https://github.com/classymouse/repository.classymouse.git $DistRepoPath
} else {
    git -C $DistRepoPath pull origin main
    Write-Host "  [4/7] dist repo pulled"
}

# ── 6. Copy zip + addon.xml into dist repo ────────────────────────────────────

$destDir = Join-Path $DistRepoPath $AddonId
New-Item -ItemType Directory -Force -Path $destDir | Out-Null

# Keep only the latest zip for this addon (remove older versions)
Get-ChildItem $destDir -Filter "$AddonId-*.zip" | Remove-Item -Force

Copy-Item $ZipPath                      (Join-Path $destDir $ZipName)   -Force
Copy-Item "$SourceRoot\addon.xml"       (Join-Path $destDir 'addon.xml') -Force
Write-Host "  [5/7] $ZipName copied to dist repo"

# ── 7. Regenerate addons.xml and addons.xml.md5 ───────────────────────────────

$sb = [System.Text.StringBuilder]::new()
[void]$sb.AppendLine('<?xml version="1.0" encoding="UTF-8"?>')
[void]$sb.AppendLine('<addons>')

Get-ChildItem $DistRepoPath -Directory |
    Where-Object { Test-Path (Join-Path $_.FullName 'addon.xml') } |
    ForEach-Object {
        # Read raw text and strip the XML declaration line, then indent
        $raw   = Get-Content (Join-Path $_.FullName 'addon.xml') -Raw -Encoding UTF8
        $inner = ($raw -replace '(?s)<\?xml[^?]*\?>\s*', '').Trim()
        foreach ($line in ($inner -split "`r?`n")) {
            [void]$sb.AppendLine("  $line")
        }
    }

[void]$sb.AppendLine('</addons>')
# Normalize to LF (\n) — git autocrlf=true converts \r\n to \n on push,
# so the MD5 must be computed from the \n bytes to match what GitHub Pages serves.
$addonsContent = $sb.ToString().Replace("`r`n", "`n")
$liveBytes = [System.Text.Encoding]::UTF8.GetBytes($addonsContent)
[System.IO.File]::WriteAllBytes("$DistRepoPath\addons.xml", $liveBytes)

$hash = ([System.Security.Cryptography.MD5]::Create().ComputeHash($liveBytes) |
         ForEach-Object { $_.ToString('x2') }) -join ''
[System.IO.File]::WriteAllText("$DistRepoPath\addons.xml.md5", $hash, $NoBom)

Write-Host "  [6/7] addons.xml regenerated  (MD5: $hash)"

# ── 8. Commit + push dist repo ────────────────────────────────────────────────

git -C $DistRepoPath add .
git -C $DistRepoPath commit -m "release: $AddonId $Version"
git -C $DistRepoPath push origin main
Write-Host "  [7/7] distribution repo pushed"

# ── Done ──────────────────────────────────────────────────────────────────────

Write-Host ""
Write-Host "  Done!  v$Version is live." -ForegroundColor Green
Write-Host ""
Write-Host "  Source:  https://github.com/classymouse/plugin.video.classysbase" -ForegroundColor DarkGray
Write-Host "  Repo:    https://classymouse.github.io/repository.classymouse/" -ForegroundColor DarkGray
Write-Host ""
Write-Host "  NOTE: If this is the first publish, enable GitHub Pages on" -ForegroundColor Yellow
Write-Host "  repository.classymouse (Settings > Pages > Branch: main / root)" -ForegroundColor Yellow
Write-Host ""
