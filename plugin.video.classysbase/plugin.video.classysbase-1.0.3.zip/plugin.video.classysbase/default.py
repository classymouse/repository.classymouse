# -*- coding: utf-8 -*-
import sys
import os

# Add resources/lib/ to sys.path so bundled packages (e.g. segno) can
# resolve their own absolute imports.
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                'resources', 'lib'))

from resources.lib.router import Router

Router(sys.argv).run()
