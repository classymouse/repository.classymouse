"""
Jen / RSS playlist parser.

Reads Chains' .txt playlist files.  Three tag types are supported:

  <item>   — playable media link
  <dir>    — sub-playlist directory (another .txt or plugin:// URL)
  <plugin> — external plugin call (treated as directory)

Uses regex rather than ElementTree so it survives slightly malformed XML.
"""
import json
import re
import sys

import xbmcgui
import xbmcplugin

from resources.lib.client import get
from resources.lib.infotag import VideoInfo
from resources.lib.log import log
from resources.lib.utils import build_url

_ADDON_URL = sys.argv[0]

# Match any of the three block types, capturing tag name + body
_BLOCK_RE = re.compile(
    r'<(item|dir|plugin)>(.*?)</(?:item|dir|plugin)>',
    re.DOTALL | re.IGNORECASE
)

_SEASON_RE   = re.compile(r'^(?:season|series?)\s*(\d+)$',       re.IGNORECASE)
_EP_TITLE_RE = re.compile(r'(?:episode|ep\.?)\s*(\d+)',           re.IGNORECASE)
_EP_URL_RE   = re.compile(r'[Ss]\d+[Ee](\d+)')


def _episode_num(title, url=''):
    """Try to extract an episode number from title or URL filename."""
    m = _EP_TITLE_RE.search(title)
    if m:
        return m.group(1)
    m = _EP_URL_RE.search(url)
    if m:
        return m.group(1)
    return ''


def browse(handle, url, params=None):
    """Fetch a Jen playlist URL and populate the Kodi directory."""
    log('[classysbase] parser.browse → %s' % url)
    response = get(url)
    if response is None:
        log('Failed to fetch playlist: %s' % url, level='error')
        return   # endOfDirectory is called by the router's finally block

    items = _parse(response.text)
    if not items:
        log('No items parsed from: %s' % url, level='warning')

    _render(handle, items, params or {})


# ── parser ─────────────────────────────────────────────────────────────────────

def _parse(content):
    """Return a list of item dicts from a Jen payload."""
    if content.startswith('\ufeff'):          # strip BOM
        content = content[1:]

    items = []
    for tag, body in _BLOCK_RE.findall(content):
        title = _tag(body, 'title') or _tag(body, 'name')
        if not title:
            continue

        # ── TMDB tag (<tmdb>collection/151</tmdb>) ──────────────────────
        tmdb_ref = _tag(body, 'tmdb')   # e.g. "collection/151" or "list/8580589"
        urls     = _extract_urls(body) if not tmdb_ref else []

        # Skip items that have neither a URL nor a TMDB ref
        if not urls and not tmdb_ref:
            continue

        items.append({
            'tag':      tag.lower(),
            'title':    title,
            'urls':     urls,       # list — 1+ elements, OR empty when tmdb_ref set
            'tmdb_ref': tmdb_ref,   # e.g. "collection/151", or '' when urls set
            'thumb':    _tag(body, 'thumbnail') or _tag(body, 'thumb') or _tag(body, 'icon'),
            'fanart':   _tag(body, 'fanart'),
            'plot':     _tag(body, 'summary') or _tag(body, 'description') or _tag(body, 'plot'),
        })
    return items


def _extract_urls(body):
    """
    Extract ALL URLs from an item/dir block and return them as a list.

    Chains' format has three URL patterns:
      1. <link>http://direct.url/video.mp4</link>          → [url]
      2. <link><sublink>url1</sublink>...</link>           → [url1, url2, ...]
      3. Standalone <sublink>url</sublink> (no <link>)     → [url]
      4. <url>http://...</url>                             → [url]

    Returns [] if nothing is found (item should be skipped).
    """
    link = _tag(body, 'link')
    if link:
        if '<sublink>' in link.lower():
            # <link> wraps multiple <sublink> tags — return ALL of them
            sublinks = re.findall(
                r'<sublink>(.*?)</sublink>', link, re.DOTALL | re.IGNORECASE
            )
            urls = [u.strip() for u in sublinks if u.strip()]
            if urls:
                return urls
        # plain <link>url</link>
        if link.strip():
            return [link.strip()]

    # Standalone <sublink> elements outside any <link>
    sublinks = re.findall(
        r'<sublink>(.*?)</sublink>', body, re.DOTALL | re.IGNORECASE
    )
    urls = [u.strip() for u in sublinks if u.strip()]
    if urls:
        return urls

    # Final fallback: <url>
    url = _tag(body, 'url')
    return [url] if url else []


def _tag(body, name, default=''):
    """Extract the text content of the first matching tag in a block body."""
    m = re.search(r'<{}>(.*?)</{}>'.format(name, name), body,
                  re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else default


# ── renderer ───────────────────────────────────────────────────────────────────

def _render(handle, items, ctx=None):
    ctx        = ctx or {}
    show_title = ctx.get('show_title', '')
    season     = ctx.get('season', '')

    # ── Fetch all data once for this list render ──────────────────────────────
    _watched_titles  = set()
    _watched_shows   = {}
    _show_tmdb_cache = {}
    _playback        = {}   # {show_tmdb_id_str: {season_str: {ep_str: progress%}}}
    _ep_meta         = {}   # {str(episode_number): norm_episode_dict}
    try:
        import resources.lib.trakt_api as _trakt
        from resources.lib.tmdb import tmdb_id_from_title as _tmdb_search, \
                                       season_episodes_cached as _season_eps
        if _trakt.is_authenticated():
            _watched_titles = _trakt.get_watched_movie_titles() or set()
            _watched_shows  = _trakt.get_watched_shows() or {}
            _playback       = _trakt.get_show_playback() or {}
        if show_title:
            _show_tmdb_cache[show_title] = _tmdb_search(show_title, 'tv')
            tid = _show_tmdb_cache.get(show_title)
            if tid:
                eps = _season_eps(tid, int(season) if season else 1)
                if eps:
                    _ep_meta = {str(e['episode_number']): e for e in eps}
    except Exception:
        pass

    list_items = []

    for item in items:
        tag      = item['tag']
        urls     = item['urls']
        tmdb_ref = item.get('tmdb_ref', '')
        title    = item['title']
        ep_num   = ''
        ep_meta  = None
        # ── TMDB directory entries (<tmdb>collection/151</tmdb>) ────────
        if tmdb_ref:
            parts = tmdb_ref.split('/', 1)
            if len(parts) == 2:
                tmdb_type, tmdb_id = parts
                target = build_url(
                    _ADDON_URL, mode='tmdb',
                    tmdb_type=tmdb_type, tmdb_id=tmdb_id, name=title
                )
                is_dir = True
            else:
                continue  # malformed tmdb_ref — skip

        elif tag in ('dir', 'plugin'):
            # Use the first URL for directory navigation
            url = urls[0]
            if url.startswith('plugin://'):
                target = url
            else:
                m_sn = _SEASON_RE.match(title.strip())
                if m_sn:
                    # Season dir — keep show_title, update season number
                    target = build_url(_ADDON_URL, mode='jen', url=url,
                                       show_title=show_title,
                                       season=m_sn.group(1))
                else:
                    # Show/category dir — set show_title to this item, clear season
                    target = build_url(_ADDON_URL, mode='jen', url=url,
                                       show_title=title, season='')
            is_dir = True
        else:
            # <item> — playable
            is_dir  = False
            ep_num  = _episode_num(title, urls[0] if urls else '')
            ep_meta = _ep_meta.get(str(ep_num)) if ep_num else None
            ctx_extra = {}
            if show_title:
                ctx_extra = {'show_title': show_title,
                             'season':     season,
                             'episode':    ep_num}
            if len(urls) == 1:
                # Single source — play directly, no dialog needed
                target = build_url(
                    _ADDON_URL, mode='play',
                    url=urls[0], name=title,
                    thumb=item['thumb'] or '', fanart=item['fanart'] or '',
                    **ctx_extra
                )
            else:
                # Multiple sources — show the source picker dialog
                target = build_url(
                    _ADDON_URL, mode='play',
                    urls=json.dumps(urls), name=title,
                    thumb=item['thumb'] or '', fanart=item['fanart'] or '',
                    **ctx_extra
                )

        display_title = (ep_meta['title'] if ep_meta else None) or title
        li = xbmcgui.ListItem(display_title)
        li.setArt({
            'thumb':  (ep_meta['thumb'] if ep_meta else None) or item['thumb'] or '',
            'fanart': (ep_meta['fanart'] if ep_meta else None) or item['fanart'] or item['thumb'] or '',
        })

        # ── Watched / resume state ───────────────────────────────────────────────
        watched = (not is_dir) and (title.lower().strip() in _watched_titles)
        resume  = 0.0
        if not is_dir and ep_num:
            try:
                tid = _show_tmdb_cache.get(show_title)
                if tid:
                    sn  = str(int(season)) if season else '1'
                    en  = str(int(ep_num))
                    sid = str(tid)
                    if not watched:
                        watched = en in (_watched_shows.get(sid, {}).get(sn) or set())
                    prog = _playback.get(sid, {}).get(sn, {}).get(en, 0.0)
                    if prog and not watched:
                        dur_s  = int(ep_meta['runtime']) * 60 if ep_meta else 0
                        resume = (prog / 100.0) * dur_s if dur_s else 0.0
            except Exception:
                pass

        # ── VideoInfo ───────────────────────────────────────────────────────
        vi = {
            'title':     display_title,
            'plot':      item['plot'] or '',
            'playcount': 1 if watched else 0,
        }
        if ep_meta:
            vi.update({
                'title':       ep_meta['title'] or title,
                'plot':        ep_meta['plot'] or item['plot'] or '',
                'year':        ep_meta['year'] or 0,
                'rating':      ep_meta['rating'],
                'duration':    ep_meta['runtime'] * 60,
                'episode':     ep_meta['episode_number'],
                'season':      ep_meta['season_number'],
                'tvshowtitle': ep_meta['show_title'],
                'first_aired': ep_meta.get('first_aired', ''),
                'media_type':  'episode',
                'unique_ids':  {'tmdb': str(ep_meta['show_id'])},
            })
            if resume:
                vi['resume'] = resume
        VideoInfo(li, **vi)
        if not is_dir:
            li.setProperty('IsPlayable', 'true')
            if show_title:
                from resources.lib.strings import _, S_MARK_WATCHED_CM
                cm_url = build_url(
                    _ADDON_URL, mode='trakt_mark', action='watched',
                    media_type='episode',
                    show_title=show_title, season=season, episode=ep_num,
                    name=title,
                )
                li.addContextMenuItems([
                    (_(S_MARK_WATCHED_CM), 'RunPlugin(%s)' % cm_url),
                ])

        list_items.append((target, li, is_dir))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'files')
