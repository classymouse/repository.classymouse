from urllib.parse import urlencode


def build_url(base, **params):
    """Build a plugin:// URL with query parameters."""
    return '{}?{}'.format(base, urlencode(params))
