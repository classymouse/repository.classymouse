"""
Playback handler — resolves URLs and hands them to Kodi.

Resolution order:
  1. script.module.resolveurl  — handles 200+ hosters AND magnet links via
                                  debrid Universal Resolvers (Real-Debrid,
                                  AllDebrid, Premiumize, OffCloud …)
  2. Direct URL fallback       — mp4 / mkv / m3u8 / pipe-header links

When params contains 'urls' (JSON list) the source-picker dialog is shown
first so the user can choose which hoster to play from.
"""
import json

import xbmc
import xbmcgui
import xbmcplugin

from resources.lib.infotag import VideoInfo
from resources.lib.log import log

_IS_MAGNET = lambda u: u.lower().startswith('magnet:')


def play(handle, params):
    """Entry point — show source picker if multiple sources, else play directly."""
    log('[classysbase] play → url=%s name=%s'
        % (params.get('url', params.get('urls', ''))[:120], params.get('name', '')))
    title  = params.get('name', '')
    fanart = params.get('fanart', '')
    poster = params.get('thumb', '')

    # ── Multiple sources → show picker dialog ───────────────────────────
    raw_urls = params.get('urls', '')
    if raw_urls:
        try:
            url_list = json.loads(raw_urls)
        except (ValueError, TypeError):
            url_list = []

        if not url_list:
            log('play() urls param is empty after decode', level='error')
            _fail(handle)
            return

        if len(url_list) == 1:
            url = url_list[0]
        else:
            from resources.lib.sourcesdialog import SourcesDialog
            url = SourcesDialog.show(
                sources=[{'url': u} for u in url_list],
                title=title,
                fanart=fanart,
                poster=poster,
            )
            if not url:
                # User dismissed the dialog — signal Kodi we're not playing
                _fail(handle)
                return

    else:
        # ── Single source ────────────────────────────────────────────────
        url = params.get('url', '')

    if not url:
        log('play() called with no URL', level='error')
        _fail(handle)
        return

    resolved = _resolve(url)
    if not resolved:
        _fail(handle)
        return

    li = xbmcgui.ListItem(title, path=resolved)
    VideoInfo(li, title=title)
    xbmcplugin.setResolvedUrl(handle, succeeded=True, listitem=li)


def _resolve(url):
    """
    Return a playable URL string, or None.

    Errors are surfaced to the user via notifications rather than silently
    swallowed so they know whether the problem is missing debrid auth,
    geo-blocking, or something else entirely.
    """

    # 1. ResolveUrl — primary path for everything
    try:
        import resolveurl
        hmf = resolveurl.HostedMediaFile(url)
        if hmf.valid_url():
            return hmf.resolve()

        # valid_url() returned False — no registered resolver can handle this.
        # For magnet links this means no debrid Universal Resolver is active.
        if _IS_MAGNET(url):
            _notify(
                'Magnet link needs a debrid service.\n'
                'Configure Real-Debrid or AllDebrid in ResolveUrl settings.',
                xbmcgui.NOTIFICATION_WARNING, ms=7000
            )
            return None

    except Exception as e:
        err_type = type(e).__name__   # 'ResolverError' or something else
        err_msg  = str(e)
        log('{}: {}'.format(err_type, err_msg), level='warning')

        if 'ResolverError' in err_type:
            low = err_msg.lower()
            if '401' in low or 'unauthorized' in low:
                _notify('Debrid account not authorised — check ResolveUrl settings.',
                        xbmcgui.NOTIFICATION_ERROR)
            elif '451' in low or 'infringing' in low:
                _notify('Content unavailable via debrid (geo-blocked or flagged).',
                        xbmcgui.NOTIFICATION_WARNING)
            else:
                _notify('Resolver error: %s' % err_msg, xbmcgui.NOTIFICATION_ERROR)
        else:
            log('resolveurl unexpected error: %s' % err_msg, level='error')
        return None

    # 2. Direct link fallback (no resolver needed)
    lower = url.lower().split('?')[0]
    direct_exts = ('.mp4', '.mkv', '.avi', '.m3u8', '.ts', '.mov', '.wmv', '.flv')
    if any(lower.endswith(ext) for ext in direct_exts):
        return url

    if '|' in url:          # URL|User-Agent=…&Referer=… pattern
        return url

    log('No resolver found for: %s' % url, level='warning')
    return None


def scrape_and_play(handle, params):
    """
    Find stream sources via external scraper modules and play the chosen one.

    Called by the router for mode=scrape.  params must contain:
        title, year, media_type, tmdb_id (optional), fanart (optional), thumb (optional)
    """
    log('[classysbase] scrape → title=%s S%sE%s tmdb_id=%s'
        % (params.get('title', ''), params.get('season', ''),
           params.get('episode', ''), params.get('tmdb_id', '')))
    title      = params.get('title', '')
    year       = params.get('year', '')
    media_type = params.get('media_type', 'movie')
    tmdb_id    = params.get('tmdb_id', '') or None
    fanart     = params.get('fanart', '')
    poster     = params.get('thumb', '')
    season     = params.get('season') or None
    episode    = params.get('episode') or None
    ep_title   = params.get('ep_title', '')

    addon_ids = _get_scraper_addons()
    if not addon_ids:
        _notify(
            'No scraper enabled.\nOpen Settings → Scrapers to activate one.',
            xbmcgui.NOTIFICATION_WARNING, ms=7000
        )
        xbmcplugin.endOfDirectory(handle, True, updateListing=False, cacheToDisc=False)
        return

    from resources.lib.scraper import scrape

    if season and episode:
        display = '"%s" S%02dE%02d' % (title, int(season), int(episode))
    else:
        display = '"%s"' % title

    pd = xbmcgui.DialogProgress()
    from resources.lib.strings import _, S_ADDON_NAME, S_SEARCHING, S_NO_SOURCES, S_NO_STREAM
    pd.create(_(S_ADDON_NAME), _(S_SEARCHING) % display)
    try:
        sources = scrape(
            title=title,
            year=year,
            media_type=media_type,
            tmdb_id=tmdb_id,
            season=season,
            episode=episode,
            tvshowtitle=title if media_type == 'episode' else None,
            addon_ids=addon_ids,
            progress_dialog=pd,
        )
    finally:
        pd.close()

    if not sources:
        _notify(_(S_NO_SOURCES) % title,
                xbmcgui.NOTIFICATION_WARNING, ms=5000)
        xbmcplugin.endOfDirectory(handle, True, updateListing=False, cacheToDisc=False)
        return

    # One-click: skip the sources dialog and auto-play the best result
    import xbmcaddon as _xbmcaddon
    _own = _xbmcaddon.Addon()
    _is_tv = media_type == 'episode'
    one_click = _own.getSetting('one_click_tv' if _is_tv else 'one_click') == 'true'

    if len(sources) == 1 or one_click:
        url = sources[0]['url']
    else:
        from resources.lib.sourcesdialog import SourcesDialog
        url = SourcesDialog.show(
            sources=sources,
            title=title,
            fanart=fanart,
            poster=poster,
        )
        if not url:
            # User dismissed the dialog — silent cancel, no "Playback Failed"
            xbmcplugin.endOfDirectory(handle, True, updateListing=False, cacheToDisc=False)
            return

    resolved = _resolve(url)
    if not resolved:
        _notify(_(S_NO_STREAM),
                xbmcgui.NOTIFICATION_ERROR, ms=5000)
        xbmcplugin.endOfDirectory(handle, True, updateListing=False, cacheToDisc=False)
        return

    play_title = ep_title or title
    li = xbmcgui.ListItem(play_title, path=resolved)
    vi_kwargs = {'title': play_title}
    if media_type == 'episode':
        vi_kwargs['tvshowtitle'] = title
        if season:  vi_kwargs['season']  = int(season)
        if episode: vi_kwargs['episode'] = int(episode)
    VideoInfo(li, **vi_kwargs)
    xbmc.Player().play(resolved, li)
    xbmcplugin.endOfDirectory(handle, True, updateListing=False, cacheToDisc=False)


def _get_scraper_addons():
    """
    Return the list of scraper addon IDs that are both enabled in our settings
    and actually installed.  The user controls which scrapers are active via
    Settings → Scrapers.
    """
    import xbmcaddon
    own    = xbmcaddon.Addon()
    pairs  = [
        ('script.module.gearsscrapers',     'use_gearsscrapers'),
        ('script.module.viperscrapers',     'use_viperscrapers'),
        ('script.module.homelanderscrapers','use_homelanderscrapers'),
        ('script.module.cocoscrapers',      'use_cocoscrapers'),
    ]
    result = []
    for addon_id, setting_key in pairs:
        if own.getSetting(setting_key) == 'true':
            try:
                xbmcaddon.Addon(addon_id)
                result.append(addon_id)
            except Exception:
                pass
    return result


def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=5000):
    from resources.lib.strings import _, S_ADDON_NAME
    xbmcgui.Dialog().notification(_(S_ADDON_NAME), msg, icon, ms)


def _fail(handle):
    xbmcplugin.setResolvedUrl(handle, succeeded=False, listitem=xbmcgui.ListItem())
