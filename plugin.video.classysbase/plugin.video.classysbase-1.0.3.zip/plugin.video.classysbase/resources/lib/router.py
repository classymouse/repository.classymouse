"""
URL router — the single entry point for every addon call.

Responsibilities:
    • Parse argv[2] into a params dict
    • Dispatch to the correct handler by mode=
    • Guarantee endOfDirectory is always called (try/finally)
    • Keep play and dev_panel outside that guarantee (they manage their own response)
"""
import sys
import traceback
from urllib.parse import parse_qsl

import xbmc
import xbmcplugin

from resources.lib.log import log


class Router:
    def __init__(self, argv):
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip('?')))

    def run(self):
        mode = self.params.get('mode', 'main')

        # ── modes that manage their own response ──────────────────────────────

        if mode == 'play':
            from resources.lib.player import play
            play(self.handle, self.params)
            return

        if mode == 'scrape':
            from resources.lib.player import scrape_and_play
            scrape_and_play(self.handle, self.params)
            return

        if mode == 'dev_panel':
            from resources.lib.keys import dev_panel
            dev_panel()
            return

        if mode == 'settings':
            import xbmcaddon
            xbmcaddon.Addon().openSettings()
            # settings is dialog-only; signal empty directory so Kodi doesn't error
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_auth':
            from resources.lib.trakt_auth import run_auth
            run_auth()
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_disconnect':
            import xbmcgui
            import resources.lib.trakt_api as trakt
            from resources.lib.strings import _, S_ADDON_NAME, S_DISCONNECT_Q, S_DISCONNECT_HINT, S_DISCONNECTED
            if xbmcgui.Dialog().yesno(
                _(S_ADDON_NAME),
                '{}[CR]{}'.format(_(S_DISCONNECT_Q), _(S_DISCONNECT_HINT)),
            ):
                trakt.disconnect()
                xbmcgui.Dialog().notification(
                    _(S_ADDON_NAME), _(S_DISCONNECTED),
                    xbmcgui.NOTIFICATION_INFO, 2500,
                )
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_toggle':
            import xbmcgui
            import resources.lib.trakt_api as trakt
            p       = self.params
            action  = p.get('action', 'watched')   # 'watched' | 'unwatched'
            mtype   = p.get('media_type', 'movie')
            tmdb_id = p.get('tmdb_id', '')
            show_id = p.get('show_id', tmdb_id)
            season  = p.get('season', 0)
            episode = p.get('episode', 0)

            ok = False
            if mtype == 'movie':
                ok = (trakt.mark_movie_watched(tmdb_id) if action == 'watched'
                        else trakt.mark_movie_unwatched(tmdb_id))
            elif mtype == 'episode':
                ok = (trakt.mark_episode_watched(show_id, season, episode) if action == 'watched'
                        else trakt.mark_episode_unwatched(show_id, season, episode))
            elif mtype == 'season':
                ok = (trakt.mark_season_watched(show_id, season) if action == 'watched'
                        else trakt.mark_season_unwatched(show_id, season))
            elif mtype == 'tvshow':
                ok = (trakt.mark_show_watched(tmdb_id) if action == 'watched'
                        else trakt.mark_show_unwatched(tmdb_id))

            from resources.lib.strings import _, S_TRAKT, S_MARKED_WATCHED, S_MARKED_UNWATCHED, S_MARK_FAILED
            notif_ok  = _(S_MARKED_WATCHED) if action == 'watched' else _(S_MARKED_UNWATCHED)
            if ok:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), notif_ok,
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_MARK_FAILED),
                    xbmcgui.NOTIFICATION_ERROR, 3000,
                )
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_mark':
            import xbmcgui
            import resources.lib.trakt_api as trakt
            from resources.lib.tmdb import tmdb_id_from_title
            p          = self.params
            action     = p.get('action', 'watched')
            mtype      = p.get('media_type', 'episode')
            tmdb_id    = p.get('tmdb_id', '')
            show_title = p.get('show_title', '')
            season     = p.get('season', '')
            episode    = p.get('episode', '')
            if not season and episode:
                season = '1'  # no season folder → assume season 1
            log('[classysbase] trakt_mark: show={!r} S{} E{} action={}'.format(show_title, season, episode, action))
            if not tmdb_id and show_title:
                resolved = tmdb_id_from_title(show_title, 'tv')
                tmdb_id = str(resolved) if resolved else ''
            log('[classysbase] trakt_mark: tmdb_id=%s' % tmdb_id)
            from resources.lib.strings import _, S_TRAKT, S_TMDB_NOT_FOUND, S_MARKED_WATCHED, S_MARKED_UNWATCHED, S_MARK_FAILED
            if not tmdb_id:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_TMDB_NOT_FOUND) % show_title,
                    xbmcgui.NOTIFICATION_WARNING, 3000,
                )
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
                return
            ok = False
            if mtype == 'episode' and season and episode:
                ok = (trakt.mark_episode_watched(tmdb_id, season, episode) if action == 'watched'
                      else trakt.mark_episode_unwatched(tmdb_id, season, episode))
            elif mtype == 'season' and season:
                ok = (trakt.mark_season_watched(tmdb_id, season) if action == 'watched'
                      else trakt.mark_season_unwatched(tmdb_id, season))
            elif mtype == 'tvshow':
                ok = (trakt.mark_show_watched(tmdb_id) if action == 'watched'
                      else trakt.mark_show_unwatched(tmdb_id))
            elif mtype == 'movie':
                ok = (trakt.mark_movie_watched(tmdb_id) if action == 'watched'
                      else trakt.mark_movie_unwatched(tmdb_id))
            log('[classysbase] trakt_mark: ok=%s' % ok)
            notif_ok2 = _(S_MARKED_WATCHED) if action == 'watched' else _(S_MARKED_UNWATCHED)
            if ok:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), notif_ok2,
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_MARK_FAILED),
                    xbmcgui.NOTIFICATION_ERROR, 3000,
                )
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        # ── directory modes — endOfDirectory guaranteed via finally ───────────

        succeeded = True
        try:
            if mode == 'main':
                from resources.lib.scraper import refresh_settings_labels
                refresh_settings_labels()
                from resources.lib.menus import main_menu
                main_menu(self.handle)

            elif mode == 'tools':
                from resources.lib.menus import tools_menu
                tools_menu(self.handle)

            elif mode == 'jen':
                url = self.params.get('url', '')
                from resources.lib.parser import browse
                browse(self.handle, url, self.params)

            elif mode == 'tmdb':
                from resources.lib.tmdb import render as tmdb_render
                tmdb_render(self.handle, self.params)

            else:
                log('Unknown mode: %s' % mode, level='warning')
                succeeded = False

        except Exception:
            log(traceback.format_exc(), level='error')
            succeeded = False

        finally:
            xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded)
