"""
Encrypted key / credential store.

Credentials are kept in  <profile>/keys.dat  — NOT in settings.xml
(settings.xml is world-readable by every installed Kodi addon).

Cipher: XOR with a derived byte-stream.
Threat model: prevents casual plain-text inspection of the file on disk
and makes settings screenshots harmless.  Not designed to resist an
attacker who already has full filesystem access and the addon source.

Developer access is PIN-gated so Chains can manage keys himself without
touching any code or config files.
"""
import json
import os

import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.log import log

# ── cipher seed ───────────────────────────────────────────────────────────────
# Stored as ints — won't appear as a readable string in a hex editor.
# If you ever change this, existing keys.dat files become unreadable.
_SEED = bytes([
    0x43, 0x6C, 0x61, 0x73, 0x73, 0x79, 0x42, 0x61,   # ClassyBa
    0x73, 0x65, 0x4B, 0x65, 0x79, 0x53, 0x74, 0x6F,   # seKeySto
    0x72, 0x65, 0x32, 0x30, 0x32, 0x36, 0x21, 0x40,   # re2026!@
    0x23, 0x24, 0x25, 0x5E, 0x26, 0x2A, 0x28, 0x29,   # #$%^&*()
])

# Developer PIN — never stored, only used in-session to unlock the UI
_DEV_PIN = '1337'


# ── internal helpers ──────────────────────────────────────────────────────────

def _profile():
    path = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
    return path


def _keys_path():
    return os.path.join(_profile(), 'keys.dat')


def _xor(data: bytes) -> bytes:
    """XOR data against the repeating seed."""
    return bytes(b ^ _SEED[i % len(_SEED)] for i, b in enumerate(data))


def _load() -> dict:
    path = _keys_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'rb') as fh:
            return json.loads(_xor(fh.read()).decode('utf-8'))
    except Exception as e:
        log('keys _load error: %s' % e, level='error')
        return {}


def _save(store: dict):
    try:
        with open(_keys_path(), 'wb') as fh:
            fh.write(_xor(json.dumps(store, separators=(',', ':')).encode('utf-8')))
    except Exception as e:
        log('keys _save error: %s' % e, level='error')


# ── public API ────────────────────────────────────────────────────────────────

def get(key: str, default: str = '') -> str:
    """Retrieve a stored credential.  Use this anywhere you need a key."""
    return _load().get(key, default)


def set_key(key: str, value: str):
    """Store or update a credential."""
    store = _load()
    store[key] = value
    _save(store)


def delete(key: str):
    """Remove a credential by name."""
    store = _load()
    store.pop(key, None)
    _save(store)


def all_keys() -> list:
    """Return the list of stored key names (values are never exposed)."""
    return list(_load().keys())


# ── developer panel ───────────────────────────────────────────────────────────

def dev_panel():
    """
    PIN-gated credential management UI.
    Chains can add / update / delete keys here without touching any file.
    """
    pin = xbmcgui.Dialog().input('Developer PIN', type=xbmcgui.INPUT_NUMERIC)
    if pin != _DEV_PIN:
        xbmcgui.Dialog().notification(
            'Access Denied', 'Incorrect PIN',
            xbmcgui.NOTIFICATION_ERROR, 2000
        )
        return

    while True:
        key_names = all_keys()

        options  = ['[COLOR khaki][+]  Add / update key[/COLOR]']
        options += [
            '[COLOR lightblue]%s[/COLOR]  [COLOR dimgray]••••••••[/COLOR]' % k
            for k in key_names
        ]
        options += ['[COLOR red][x]  Close[/COLOR]']

        choice = xbmcgui.Dialog().select("Developer Keys", options)

        if choice == -1 or choice == len(options) - 1:
            break
        elif choice == 0:
            _ui_add_or_update()
        else:
            _ui_manage(key_names[choice - 1])


def _ui_add_or_update():
    key = xbmcgui.Dialog().input(
        'Key name  (e.g. tmdb, trakt_id, rd_token)',
        type=xbmcgui.INPUT_ALPHANUM
    )
    if not key:
        return
    key = key.strip().lower()
    value = xbmcgui.Dialog().input(
        'Value for [COLOR khaki]%s[/COLOR]' % key,
        type=xbmcgui.INPUT_ALPHANUM
    )
    if value:
        set_key(key, value)
        xbmcgui.Dialog().notification(
            'Key saved', '"%s" stored' % key,
            xbmcgui.NOTIFICATION_INFO, 2000
        )


def _ui_manage(key):
    action = xbmcgui.Dialog().select(
        'Key: %s' % key,
        ['Update value', 'Delete key', 'Cancel']
    )
    if action == 0:
        value = xbmcgui.Dialog().input(
            'New value for [COLOR khaki]%s[/COLOR]' % key,
            type=xbmcgui.INPUT_ALPHANUM
        )
        if value:
            set_key(key, value)
            xbmcgui.Dialog().notification(
                'Key updated', '"%s" updated' % key,
                xbmcgui.NOTIFICATION_INFO, 2000
            )
    elif action == 1:
        if xbmcgui.Dialog().yesno('Delete key', 'Delete [COLOR red]%s[/COLOR]?' % key):
            delete(key)
