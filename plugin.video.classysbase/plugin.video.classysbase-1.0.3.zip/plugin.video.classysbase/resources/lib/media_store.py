"""
media_store.py — Smart cache-aware media fetch layer.
======================================================

Single entry point for all TV show data fetches.  Applies content-type-aware
TTLs so ended shows don't trigger unnecessary API calls:

  Ended / Cancelled shows        → 30 days  (metadata is frozen)
  Active / Returning shows       → 6 hours  (new seasons may appear)
  Seasons of an ended show       → 30 days  (same logic, inherited)
  Seasons of an active show      → 24 hours
  Individual episode metadata    → 24 hours

Cache keys are explicit readable strings rather than opaque MD5 hashes:

  ms:tv:<show_id>              full show dict (status, genres, imdb, ...)
  ms:seasons:<show_id>         list of season dicts
  ms:season:<show_id>:<sn>     list of episode dicts for season <sn>

This makes granular invalidation straightforward — call invalidate() to
clear one show, one season, or everything.

TTL overrides (hours) can be set in config.json / the remote config URL:

  "cache_ttl_tv_ended"   →  default 720  (30 days)
  "cache_ttl_tv_active"  →  default   6
  "cache_ttl_episode"    →  default  24
"""

from resources.lib import cache as _cache
from resources.lib.log import log

# ── Default TTLs (hours) ───────────────────────────────────────────────────────

_DEFAULTS = {
    'tv_ended':   30 * 24,   # 720 h — show is done; seasons/eps won't change
    'tv_active':       6,    #   6 h — may be returning with new seasons
    'episode':        24,    #  24 h — episode metadata rarely changes
}

_ENDED_STATUSES = {'Ended', 'Canceled', 'Cancelled'}


# ── Helpers ────────────────────────────────────────────────────────────────────

def _ttl(category):
    """Return TTL in hours — config.json override, else built-in default."""
    try:
        from resources.lib import config
        val = config.get('cache_ttl_%s' % category)
        if val:
            return float(val)
    except Exception:
        pass
    return float(_DEFAULTS.get(category, 24))


def _is_ended(status):
    return str(status) in _ENDED_STATUSES


def _show_ttl(status):
    return _ttl('tv_ended') if _is_ended(status) else _ttl('tv_active')


# ── Cache key builders ─────────────────────────────────────────────────────────

def _show_key(show_id):
    return 'ms:tv:%s' % show_id


def _seasons_key(show_id):
    return 'ms:seasons:%s' % show_id


def _season_key(show_id, season_num):
    return 'ms:season:{}:{}'.format(show_id, season_num)


# ── Public fetch API ───────────────────────────────────────────────────────────

def fetch_show(show_id):
    """
    Fetch full TV show details with status-aware TTL.

    Includes: status, genres, tagline, runtime, imdb_id, number_of_seasons,
    number_of_episodes — all fields the TMDB /tv/{id} endpoint returns.

    Caching strategy
    ----------------
    - Read cached entry if age < tv_ended TTL (30 days).
    - If the cached entry says the show is active, additionally check
      against the shorter tv_active TTL (6 hours) and refetch if stale.
    - If the show has ended, the 30-day hit is always returned.

    Returns a normalised show dict, or None on error.
    """
    key = _show_key(show_id)

    # Try the cache using the long (ended) window — we refine below.
    cached = _cache.fetch(key, _ttl('tv_ended'))
    if cached:
        status = cached.get('status', '')
        if _is_ended(status):
            return cached                       # Ended: 30-day TTL is fine.
        # Active show: respect the shorter TTL.
        age = _cache.age_hours(key)
        if age is not None and age < _ttl('tv_active'):
            return cached                       # Still fresh.
        # Active TTL expired — fall through to refetch.

    # Fetch from TMDB, including external_ids for imdb_id in one call.
    from resources.lib.tmdb import _get, _norm_tv
    data = _get('/tv/%s' % show_id,
                extra_params={'append_to_response': 'external_ids'})
    if not data:
        return None

    result = _norm_tv(data)
    _cache.put(key, result)
    log('media_store: fetched show %s (%s, TTL %.0fh)'
        % (show_id, result.get('status', '?'), _show_ttl(result.get('status', ''))),
        level='debug')
    return result


def fetch_seasons(show_id):
    """
    Fetch the season list for a TV show.

    TTL is inherited from the show's status:
      ended show  → 30 days
      active show → 6 hours

    Returns list[season_dict] or None on error.
    """
    key = _seasons_key(show_id)

    # Determine show status (uses its own cache — no extra API call if warm).
    show  = fetch_show(show_id)
    if show is None:
        return None
    ended = _is_ended(show.get('status', ''))
    ttl   = _ttl('tv_ended') if ended else _ttl('tv_active')

    cached = _cache.fetch(key, ttl)
    if cached:
        return cached

    from resources.lib.tmdb import _get, _norm_season
    data = _get('/tv/%s' % show_id)
    if not data:
        return None

    seasons = data.get('seasons') or []
    result  = [_norm_season(s, data) for s in seasons]
    _cache.put(key, result)
    return result


def fetch_season(show_id, season_num):
    """
    Fetch all episodes for one season of a TV show.

    TTL:
      ended show   → 30 days (episode list is final)
      active show  → 24 hours (episode may have been added/corrected)

    Returns list[episode_dict] or None on error.
    """
    key = _season_key(show_id, season_num)

    show  = fetch_show(show_id)
    ended = _is_ended((show or {}).get('status', ''))
    ttl   = _ttl('tv_ended') if ended else _ttl('episode')

    cached = _cache.fetch(key, ttl)
    if cached:
        return cached

    from resources.lib.tmdb import _get, _norm_episode
    show_data = _get('/tv/%s' % show_id)
    ep_data   = _get('/tv/{}/season/{}'.format(show_id, season_num))
    if not ep_data or not show_data:
        return None

    result = [_norm_episode(e, show_data) for e in (ep_data.get('episodes') or [])]
    _cache.put(key, result)
    return result


# ── Cache invalidation ─────────────────────────────────────────────────────────

def invalidate(show_id, season_num=None):
    """
    Granular cache invalidation.

    invalidate(show_id)
        Clears the show detail, its season list, and all individual season
        episode lists.  Use when the user forces a refresh on a show.

    invalidate(show_id, season_num)
        Clears only the episode list for that one season — useful when
        episode progress/watched state is being tracked and you want a
        fresh fetch without disturbing other cached data.
    """
    if season_num is not None:
        _cache.delete(_season_key(show_id, season_num))
        log('media_store: invalidated s{} of show {}'.format(season_num, show_id))
    else:
        _cache.delete(_show_key(show_id))
        _cache.delete(_seasons_key(show_id))
        _cache.clear(key_prefix='ms:season:%s:' % show_id)
        log('media_store: invalidated show %s + all seasons' % show_id)
