"""
strings.py — Localised string IDs and a convenience lookup helper.

Usage:
    from resources.lib.strings import _, S_SETTINGS, S_CONNECT_TRAKT

    label = _(S_SETTINGS)          # returns the localised string for 32011
    label = _(S_WAITING_AUTH) % 42 # strings with % placeholders work normally
"""
import xbmcaddon

_addon = xbmcaddon.Addon()


def _(string_id):
    """Return the localised string for *string_id* (int 32000–32999)."""
    return _addon.getLocalizedString(string_id)


# ── General ────────────────────────────────────────────────────────────────────
S_ADDON_NAME        = 32000   # "Classy's Base"
S_ADDON_TRAKT       = 32001   # "Classy's Base — Trakt"
S_TRAKT             = 32002   # "Trakt"

# ── Menus ──────────────────────────────────────────────────────────────────────
S_TOOLS_SETTINGS    = 32010   # "Tools & Settings"
S_SETTINGS          = 32011   # "Settings"
S_CONNECT_TRAKT     = 32012   # "Connect Trakt"
S_TRAKT_CONNECTED   = 32013   # "Trakt  [Connected]"
S_NO_PLAYLISTS      = 32014   # "No content configured — add playlists to config.json"

# ── Trakt auth — configuration errors ─────────────────────────────────────────
S_NO_CLIENT_ID      = 32020   # "No Trakt Client ID is configured."
S_NO_CLIENT_ID_HINT = 32021   # "Set [B]trakt_client_id[/B] in …"
S_NO_CLIENT_SECRET  = 32022   # "No Trakt Client Secret is configured."
S_NO_SECRET_HINT    = 32023   # "Set [B]trakt_client_secret[/B] in …"
S_TRAKT_UNREACHABLE = 32024   # "Could not contact Trakt. …"

# ── Trakt auth — flow status messages ─────────────────────────────────────────
S_CODE_EXPIRED      = 32025   # "Code expired.  Please start again."
S_WAITING_AUTH      = 32026   # "Waiting for authorisation… (%ds remaining)"
S_CONNECTED_OK      = 32027   # "Connected!  Welcome to Trakt. ✓"
S_AUTH_FAILED       = 32028   # "Authorisation failed or was denied."
S_TRAKT_LINKED      = 32029   # "Trakt connected successfully!"

# ── Trakt auth — dialog labels ─────────────────────────────────────────────────
S_VISIT             = 32070   # "Visit:"
S_ENTER_CODE        = 32071   # "Enter code:"
S_SCAN_QR           = 32072   # "— or scan the QR code on the right —"
S_BACK_TO_CANCEL    = 32073   # "Press  [B]Back[/B]  to cancel"
S_WAITING_INIT      = 32074   # "Waiting for authorisation…"

# ── Trakt disconnect ───────────────────────────────────────────────────────────
S_DISCONNECT_Q      = 32030   # "Disconnect Trakt?"
S_DISCONNECT_HINT   = 32031   # "Your access token will be removed from this device."
S_DISCONNECTED      = 32032   # "Trakt disconnected."

# ── Trakt notifications ────────────────────────────────────────────────────────
S_MARKED_WATCHED    = 32033   # "Marked as Watched"
S_MARKED_UNWATCHED  = 32034   # "Marked as Unwatched"
S_MARK_FAILED       = 32035   # "Failed — check connection"
S_TMDB_NOT_FOUND    = 32036   # "Could not identify "%s" on TMDB"

# ── Context menus ──────────────────────────────────────────────────────────────
S_MARK_WATCHED_CM   = 32040   # "Mark as Watched [Trakt]"
S_TRAKT_WATCHED     = 32041   # "Trakt: Watched"
S_TRAKT_UNWATCHED   = 32042   # "Trakt: Unwatched"
S_TRAKT_SEASON_W    = 32043   # "Trakt: Season watched"
S_TRAKT_SEASON_UW   = 32044   # "Trakt: Season unwatched"
S_TRAKT_SHOW_W      = 32045   # "Trakt: Show watched"
S_TRAKT_SHOW_UW     = 32046   # "Trakt: Show unwatched"

# ── Scraper progress ───────────────────────────────────────────────────────────
S_SCRAPE_START      = 32050   # "Starting scrape …"
S_SCRAPE_DONE       = 32051   # "Done"

# ── Sources dialog ─────────────────────────────────────────────────────────────
S_SELECT_SOURCE     = 32060   # "Select Source"
S_ONE_SOURCE        = 32061   # "1 source available"
S_MANY_SOURCES      = 32062   # "%d sources available"

# ── Player ─────────────────────────────────────────────────────────────────────
S_SEARCHING         = 32080   # "Searching for sources for %s …"
S_NO_SOURCES        = 32081   # "No sources found for \"%s\"."
S_NO_STREAM         = 32082   # "Could not resolve a playable stream."
S_TMDB_BAD_KEY      = 32083   # "TMDB: invalid API key — check Settings"
