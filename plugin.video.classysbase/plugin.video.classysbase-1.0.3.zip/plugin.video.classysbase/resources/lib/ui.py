import xbmcgui

from resources.lib.strings import _, S_ADDON_NAME


def notify(msg, heading=None, icon=xbmcgui.NOTIFICATION_INFO, ms=3000):
    xbmcgui.Dialog().notification(heading or _(S_ADDON_NAME), msg, icon, ms)


def ok(msg, heading=None):
    xbmcgui.Dialog().ok(heading or _(S_ADDON_NAME), msg)
