"""
SQLite cache — single clean implementation.

No eval(), no string-formatted SQL, no repr() tricks.
Uses ast.literal_eval() for deserialisation and ? placeholders throughout.
"""
import ast
import hashlib
import os
import time

import xbmcaddon
import xbmcvfs

try:
    from sqlite3 import dbapi2 as sqlite
except ImportError:
    from pysqlite2 import dbapi2 as sqlite

from resources.lib.log import log

_CREATE = '''
    CREATE TABLE IF NOT EXISTS cache (
        key   TEXT PRIMARY KEY,
        value TEXT NOT NULL,
        ts    INTEGER NOT NULL
    )
'''


def _db_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(profile):
        os.makedirs(profile)
    return os.path.join(profile, 'cache.db')


def _connect():
    con = sqlite.connect(_db_path(), check_same_thread=False)
    con.execute(_CREATE)
    con.commit()
    return con


def get(func, timeout_hours, *args):
    """
    Return cached result of func(*args) if still fresh.
    Otherwise call func, persist the result, and return it.
    """
    key = _make_key(func, args)
    con = _connect()
    try:
        row = con.execute(
            'SELECT value, ts FROM cache WHERE key = ?', (key,)
        ).fetchone()

        if row:
            age_hours = (time.time() - row[1]) / 3600
            if age_hours < timeout_hours:
                try:
                    return ast.literal_eval(row[0])
                except Exception as e:
                    log('Cache deserialise error: %s' % e, level='warning')

        result = func(*args)
        if result is not None:
            con.execute(
                'INSERT OR REPLACE INTO cache (key, value, ts) VALUES (?, ?, ?)',
                (key, repr(result), int(time.time()))
            )
            con.commit()
        return result

    except Exception as e:
        log('Cache error: %s' % e, level='error')
        try:
            return func(*args)
        except Exception:
            return None
    finally:
        con.close()


def clear(key_prefix=None):
    """Clear all entries, or those whose key starts with key_prefix."""
    con = _connect()
    try:
        if key_prefix:
            con.execute('DELETE FROM cache WHERE key LIKE ?', (key_prefix + '%',))
        else:
            con.execute('DELETE FROM cache')
        con.commit()
    finally:
        con.close()


def _make_key(func, args):
    h = hashlib.md5()
    h.update(repr(func).encode('utf-8'))
    h.update(repr(args).encode('utf-8'))
    return h.hexdigest()


# ── Explicit-key API (used by media_store) ─────────────────────────────────────

def put(key, value):
    """Store *value* under an explicit string *key*. ts = now (creation time)."""
    con = _connect()
    try:
        con.execute(
            'INSERT OR REPLACE INTO cache (key, value, ts) VALUES (?, ?, ?)',
            (key, repr(value), int(time.time()))
        )
        con.commit()
    except Exception as e:
        log('Cache put error: %s' % e, level='error')
    finally:
        con.close()


def fetch(key, ttl_hours):
    """Return the cached value for *key* if age < ttl_hours, else None."""
    con = _connect()
    try:
        row = con.execute(
            'SELECT value, ts FROM cache WHERE key = ?', (key,)
        ).fetchone()
        if row and (time.time() - row[1]) / 3600 < ttl_hours:
            try:
                return ast.literal_eval(row[0])
            except Exception as e:
                log('Cache fetch deserialise error: %s' % e, level='warning')
        return None
    except Exception as e:
        log('Cache fetch error: %s' % e, level='error')
        return None
    finally:
        con.close()


def age_hours(key):
    """Return how many hours ago *key* was written, or None if not found."""
    con = _connect()
    try:
        row = con.execute(
            'SELECT ts FROM cache WHERE key = ?', (key,)
        ).fetchone()
        return (time.time() - row[0]) / 3600 if row else None
    except Exception:
        return None
    finally:
        con.close()


def delete(key):
    """Delete a single explicit-key entry."""
    con = _connect()
    try:
        con.execute('DELETE FROM cache WHERE key = ?', (key,))
        con.commit()
    except Exception as e:
        log('Cache delete error: %s' % e, level='error')
    finally:
        con.close()
