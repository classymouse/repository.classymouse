"""
trakt_auth.py — Trakt device-code auth dialog with QR code
============================================================

Entry point:  run_auth()

Flow
----
1.  Check that Client ID + Secret are set in Settings → Trakt.
2.  POST /oauth/device/code → get user_code, verification_url, device_code.
3.  Generate a QR code PNG (via bundled segno library).
4.  Show a custom WindowDialog with the QR image + instructions.
5.  Poll /oauth/device/token every `interval` seconds.
6.  On success: call trakt_api.save_token() and close the dialog.
7.  On cancel / timeout: close the dialog gracefully.

The QR code links to  https://trakt.tv/activate?code=XXXX  so the user
can scan with their phone and land directly on the correct Trakt page.
"""

import os
import struct
import time
import zlib

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from resources.lib.strings import (
    _, S_ADDON_NAME, S_ADDON_TRAKT, S_CONNECT_TRAKT,
    S_NO_CLIENT_ID, S_NO_CLIENT_ID_HINT,
    S_NO_CLIENT_SECRET, S_NO_SECRET_HINT, S_TRAKT_UNREACHABLE,
    S_CODE_EXPIRED, S_WAITING_AUTH, S_CONNECTED_OK, S_AUTH_FAILED,
    S_TRAKT_LINKED, S_VISIT, S_ENTER_CODE, S_SCAN_QR, S_BACK_TO_CANCEL,
    S_WAITING_INIT,
)

import resources.lib.trakt_api as trakt
from resources.lib.log import log

_ADDON    = xbmcaddon.Addon()
_ADDON_ID = _ADDON.getAddonInfo('id')


# ── QR code generation ─────────────────────────────────────────────────────────

def _ensure_lib_path():
    """Add resources/lib/ to sys.path so segno can resolve its own imports."""
    import sys
    lib_dir = os.path.join(
        xbmcvfs.translatePath('special://home/addons/%s/' % _ADDON_ID),
        'resources', 'lib',
    )
    if lib_dir not in sys.path:
        sys.path.insert(0, lib_dir)


def _make_qr(url):
    """
    Generate a QR code PNG for *url* and return the local file path.
    Returns '' on failure (dialog will still open, just without the image).
    """
    try:
        import hashlib
        _ensure_lib_path()
        import segno                                    # bundled at resources/lib/segno/
        profile = xbmcvfs.translatePath(
            'special://profile/addon_data/%s/' % _ADDON_ID
        )
        if not os.path.exists(profile):
            os.makedirs(profile)
        url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()[:8]
        path = os.path.join(profile, 'trakt_qr_%s.png' % url_hash)
        qr = segno.make(url, micro=False)
        qr.save(path, scale=10, border=2)
        return path
    except Exception as e:
        log('Trakt QR generation failed: %s' % e, level='warning')
        return ''


# ── background helpers ────────────────────────────────────────────────────────

def _fanart_path():
    """Return the addon's fanart.jpg path, or '' if it doesn't exist."""
    path = xbmcvfs.translatePath(
        'special://home/addons/%s/fanart.jpg' % _ADDON_ID
    )
    return path if os.path.exists(path) else ''


def _make_dim_png():
    """
    Write a 1×1 fully-opaque black PNG used as a fullscreen dim overlay.
    Returns '' on failure.
    """
    try:
        profile = xbmcvfs.translatePath(
            'special://profile/addon_data/%s/' % _ADDON_ID
        )
        if not os.path.exists(profile):
            os.makedirs(profile)
        path = os.path.join(profile, 'dialog_dim.png')
        if os.path.exists(path):
            return path

        def _chunk(ctype, data):
            crc = zlib.crc32(ctype + data) & 0xffffffff
            return struct.pack('>I', len(data)) + ctype + data + struct.pack('>I', crc)

        # IHDR: 1×1, 8-bit, RGBA (colour type 6)
        ihdr = struct.pack('>IIBBBBB', 1, 1, 8, 6, 0, 0, 0)
        # One scanline: filter(0) R(0) G(0) B(0) A(178) — black, ~70 % opaque
        raw  = zlib.compress(b'\x00\x00\x00\x00\xb2')
        png  = (b'\x89PNG\r\n\x1a\n'
                + _chunk(b'IHDR', ihdr)
                + _chunk(b'IDAT', raw)
                + _chunk(b'IEND', b''))
        with open(path, 'wb') as fh:
            fh.write(png)
        return path
    except Exception as e:
        log('Trakt dim PNG creation failed: %s' % e, level='warning')
        return ''


# ── custom dialog ──────────────────────────────────────────────────────────────

class _TraktAuthDialog(xbmcgui.WindowDialog):
    """
    Floating dialog (1280×720 virtual coordinate space) that shows:
      • QR code image  (right half)
      • user_code + verification URL  (left half)
      • status line that updates as we poll
    """

    # Dialog geometry (1280×720 virtual space)
    _DX, _DY, _DW, _DH = 255, 115, 770, 490

    def __init__(self, user_code, verify_url, qr_path, fanart, dim_path):
        super().__init__()
        self._canceled = False

        dx, dy, dw, dh = self._DX, self._DY, self._DW, self._DH

        # ── layer 1: fullscreen fanart ────────────────────────────────────
        if fanart:
            try:
                self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, fanart, aspectRatio=1))
            except Exception:
                pass

        # ── layer 2: fullscreen dark overlay (dims the fanart) ────────────
        if dim_path:
            try:
                self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, dim_path, aspectRatio=2))
            except Exception:
                pass

        # ── QR image (right column) ───────────────────────────────────────
        qr_size = 230
        qr_x    = dx + dw - qr_size - 25
        qr_y    = dy + (dh - qr_size) // 2
        if qr_path:
            try:
                self.addControl(xbmcgui.ControlImage(qr_x, qr_y, qr_size, qr_size, qr_path))
            except Exception:
                pass

        # ── left column ───────────────────────────────────────────────────
        lx = dx + 30
        lw = qr_x - lx - 20           # width available for text

        def _lbl(y, h, text, font='font13', color='0xFFFFFFFF'):
            try:
                self.addControl(xbmcgui.ControlLabel(lx, dy + y, lw, h, text,
                                                    font=font, textColor=color))
            except Exception:
                pass

        _lbl(30,  45, '[B]%s[/B]' % _(S_CONNECT_TRAKT),             font='font16')
        _lbl(85,  25, _(S_VISIT),                                    color='0xFFAAAAAA')
        _lbl(110, 25, '[B]%s[/B]' % verify_url,                      color='0xFFFFFFFF')
        _lbl(150, 25, _(S_ENTER_CODE),                               color='0xFFAAAAAA')
        _lbl(175, 55, '[COLOR=0xFFED1C24][B]%s[/B][/COLOR]' % user_code, font='font30')
        _lbl(245, 25, _(S_SCAN_QR),                                  color='0xFFAAAAAA')
        _lbl(285, 25, _(S_BACK_TO_CANCEL),                           color='0xFF888888')

        # ── status line (bottom) ──────────────────────────────────────────────────
        self._status = xbmcgui.ControlLabel(
            lx, dy + dh - 40, dw - 55, 28,
            '[COLOR=0xFFAAAAAA]%s[/COLOR]' % _(S_WAITING_INIT),
            font='font12',
        )
        try:
            self.addControl(self._status)
        except Exception:
            pass

    # -- event handlers -------------------------------------------------------

    def onAction(self, action):
        if action.getId() in (
            xbmcgui.ACTION_PREVIOUS_MENU,
            xbmcgui.ACTION_NAV_BACK,
            xbmcgui.ACTION_STOP,
        ):
            self._canceled = True
            self.close()

    def is_canceled(self):
        return self._canceled

    def set_status(self, msg):
        try:
            self._status.setLabel(f'[COLOR=0xFFAAAAAA]{msg}[/COLOR]')
        except Exception:
            pass


# ── public entry point ─────────────────────────────────────────────────────────

def run_auth():
    """
    Run the full Trakt device-code auth flow.

    Returns True on success, False on cancel or failure.
    """
    # 1. Validate credentials are present ----------------------------------
    from resources.lib import config as _cfg
    if not _cfg.get('trakt_client_id'):
        xbmcgui.Dialog().ok(
            _(S_ADDON_TRAKT),
            _(S_NO_CLIENT_ID) + '[CR]' + _(S_NO_CLIENT_ID_HINT),
        )
        return False

    if not _cfg.get('trakt_client_secret'):
        xbmcgui.Dialog().ok(
            _(S_ADDON_TRAKT),
            _(S_NO_CLIENT_SECRET) + '[CR]' + _(S_NO_SECRET_HINT),
        )
        return False

    # 2. Get device code ---------------------------------------------------
    code_data = trakt.get_device_code()
    if not code_data:
        xbmcgui.Dialog().ok(
            _(S_ADDON_TRAKT),
            _(S_TRAKT_UNREACHABLE),
        )
        return False

    user_code  = str(code_data['user_code'])
    verify_url = str(code_data.get('verification_url', 'https://trakt.tv/activate'))
    expires_in = int(code_data.get('expires_in', 600))
    interval   = max(int(code_data.get('interval', 5)), 5)

    # Deep-link: scan QR → lands directly on the pre-filled activation page
    auth_url = '{}?code={}'.format(verify_url, user_code)

    # 3. Prepare artwork ---------------------------------------------------
    qr_path  = _make_qr(auth_url)
    fanart   = _fanart_path()
    dim_path = _make_dim_png()

    # 4. Show dialog and poll Trakt ----------------------------------------
    dlg     = _TraktAuthDialog(user_code, verify_url, qr_path, fanart, dim_path)
    dlg.show()

    success     = False
    elapsed     = 0.0
    poll_timer  = float(interval)   # fire on first pass

    try:
        while not dlg.is_canceled():
            xbmc.sleep(500)
            elapsed    += 0.5
            poll_timer += 0.5

            if elapsed >= expires_in:
                dlg.set_status(_(S_CODE_EXPIRED))
                xbmc.sleep(2000)
                break

            if poll_timer < interval:
                continue

            poll_timer = 0.0
            result = trakt.poll_device_token(code_data)

            if result is False:
                remaining = int(expires_in - elapsed)
                dlg.set_status(_(S_WAITING_AUTH) % remaining)

            elif isinstance(result, dict):
                trakt.save_token(result)
                dlg.set_status(_(S_CONNECTED_OK))
                success = True
                xbmc.sleep(1800)
                break

            else:
                # None → expired / denied / network error
                dlg.set_status(_(S_AUTH_FAILED))
                xbmc.sleep(2000)
                break

    finally:
        try:
            dlg.close()
        except Exception:
            pass
        # Clean up the temp QR file
        if qr_path:
            try:
                os.remove(qr_path)
            except Exception:
                pass

    if success:
        xbmcgui.Dialog().notification(
            _(S_ADDON_NAME), _(S_TRAKT_LINKED),
            xbmcgui.NOTIFICATION_INFO, 3000,
        )
    return success
