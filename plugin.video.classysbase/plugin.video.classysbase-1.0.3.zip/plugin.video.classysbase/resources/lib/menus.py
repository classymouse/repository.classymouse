"""
Main menu — playlist entries driven by config.json.

To customise the menu for your fork, edit the "playlists" array in
resources/config.json (or your hosted remote config).  No Python changes
needed.
"""
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import config as _cfg
from resources.lib.infotag import VideoInfo
from resources.lib.strings import _, S_TOOLS_SETTINGS, S_SETTINGS, S_CONNECT_TRAKT, S_TRAKT_CONNECTED, S_NO_PLAYLISTS
from resources.lib.utils import build_url

_ADDON = xbmcaddon.Addon()
_ADDON_URL = sys.argv[0]
_ADDON_ID  = _ADDON.getAddonInfo('id')
_ART_BASE  = f'special://home/addons/{_ADDON_ID}/resources/artwork'
_SETTINGS_ICON = f'{_ART_BASE}/settings.png'
_TRAKT_ICON    = f'{_ART_BASE}/trakt.png'


def main_menu(handle):
    items = []

    for entry in _cfg.get('playlists', []):
        name, url, thumb, fanart = (
            entry.get('name', ''),
            entry.get('url', ''),
            entry.get('thumb', ''),
            entry.get('fanart', ''),
        )
        if not url:
            continue
        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': thumb, 'fanart': fanart})
        VideoInfo(li, title=name)
        items.append((build_url(_ADDON_URL, mode='jen', url=url), li, True))

    # Placeholder when no playlists are configured
    if not items:
        li = xbmcgui.ListItem(f'[COLOR dimgray]{_(S_NO_PLAYLISTS)}[/COLOR]')
        li.setProperty('IsPlayable', 'false')
        items.append(('', li, False))

    # Tools & Settings submenu at the bottom
    li = xbmcgui.ListItem('[COLOR dimgray]%s[/COLOR]' % _(S_TOOLS_SETTINGS))
    li.setArt({'thumb': _SETTINGS_ICON, 'icon': _SETTINGS_ICON})
    items.append((build_url(_ADDON_URL, mode='tools'), li, True))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.setContent(handle, 'files')


def tools_menu(handle):
    """Tools & Settings submenu: addon settings + Trakt auth."""
    import resources.lib.trakt_api as trakt
    items = []

    # ── Addon settings ────────────────────────────────────────────────────
    li = xbmcgui.ListItem(_(S_SETTINGS))
    li.setArt({'thumb': _SETTINGS_ICON, 'icon': _SETTINGS_ICON})
    items.append((build_url(_ADDON_URL, mode='settings'), li, False))

    # ── Trakt ─────────────────────────────────────────────────────────────
    if trakt.is_authenticated():
        label = '[COLOR lime]%s[/COLOR]' % _(S_TRAKT_CONNECTED)
        mode  = 'trakt_disconnect'
    else:
        label = _(S_CONNECT_TRAKT)
        mode  = 'trakt_auth'
    li = xbmcgui.ListItem(label)
    li.setArt({'thumb': _TRAKT_ICON, 'icon': _TRAKT_ICON})
    items.append((build_url(_ADDON_URL, mode=mode), li, False))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.setContent(handle, 'files')
