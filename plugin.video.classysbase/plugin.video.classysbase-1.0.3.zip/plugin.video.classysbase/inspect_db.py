"""
Register plugin.video.classysbase in Kodi's Addons33.db.
Run this once with Kodi closed. After running, start Kodi normally.
"""
import sqlite3, json
from datetime import datetime

DB       = r'C:\Users\fvanb\AppData\Roaming\Kodi\userdata\Database\Addons33.db'
ADDON_ID = 'plugin.video.classysbase'
VERSION  = '1.0.0'
NAME     = "Classy's Base"
SUMMARY  = "Classy's Base — curated media, clean code"
DESC     = "Clean, fast access to Chains' curated media playlists."
PATH     = r'C:\Users\fvanb\AppData\Roaming\Kodi\addons\plugin.video.classysbase'
NOW      = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

metadata = {
    "art": {
        "icon":   PATH + r'\icon.png',
        "fanart": PATH + r'\fanart.jpg',
    },
    "author": "Classy",
    "dependencies": [
        {"addonId": "xbmc.python",            "minversion": "3.0.0", "optional": False, "version": "3.0.0"},
        {"addonId": "script.module.requests", "minversion": "0.0.0", "optional": False, "version": "0.0.0"},
        {"addonId": "script.module.resolveurl","minversion": "0.0.0", "optional": False, "version": "0.0.0"},
    ],
    "disclaimer": "",
    "extensions": [
        {
            "children": [],
            "type": "xbmc.python.pluginsource",
            "values": [
                {"content": [{"key": "@library", "value": "default.py"}], "id": ""},
                {"content": [{"key": "provides",  "value": "video"}],     "id": "provides"},
            ],
        }
    ],
    "extrainfo": [
        {"key": "provides",             "value": "video"},
        {"key": "reuselanguageinvoker", "value": "false"},
    ],
    "icon":         PATH + r'\icon.png',
    "lifecycledesc": "",
    "lifecycletype": 0,
    "path":         PATH,
    "screenshots":  [],
    "size":         0,
}

con = sqlite3.connect(DB)

# Guard: don't double-insert
exists = con.execute("SELECT id FROM addons WHERE addonID=?", (ADDON_ID,)).fetchone()
if exists:
    print('Already registered (addons id=%d). Nothing to do.' % exists[0])
    con.close()
    raise SystemExit

# 1 — addons table
con.execute(
    'INSERT INTO addons (metadata, addonID, version, name, summary, news, description) '
    'VALUES (?, ?, ?, ?, ?, ?, ?)',
    (json.dumps(metadata, separators=(',', ':')), ADDON_ID, VERSION, NAME, SUMMARY, '', DESC)
)

# 2 — installed table
inst_exists = con.execute("SELECT id FROM installed WHERE addonID=?", (ADDON_ID,)).fetchone()
if not inst_exists:
    con.execute(
        'INSERT INTO installed (addonID, enabled, installDate, lastUpdated, lastUsed, origin, disabledReason) '
        'VALUES (?, 1, ?, NULL, NULL, ?, 0)',
        (ADDON_ID, NOW, '')
    )

con.commit()
con.close()
print('Done — %s v%s registered and enabled.' % (NAME, VERSION))
print('Start Kodi and find it under Add-ons > Video add-ons.')
