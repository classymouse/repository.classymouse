"""
Main menu — playlist entries driven by config.json.

To customise the menu for your fork, edit the "playlists" array in
resources/config.json (or your hosted remote config).  No Python changes
needed.
"""
import sys

import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib import config as _cfg
from resources.lib.infotag import VideoInfo
from resources.lib.strings import _, S_TOOLS_SETTINGS, S_SETTINGS, S_CONNECT_TRAKT, S_TRAKT_CONNECTED, S_NO_PLAYLISTS
from resources.lib.utils import build_url

_ADDON = xbmcaddon.Addon()
_ADDON_URL = sys.argv[0]
_ADDON_ID  = _ADDON.getAddonInfo('id')
_ART_BASE  = f'special://home/addons/{_ADDON_ID}/resources/artwork'
_SETTINGS_ICON = f'{_ART_BASE}/settings.png'
_TRAKT_ICON    = f'{_ART_BASE}/trakt.png'
_XML_ICON      = f'{_ART_BASE}/xml.png'


def main_menu(handle):
    items = []

    for entry in _cfg.get('playlists', []):
        name   = entry.get('name', '')
        thumb  = entry.get('thumb', '')
        fanart = entry.get('fanart', '')
        li = xbmcgui.ListItem(name)
        li.setArt({'thumb': thumb, 'fanart': fanart})
        VideoInfo(li, title=name)
        if entry.get('type') == 'local':
            root = entry.get('root', '')
            if not root:
                continue
            # Resolve special:// paths at menu-build time so the URL stays portable
            try:
                import xbmcvfs
                root = xbmcvfs.translatePath(root)
            except Exception:
                pass
            items.append((build_url(_ADDON_URL, mode='local', root=root), li, True))
        elif entry.get('type') == 'remote_xml':
            items.append((build_url(_ADDON_URL, mode='remote_xml'), li, True))
        else:
            url = entry.get('url', '')
            if not url:
                continue
            items.append((build_url(_ADDON_URL, mode='jen', url=url), li, True))

    # Auto-add XML catalog entries when xml_catalog_url is set and not already in playlists
    if (_cfg.get('xml_catalog_url') and
            not any(e.get('type') == 'remote_xml' for e in _cfg.get('playlists', []))):
        catalog_url = _cfg.get('xml_catalog_url', '').strip()
        try:
            from resources.lib.remote_xml_browser import get_catalog_items
            catalog_items = get_catalog_items(catalog_url)
        except Exception:
            catalog_items = []
        if catalog_items:
            items.extend(catalog_items)
        else:
            # Fallback: single folder entry if catalog unreachable
            li = xbmcgui.ListItem('Browse Online (XML)')
            li.setArt({'thumb': _XML_ICON, 'icon': _XML_ICON})
            VideoInfo(li, title='Browse Online (XML)')
            items.append((build_url(_ADDON_URL, mode='remote_xml'), li, True))

    # Placeholder when no playlists are configured
    if not items:
        li = xbmcgui.ListItem(f'[COLOR dimgray]{_(S_NO_PLAYLISTS)}[/COLOR]')
        li.setProperty('IsPlayable', 'false')
        items.append(('', li, False))

    # Tools & Settings submenu at the bottom
    li = xbmcgui.ListItem('[COLOR dimgray]%s[/COLOR]' % _(S_TOOLS_SETTINGS))
    li.setArt({'thumb': _SETTINGS_ICON, 'icon': _SETTINGS_ICON})
    items.append((build_url(_ADDON_URL, mode='tools'), li, True))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.setContent(handle, 'files')


def tools_menu(handle):
    """Tools & Settings submenu: addon settings + Trakt auth."""
    import resources.lib.trakt_api as trakt
    items = []

    # ── Addon settings ────────────────────────────────────────────────────
    li = xbmcgui.ListItem(_(S_SETTINGS))
    li.setArt({'thumb': _SETTINGS_ICON, 'icon': _SETTINGS_ICON})
    items.append((build_url(_ADDON_URL, mode='settings'), li, False))

    # ── Trakt ─────────────────────────────────────────────────────────────
    if trakt.is_authenticated():
        label = '[COLOR lime]%s[/COLOR]' % _(S_TRAKT_CONNECTED)
        mode  = 'trakt_disconnect'
    else:
        label = _(S_CONNECT_TRAKT)
        mode  = 'trakt_auth'
    li = xbmcgui.ListItem(label)
    li.setArt({'thumb': _TRAKT_ICON, 'icon': _TRAKT_ICON})
    items.append((build_url(_ADDON_URL, mode=mode), li, False))

    xbmcplugin.addDirectoryItems(handle, items, len(items))
    xbmcplugin.setContent(handle, 'files')
