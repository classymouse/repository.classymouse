"""
builder.py  —  Jen playlist crawler + TMDB enricher + XML exporter.

Pure Python — no Kodi UI imports.  Call from the Kodi dev panel or a
standalone CLI script.

Quickstart:
    from resources.lib.builder import build
    stats = build('https://example.com/main.txt',
                  output_dir='/path/to/xml/mylist',
                  tmdb_key='YOUR_KEY',
                  progress_cb=lambda pct, msg: print(pct, msg),
                  cancel_check=lambda: False)
"""
import datetime
import html
import json
import re
import shutil
import threading
import time
import unicodedata
import xml.etree.ElementTree as ET
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path
from xml.dom import minidom

import requests


# ── constants ──────────────────────────────────────────────────────────────────

TMDB_BASE        = 'https://api.themoviedb.org/3'
TRAKT_BASE       = 'https://api.trakt.tv'
LANGUAGE         = 'en-US'
MAX_DEPTH        = 6
FETCH_DELAY      = 1.0   # seconds between Jen playlist requests
MAX_RETRIES      = 4
WORKERS          = 5     # TMDB enrichment threads
TMDB_GENRE_PAGES = 3     # pages per genre/discover dir (20 items/page → 60 total)

# Manual overrides for titles TMDB's search index cannot find.
# Key: cleaned title (lowercase).  Value: (tmdb_id, 'movie'|'tv')
MANUAL_IDS = {
    'whores on fire': (1680815, 'movie'),
}


# ── Builder class ──────────────────────────────────────────────────────────────

class Builder:
    """
    One instance per build run.  Holds the HTTP session, rate limiter,
    and TMDB credentials so all methods share them cleanly.
    """

    def __init__(self, tmdb_key, trakt_key=''):
        self._tmdb_key  = tmdb_key
        self._trakt_key = trakt_key
        self._session   = requests.Session()
        self._session.headers['User-Agent'] = 'classysbase/builder (Kodi plugin)'
        self._rl        = _RateLimiter(rate=8.0)
        self._plock     = threading.Lock()   # print/progress lock
        self._clock     = threading.Lock()   # counter lock

    # ── TMDB API ───────────────────────────────────────────────────────────────

    def _get(self, endpoint, **params):
        """Thread-safe TMDB GET with rate-limiting and 429 back-off."""
        params.setdefault('api_key', self._tmdb_key)
        params.setdefault('language', LANGUAGE)
        url = f'{TMDB_BASE}/{endpoint.lstrip("/")}'
        for attempt in range(5):
            self._rl.acquire()
            r = self._session.get(url, params=params, timeout=10)
            if r.status_code == 429:
                wait = int(r.headers.get('Retry-After', 5)) + 1
                time.sleep(wait)
                continue
            r.raise_for_status()
            return r.json()
        r.raise_for_status()

    def _search(self, media_type, query, include_adult=False):
        endpoint = {
            'multi': '/search/multi',
            'tv':    '/search/tv',
            'movie': '/search/movie',
        }[media_type]
        data = self._get(endpoint, query=query, include_adult=include_adult)
        results = []
        for r in data.get('results', []):
            mt = r.get('media_type', media_type)
            if media_type == 'multi' and mt not in ('movie', 'tv'):
                continue
            title = r.get('title') or r.get('name') or ''
            date  = r.get('release_date') or r.get('first_air_date') or ''
            results.append({
                'tmdb_id':      r['id'],
                'media_type':   mt,
                'title':        title,
                'orig_title':   r.get('original_title') or r.get('original_name') or '',
                'year':         date[:4] if date else '',
                'popularity':   r.get('popularity', 0.0),
                'vote_avg':     r.get('vote_average', 0.0),
                'poster_path':  r.get('poster_path') or '',
                'backdrop_path': r.get('backdrop_path') or '',
            })
        return results

    def _fetch_direct(self, tmdb_id, media_type):
        ep = '/movie/' if media_type == 'movie' else '/tv/'
        r  = self._get(f'{ep}{tmdb_id}')
        title = r.get('title') or r.get('name') or ''
        date  = r.get('release_date') or r.get('first_air_date') or ''
        return {'tmdb_id': tmdb_id, 'media_type': media_type, 'title': title,
                'orig_title':    r.get('original_title') or r.get('original_name') or '',
                'year':          date[:4] if date else '',
                'popularity':    r.get('popularity', 0.0),
                'vote_avg':      r.get('vote_average', 0.0),
                'poster_path':   r.get('poster_path') or '',
                'backdrop_path': r.get('backdrop_path') or '',
                'match_score':   1.0}

    def best_match(self, title, media_type='tv'):
        """Search TMDB for title, return best-scored result dict or None."""
        clean  = _clean_title(title)
        manual = MANUAL_IDS.get(clean.lower()) or MANUAL_IDS.get(title.lower())
        if manual:
            return self._fetch_direct(*manual)

        def _try(mt, query, ia):
            return self._search(mt, query, include_adult=ia)

        hits = _try(media_type, clean, False) or _try(media_type, clean, True)
        if not hits and _AND_WORD.search(clean):
            alt  = _AND_WORD.sub('&', clean)
            hits = _try(media_type, alt, False) or _try(media_type, alt, True)
        if not hits and '&' in clean:
            alt  = clean.replace('&', 'and')
            hits = _try(media_type, alt, False) or _try(media_type, alt, True)
        if not hits and media_type != 'multi':
            hits = _try('multi', clean, False) or _try('multi', clean, True)
            if not hits and _AND_WORD.search(clean):
                alt  = _AND_WORD.sub('&', clean)
                hits = _try('multi', alt, False) or _try('multi', alt, True)
        if not hits:
            return None

        q = _norm(clean)
        best_score, best = _pick_best(q, hits)
        if best is None:
            return None
        best = dict(best)
        best['match_score'] = round(best_score, 3)
        return best

    # ── Jen crawler ────────────────────────────────────────────────────────────

    def _fetch_jen(self, url):
        """GET a Jen .txt URL with retry/backoff.  Returns text or None."""
        if not url.startswith(('http://', 'https://')):
            return None
        delay = FETCH_DELAY
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                r = self._session.get(url, timeout=15)
                if r.status_code == 429:
                    wait = max(int(r.headers.get('Retry-After', delay)), delay)
                    time.sleep(wait)
                    delay *= 2
                    continue
                r.raise_for_status()
                time.sleep(FETCH_DELAY)
                return r.text
            except Exception:
                if attempt == MAX_RETRIES:
                    return None
                time.sleep(delay)
                delay *= 2
        return None

    # ── Trakt / TMDB dir expanders ────────────────────────────────────────────

    def _expand_trakt_dir(self, url):
        """Fetch a Trakt list URL and return minimal item records (title+year).
        enrich() will title-search these and fill in TMDB ID + artwork.
        """
        if not self._trakt_key:
            return []
        try:
            r = self._session.get(
                url,
                headers={
                    'trakt-api-version': '2',
                    'trakt-api-key':     self._trakt_key,
                    'Content-Type':      'application/json',
                },
                timeout=15,
            )
            r.raise_for_status()
            items = []
            for entry in r.json():
                media_type = entry.get('type', 'movie')
                obj = entry.get(media_type) or entry.get('movie') or entry.get('show')
                if not obj or not obj.get('title'):
                    continue
                items.append({
                    'type':        'item',
                    'title':       obj['title'],
                    'link':        '',
                    'thumb':       '',
                    'fanart':      '',
                    'year':        str(obj.get('year', '')),
                    'season':      '',
                    'episode':     '',
                    'imdb':        '',
                    'tmdb':        '',
                    'description': '',
                    'sublinks':    [],
                    '_media_type': media_type,
                })
            return items
        except Exception:
            return []

    def _tmdb_result_to_item(self, r, media_type):
        """Convert a TMDB discover/list result dict into a builder item record."""
        title    = r.get('title') or r.get('name') or ''
        date     = r.get('release_date') or r.get('first_air_date') or ''
        poster   = r.get('poster_path') or ''
        backdrop = r.get('backdrop_path') or ''
        thumb    = f'https://image.tmdb.org/t/p/w500{poster}'       if poster   else ''
        fanart   = f'https://image.tmdb.org/t/p/original{backdrop}' if backdrop else ''
        if not thumb and fanart:
            thumb = fanart
        return {
            'type':        'item',
            'title':       title,
            'link':        '',
            'thumb':       thumb,
            'fanart':      fanart,
            'year':        date[:4] if date else '',
            'season':      '',
            'episode':     '',
            'imdb':        '',
            'tmdb':        str(r.get('id', '')),
            'description': (r.get('overview') or '').strip(),
            'sublinks':    [],
            '_media_type': media_type,
        }

    def _expand_tmdb_dir(self, spec):
        """Expand a <tmdb> dir spec into fully-enriched item records.

        Handles:
          list/<id>              → TMDB user list
          collection/<id>        → TMDB movie collection (franchise)
          genre/movies/<id>      → TMDB discover movies by genre
          genre/tv/<id>          → TMDB discover TV shows by genre
          genre/shows/<id>       → alias for genre/tv/<id>
          company/movies/<id>    → TMDB discover movies by production company
          company/movie/<id>     → alias for company/movies/<id>
          company/tv/<id>        → TMDB discover TV shows by production company
        """
        spec  = spec.strip()
        items = []
        try:
            if spec.startswith('collection/'):
                coll_id = spec.split('/', 1)[1]
                data = self._get(f'/collection/{coll_id}')
                for r in data.get('parts', []):
                    items.append(self._tmdb_result_to_item(r, 'movie'))
            elif spec.startswith('list/'):
                list_id = spec.split('/', 1)[1]
                data = self._get(f'/list/{list_id}')
                for r in data.get('items', []):
                    mt = r.get('media_type', 'movie')
                    if mt not in ('movie', 'tv'):
                        mt = 'movie'
                    items.append(self._tmdb_result_to_item(r, mt))
            elif spec.startswith('genre/'):
                parts = spec.split('/')  # ['genre', 'movies', '28']
                if len(parts) >= 3:
                    media_raw  = parts[1]
                    genre_id   = parts[2]
                    endpoint   = '/discover/movie' if media_raw == 'movies' else '/discover/tv'
                    media_type = 'movie'            if media_raw == 'movies' else 'tv'
                    for page in range(1, TMDB_GENRE_PAGES + 1):
                        data = self._get(
                            endpoint,
                            with_genres=genre_id,
                            page=page,
                            sort_by='popularity.desc',
                        )
                        for r in data.get('results', []):
                            items.append(self._tmdb_result_to_item(r, media_type))
                        if page >= data.get('total_pages', 1):
                            break
            elif spec.startswith('company/'):
                parts = spec.split('/')  # ['company', 'movies'|'movie'|'tv', '<id>']
                if len(parts) >= 3:
                    media_raw   = parts[1]
                    company_id  = parts[2]
                    endpoint    = '/discover/tv'    if media_raw == 'tv' else '/discover/movie'
                    media_type  = 'tv'              if media_raw == 'tv' else 'movie'
                    for page in range(1, TMDB_GENRE_PAGES + 1):
                        data = self._get(
                            endpoint,
                            with_companies=company_id,
                            page=page,
                            sort_by='popularity.desc',
                        )
                        for r in data.get('results', []):
                            items.append(self._tmdb_result_to_item(r, media_type))
                        if page >= data.get('total_pages', 1):
                            break
        except Exception as _e:
            import sys as _sys
            print(f'[builder] _expand_tmdb_dir failed for {spec!r}: {_e}', file=_sys.stderr)
        return items

    def crawl(self, root_url, progress_cb=None, cancel_check=None):
        """Recursively crawl a Jen playlist tree.  Returns (items, dir_artwork)."""
        visited    = set()
        items_out  = []
        dir_artwork = {}   # full path  →  {'thumb': str, 'fanart': str}

        def _walk(url, path, depth):
            url = url.strip()
            if not url or url in visited or depth > MAX_DEPTH:
                return
            if cancel_check and cancel_check():
                return
            visited.add(url)

            text = self._fetch_jen(url)
            if text is None:
                return

            records = _parse_jen(text)
            for item in records:
                if item['type'] == 'item':
                    item['_path']       = path
                    item['_source_url'] = url
                    items_out.append(item)
                else:
                    child_url  = (item['link'] or '').strip()
                    child_path = f'{path} / {item["title"]}' if path else item['title']
                    # Capture the dir's artwork (icon / fanart set on the folder entry)
                    if item.get('thumb') or item.get('fanart'):
                        dir_artwork[child_path] = {
                            'thumb':  item.get('thumb', ''),
                            'fanart': item.get('fanart', ''),
                        }
                    if child_url:
                        if progress_cb:
                            progress_cb(
                                min(28, 5 + len(visited) // 2),
                                f'Crawling... {len(items_out):,} items  {len(visited)} pages fetched',
                            )
                        _walk(child_url, child_path, depth + 1)
                    elif (item.get('trakt') or '').strip():
                        trakt_url = item['trakt'].strip()
                        if trakt_url == 'search':
                            items_out.append({
                                'type': 'item', 'title': item.get('title', 'Search Trakt'),
                                '_search_source': 'trakt',
                                '_path': child_path, '_source_url': url,
                                'link': '', 'thumb': item.get('thumb', ''),
                                'fanart': item.get('fanart', ''), 'year': '',
                                'season': '', 'episode': '', 'imdb': '', 'tmdb': '',
                                'description': '', 'sublinks': [],
                            })
                        else:
                            if progress_cb:
                                progress_cb(
                                    min(28, 5 + len(visited) // 2),
                                    f'Fetching Trakt: {item["title"]}',
                                )
                            for exp in self._expand_trakt_dir(trakt_url):
                                exp['_path']       = child_path
                                exp['_source_url'] = url
                                items_out.append(exp)
                    elif (item.get('tmdb') or '').strip():
                        spec = item['tmdb'].strip()
                        if spec == 'search':
                            _stitle = item.get('title', 'Search TMDB')
                            _stitle_l = _stitle.lower()
                            if 'movie' in _stitle_l:
                                _smtype = 'movie'
                            elif any(w in _stitle_l for w in ('show', 'serie', 'tv', 'series')):
                                _smtype = 'tv'
                            else:
                                _smtype = ''
                            items_out.append({
                                'type': 'item', 'title': _stitle,
                                '_search_source': 'tmdb',
                                '_search_media_type': _smtype,
                                '_path': child_path, '_source_url': url,
                                'link': '', 'thumb': item.get('thumb', ''),
                                'fanart': item.get('fanart', ''), 'year': '',
                                'season': '', 'episode': '', 'imdb': '', 'tmdb': '',
                                'description': '', 'sublinks': [],
                            })
                        elif '/' in spec:
                            if progress_cb:
                                progress_cb(
                                    min(28, 5 + len(visited) // 2),
                                    f'Fetching TMDB: {item["title"]}',
                                )
                            for exp in self._expand_tmdb_dir(spec):
                                exp['_path']       = child_path
                                exp['_source_url'] = url
                                items_out.append(exp)

        _walk(root_url, '', 0)
        return items_out, dir_artwork

    # ── Enricher ───────────────────────────────────────────────────────────────

    def enrich(self, all_entries, progress_cb=None, cancel_check=None):
        """Enrich entries in-place with TMDB metadata.  Returns hit counters."""
        # Clear bare-episode items before lookup
        for r in all_entries:
            if _BARE_EP_RE.match((r.get('title') or '').strip()):
                r['tmdb'] = r['year'] = r['season'] = r['episode'] = r['description'] = ''
                r.pop('_media_type', None)

        needs_lookup = [r for r in all_entries
                        if not r.get('imdb') and not r.get('tmdb') and r.get('title')
                        and not r.get('_search_source')]
        n      = max(len(needs_lookup), 1)
        counts = {'ok_hi': 0, 'ok_lo': 0, 'miss': 0}
        done   = [0]

        def _enrich_one(rec):
            if cancel_check and cancel_check():
                return
            title = (rec.get('title') or '').strip()

            # ── bare episode: "Episode 1" → look up by show name ─────────────
            if _BARE_EP_RE.match(title):
                show = _show_name_from_path(rec.get('_path', ''))
                if show:
                    hit = self.best_match(show, 'tv')
                    if hit:
                        rec['tmdb']        = str(hit['tmdb_id'])
                        rec['year']        = hit['year']
                        rec['_media_type'] = 'tv'
                        season_num = _season_from_path(rec.get('_path', ''))
                        ep_num     = _ep_num_from_title(title)
                        if season_num and ep_num:
                            try:
                                ep = self._get(f'/tv/{hit["tmdb_id"]}/season/{season_num}/episode/{ep_num}')
                                ep_title = (ep.get('name') or '').strip()
                                if ep_title:
                                    rec['title'] = ep_title
                                rec['description'] = (ep.get('overview') or '').strip()
                                still = ep.get('still_path')
                                if still:
                                    rec['thumb'] = f'https://image.tmdb.org/t/p/w500{still}'
                                air = ep.get('air_date') or ''
                                if air and len(air) >= 4:
                                    rec['year'] = air[:4]
                                rec['season']  = season_num
                                rec['episode'] = ep_num
                            except Exception:
                                pass   # unreleased / not on TMDB yet
                        with self._clock:
                            counts['ok_hi' if hit['match_score'] >= 0.8 else 'ok_lo'] += 1
                        return
                with self._clock:
                    counts['miss'] += 1
                return

            # ── regular title ─────────────────────────────────────────────────
            mt  = 'tv' if rec.get('season') else 'movie'
            hit = self.best_match(title, mt)
            if hit and rec.get('year'):
                try:
                    if abs(int(hit.get('year') or 0) - int(rec['year'])) > 2:
                        hit2 = self.best_match(f"{title} {rec['year']}", mt)
                        if hit2 and hit2['match_score'] >= hit['match_score']:
                            hit = hit2
                except (ValueError, TypeError):
                    pass
            if hit:
                rec['tmdb'] = str(hit['tmdb_id'])
                rec['year'] = rec['year'] or hit['year']
                if not rec.get('thumb') and hit.get('poster_path'):
                    rec['thumb']  = f'https://image.tmdb.org/t/p/w500{hit["poster_path"]}'
                if not rec.get('fanart') and hit.get('backdrop_path'):
                    rec['fanart'] = f'https://image.tmdb.org/t/p/original{hit["backdrop_path"]}'
                # Fallback: use backdrop as thumb when TMDB has no poster
                if not rec.get('thumb') and rec.get('fanart'):
                    rec['thumb'] = rec['fanart']
                # Preserve the actual TMDB media_type so TV shows aren't stamped as movies
                if hit.get('media_type') == 'tv':
                    rec['_media_type'] = 'tv'
                with self._clock:
                    counts['ok_hi' if hit['match_score'] >= 0.8 else 'ok_lo'] += 1
            else:
                with self._clock:
                    counts['miss'] += 1

        with ThreadPoolExecutor(max_workers=WORKERS) as pool:
            futures = {pool.submit(_enrich_one, r): r for r in needs_lookup}
            for fut in as_completed(futures):
                if cancel_check and cancel_check():
                    break
                done[0] += 1
                if progress_cb:
                    pct = 30 + (done[0] * 58 // n)
                    progress_cb(
                        pct,
                        f'Enriching... {done[0]:,}/{n:,}  '
                        f'ok:{counts["ok_hi"]}  ~:{counts["ok_lo"]}  miss:{counts["miss"]}',
                    )
                try:
                    fut.result()
                except Exception:
                    pass

        return counts

    # ── Exporter ───────────────────────────────────────────────────────────────

    def export(self, all_entries, output_dir, source_url, dir_artwork=None, progress_cb=None):
        """Write XML tree to output_dir.  Returns stats dict."""
        output_dir = Path(output_dir)
        if output_dir.exists():
            shutil.rmtree(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)

        by_section = defaultdict(list)
        for item in all_entries:
            by_section[item.get('_path', '') or '(root)'].append(item)

        index_rows = []
        for section_path, items in sorted(by_section.items()):
            parts    = [_safe_name(p) for p in section_path.split(' / ')]
            rel_path = (Path(*parts[:-1]) / (parts[-1] + '.xml')
                        if len(parts) > 1 else Path(parts[0] + '.xml'))
            out_path = output_dir / rel_path
            out_path.parent.mkdir(parents=True, exist_ok=True)
            needs_id = _write_section_xml(out_path, section_path, items, source_url)
            index_rows.append((section_path, rel_path, len(items), needs_id))

        # _index.xml
        idx = ET.Element('index')
        idx.set('generator', 'classysbase/builder.py')
        idx.set('source',   source_url)
        idx.set('sections', str(len(index_rows)))
        idx.set('items',    str(len(all_entries)))
        # <dir> elements — artwork for folder entries in the tree browser
        for dpath, art in sorted((dir_artwork or {}).items()):
            d = ET.SubElement(idx, 'dir')
            d.set('label', dpath)
            if art.get('thumb'):
                d.set('thumb', art['thumb'])
            if art.get('fanart'):
                d.set('fanart', art['fanart'])
        for sp, rp, n_items, n_miss in index_rows:
            s = ET.SubElement(idx, 'section')
            s.set('label',    sp)
            s.set('file',     str(rp).replace('\\', '/'))
            s.set('items',    str(n_items))
            s.set('needs_id', str(n_miss))
        (output_dir / '_index.xml').write_text(_pretty_xml(idx), encoding='utf-8')
        _update_catalog(output_dir, source_url, len(index_rows), len(all_entries))

        total_missing = sum(r[3] for r in index_rows)
        return {
            'sections':   len(index_rows),
            'items':      len(all_entries),
            'missing':    total_missing,
            'output_dir': str(output_dir),
        }

    # ── Full pipeline ──────────────────────────────────────────────────────────

    def build(self, url, output_dir, progress_cb=None, cancel_check=None):
        """Crawl → enrich → export.  Returns stats dict, or None if cancelled."""
        if progress_cb:
            progress_cb(2, 'Crawling playlist...')

        entries, dir_artwork = self.crawl(url, progress_cb=progress_cb, cancel_check=cancel_check)
        if cancel_check and cancel_check():
            return None

        if progress_cb:
            progress_cb(30, f'Enriching {len(entries):,} items with TMDB...')

        counts = self.enrich(entries, progress_cb=progress_cb, cancel_check=cancel_check)
        if cancel_check and cancel_check():
            return None

        # Backfill collection-level dir thumbs from the first enriched item's poster.
        # Section dirs (no direct items) keep their Chains fanart untouched.
        for entry in entries:
            path = entry.get('_path', '')
            if path and entry.get('thumb') and not dir_artwork.get(path, {}).get('thumb'):
                dir_artwork.setdefault(path, {})['thumb'] = entry['thumb']

        if progress_cb:
            progress_cb(90, 'Writing XML files...')

        stats = self.export(entries, output_dir, url, dir_artwork=dir_artwork, progress_cb=progress_cb)
        stats['counts'] = counts

        if progress_cb:
            progress_cb(100, f'Done - {stats["items"]:,} items  {stats["sections"]} sections')
        return stats


# ── Module-level convenience entry point ──────────────────────────────────────

def build(url, output_dir, tmdb_key, trakt_key='', progress_cb=None, cancel_check=None):
    """Convenience wrapper — creates a Builder and runs the full pipeline."""
    return Builder(tmdb_key, trakt_key=trakt_key).build(url, output_dir,
                                                        progress_cb=progress_cb,
                                                        cancel_check=cancel_check)


# ── Shared helpers (module-level, stateless) ───────────────────────────────────

class _RateLimiter:
    def __init__(self, rate=8.0):
        self._interval = 1.0 / rate
        self._lock     = threading.Lock()
        self._last_ts  = 0.0

    def acquire(self):
        while True:
            with self._lock:
                now = time.time()
                gap = self._interval - (now - self._last_ts)
                if gap <= 0:
                    self._last_ts = now
                    return
            time.sleep(max(0.001, gap))


_EDITION_TAGS = re.compile(
    r'\s*\((?:uncut|unrated|extended|theatrical|directors?\s*cut|special\s*edition|'
    r'remastered?|4k|uhd|hdr|bluray|blu[- ]?ray|dvdrip|webrip|web[- ]?dl|'
    r'bdrip|hdtv|x264|x265|hevc|avc|h\.?264|h\.?265|dubbed?|subbed?|multi|'
    r'dual\s*audio|limited|collectors?\s*edition|anniversary\s*edition|'
    r'final\s*cut|redux|restored?|criterion|screener)\)',
    re.IGNORECASE,
)
_YEAR_PAREN    = re.compile(r'\s*\(((?:19|20)\d{2})\)\s*$')
_AND_WORD      = re.compile(r'\band\b', re.IGNORECASE)
_BARE_EP_RE    = re.compile(r'^(?:episode|ep\.?)\s*\d+(?:\s*[~\-to]\s*\d+)?$', re.IGNORECASE)
_SEASON_SEG_RE = re.compile(r'^(?:season|series|part|vol(?:ume)?\.?|book)\s*\d+$', re.IGNORECASE)
_SEASON_NUM_RE = re.compile(r'^(?:season|series)\s*(\d+)$', re.IGNORECASE)
_EP_NUM_RE     = re.compile(r'^(?:episode|ep\.?)\s*(\d+)', re.IGNORECASE)


def _norm(s):
    s = unicodedata.normalize('NFD', s).encode('ascii', 'ignore').decode()
    return re.sub(r'\s+', ' ', re.sub(r'[^a-z0-9 ]', '', s.lower())).strip()


def _token_score(a, b):
    sa, sb = set(a.split()), set(b.split())
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def _pick_best(q, hits):
    scored = []
    for h in hits:
        score = max(_token_score(q, _norm(h['title'])),
                    _token_score(q, _norm(h['orig_title'])))
        scored.append((score, h.get('popularity', 0.0), h))
    if not scored:
        return 0.0, None
    scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
    return scored[0][0], scored[0][2]


def _clean_title(title):
    t = html.unescape(title)
    t = _KODI_TAG_RE.sub('', t)  # strip Kodi tags: [COLOR x], [/COLOR], [B] etc.
    t = _EDITION_TAGS.sub('', t)
    t = _YEAR_PAREN.sub('', t)
    return t.strip()


def _show_name_from_path(path):
    for seg in reversed(path.split(' / ')):
        seg = seg.strip()
        if seg and not _SEASON_SEG_RE.match(seg):
            return seg
    return ''


def _season_from_path(path):
    for seg in reversed(path.split(' / ')):
        m = _SEASON_NUM_RE.match(seg.strip())
        if m:
            return m.group(1)
    return ''


def _ep_num_from_title(title):
    m = _EP_NUM_RE.match(title.strip())
    return m.group(1) if m else ''


def _safe_name(s):
    s = _KODI_TAG_RE.sub('', s)  # strip Kodi tags before slugifying
    s = re.sub(r'[^a-z0-9]+', '_', s.strip().lower()).strip('_')
    return s or '_'


def _safe_url_name(url):
    stem = url.rstrip('/').split('/')[-1].replace('%20', ' ')
    stem = re.sub(r'\.txt$', '', stem, flags=re.IGNORECASE)
    return _safe_name(stem) or 'export'


def _jen_tag(block, tag):
    m = re.search(r'<' + re.escape(tag) + r'>\s*(.+?)\s*</' + re.escape(tag) + r'>',
                  block, re.DOTALL | re.IGNORECASE)
    return m.group(1).strip() if m else ''


_KODI_TAG_RE = re.compile(r'\[/?[A-Za-z]+[^\]]*\]')

def _strip_kodi_tags(s):
    """Remove Kodi formatting tags: [COLOR x], [/COLOR], [B], [I], etc."""
    return _KODI_TAG_RE.sub('', s).strip()


def _parse_jen(text):
    if text.startswith('\ufeff'):
        text = text[1:]
    records = []
    for rec_type, block in re.findall(
            r'<(item|dir|plugin)>(.*?)</(?:item|dir|plugin)>',
            text, re.DOTALL | re.IGNORECASE):
        _sublinks = re.findall(r'<sublink>\s*(.+?)\s*</sublink>', block, re.DOTALL)
        _raw_link  = _jen_tag(block, 'link') or _jen_tag(block, 'url')
        # Some Jen entries wrap <sublink> elements inside <link> — strip them
        if '<sublink>' in _raw_link.lower():
            _raw_link = _sublinks[0] if _sublinks else ''
        records.append({
            'type':        'dir' if rec_type.lower() in ('dir', 'plugin') else 'item',
            'title':       _strip_kodi_tags(_jen_tag(block, 'title') or _jen_tag(block, 'name')),
            'link':        _raw_link,
            'thumb':       _jen_tag(block, 'thumb') or _jen_tag(block, 'icon'),
            'fanart':      _jen_tag(block, 'fanart'),
            'year':        _jen_tag(block, 'year'),
            'season':      _jen_tag(block, 'season'),
            'episode':     _jen_tag(block, 'episode'),
            'imdb':        _jen_tag(block, 'imdb'),
            'tmdb':        _jen_tag(block, 'tmdb'),
            'trakt':       _jen_tag(block, 'trakt'),
            'description': _strip_kodi_tags(_jen_tag(block, 'description') or _jen_tag(block, 'plot')),
            'sublinks':    _sublinks,
        })
    return records


def _update_catalog(output_dir, source_url, sections, items):
    """Upsert this tree's entry in xml/index.xml — the top-level catalog.

    Reads name/thumb/fanart from resources/config.json by matching source_url
    against the playlists array.  Safe to call even if config.json is absent.
    """
    xml_dir      = Path(output_dir).parent
    catalog_path = xml_dir / 'index.xml'
    root_name    = Path(output_dir).name
    today        = datetime.date.today().isoformat()

    # Try to get display metadata from config.json
    name = root_name
    thumb = fanart = ''
    try:
        cfg_path = xml_dir.parent / 'resources' / 'config.json'
        with open(cfg_path, encoding='utf-8') as f:
            cfg = json.load(f)
        for pl in cfg.get('playlists', []):
            if pl.get('url', '').rstrip('/') == source_url.rstrip('/'):
                name   = pl.get('name', root_name)
                thumb  = pl.get('thumb', '')
                fanart = pl.get('fanart', '')
                break
    except Exception:
        pass

    # Load or create catalog root element
    if catalog_path.exists():
        try:
            cat = ET.parse(catalog_path).getroot()
        except Exception:
            cat = ET.Element('catalog')
    else:
        cat = ET.Element('catalog')

    cat.set('generator', 'classysbase/builder.py')
    cat.set('updated',   today)

    # Remove stale entry for this root (upsert)
    for existing in cat.findall('playlist'):
        if existing.get('root') == root_name:
            cat.remove(existing)

    pl_el = ET.SubElement(cat, 'playlist')
    pl_el.set('name',     name)
    pl_el.set('root',     root_name)
    pl_el.set('source',   source_url)
    if thumb:
        pl_el.set('thumb',  thumb)
    if fanart:
        pl_el.set('fanart', fanart)
    pl_el.set('sections', str(sections))
    pl_el.set('items',    str(items))
    pl_el.set('updated',  today)

    catalog_path.write_text(_pretty_xml(cat), encoding='utf-8')


def _pretty_xml(root_el):
    raw    = ET.tostring(root_el, encoding='unicode')
    pretty = minidom.parseString(raw).toprettyxml(indent='  ')
    return '<?xml version="1.0" encoding="UTF-8"?>\n' + '\n'.join(pretty.splitlines()[1:])


def _write_section_xml(path, section_label, items, source_url):
    root_el = ET.Element('playlist')
    root_el.set('generator', 'classysbase/builder.py')
    root_el.set('source',    source_url)
    root_el.set('section',   section_label)
    for rec in items:
        if rec.get('_search_source'):
            node = ET.SubElement(root_el, 'search')
            node.set('source', rec['_search_source'])
            node.set('label', rec.get('title', 'Search'))
            if rec.get('_search_media_type'):
                node.set('media_type', rec['_search_media_type'])
            if rec.get('thumb'):
                ET.SubElement(node, 'thumb').text = rec['thumb']
            if rec.get('fanart'):
                ET.SubElement(node, 'fanart').text = rec['fanart']
            continue
        node = ET.SubElement(root_el, 'item')
        if not rec.get('tmdb') and not rec.get('imdb'):
            node.set('needs_id', 'true')
        if rec.get('season') or rec.get('_media_type') == 'tv':
            node.set('media_type', 'tv')
        elif rec.get('year'):
            node.set('media_type', 'movie')
        else:
            node.set('media_type', 'unknown')
        for tag, key in [('title', 'title'), ('year', 'year'), ('imdb', 'imdb'),
                         ('tmdb', 'tmdb'), ('season', 'season'), ('episode', 'episode'),
                         ('description', 'description'), ('thumb', 'thumb'),
                         ('fanart', 'fanart'), ('link', 'link')]:
            val = rec.get(key, '')
            if val:
                ET.SubElement(node, tag).text = str(val)
        _link_val = rec.get('link', '')
        for sl in rec.get('sublinks', []):
            if sl and sl != _link_val:   # skip sublinks that duplicate <link>
                ET.SubElement(node, 'sublink').text = sl
    xml_text = _pretty_xml(root_el)
    path.write_text(xml_text, encoding='utf-8')
    return xml_text.count('needs_id="true"')
