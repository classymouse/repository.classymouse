"""
remote_xml_browser.py — browse Chains XML trees served over HTTPS.

Fetches the catalog from xml_catalog_url (config.json), then navigates
individual trees by fetching _index.xml and section .xml files on demand.
No local files required — works entirely over the network.

URL params (mode=remote_xml):
  root=   base URL of a tree, e.g. https://thechains24.com/xml/oneclick_main
           (absent = show catalog listing)
  path=   virtual breadcrumb, e.g. "4K Section / 4K Boxsets"
  file=   relative path to a leaf XML, e.g. "4k_section/300_collection.xml"
"""
import sys
import xml.etree.ElementTree as ET

import xbmcgui
import xbmcplugin

from resources.lib import config as _cfg
from resources.lib.infotag import VideoInfo
from resources.lib.log import log
from resources.lib.utils import build_url

_ADDON_URL = sys.argv[0]
_TIMEOUT   = 15   # seconds per request

# Default artwork — drop files in resources/artwork/ to activate
try:
    import xbmcaddon as _xa
    _ART = _xa.Addon('plugin.video.classysbase').getAddonInfo('path') + '/resources/artwork/'
except Exception:
    _ART = ''
_DEFAULT_POSTER = _ART + 'default_poster.jpg'
_DEFAULT_FANART = _ART + 'default_fanart.jpg'
_DEFAULT_FOLDER = _ART + 'default_folder.png'


# ── entry point ────────────────────────────────────────────────────────────────

def browse(handle, params):
    root     = params.get('root', '').rstrip('/')
    path     = params.get('path', '')
    xml_file = params.get('file', '')

    if not root:
        catalog_url = _cfg.get('xml_catalog_url', '').strip()
        if not catalog_url:
            xbmcgui.Dialog().notification(
                'Remote XML', 'xml_catalog_url not set in config',
                xbmcgui.NOTIFICATION_ERROR, 4000,
            )
            return
        _browse_catalog(handle, catalog_url)
    elif xml_file:
        _browse_leaf(handle, root, xml_file)
    else:
        _browse_tree(handle, root, path)


# ── catalog ────────────────────────────────────────────────────────────────────

def get_catalog_items(catalog_url):
    """Return list of (url, ListItem, True) for every playlist in the catalog.
    Returns an empty list if the catalog cannot be fetched."""
    root = _fetch_xml(catalog_url)
    if root is None:
        return []

    catalog_base = catalog_url.rsplit('/', 1)[0]   # https://thechains24.com/xml
    list_items   = []

    for pl in root.findall('playlist'):
        name      = pl.get('name',     pl.get('root', '?'))
        root_name = pl.get('root',     '')
        thumb     = pl.get('thumb',    '')
        fanart    = pl.get('fanart',   '')
        n_items   = pl.get('items',    '0')
        updated   = pl.get('updated',  '')

        if not root_name:
            continue

        base_url = '%s/%s' % (catalog_base, root_name)
        label    = name
        sub      = []
        if n_items:
            sub.append('%s items' % n_items)
        if updated:
            sub.append(updated)
        if sub:
            label += ' [COLOR dimgray](%s)[/COLOR]' % '  ·  '.join(sub)

        li = xbmcgui.ListItem(label)
        li.setArt({'thumb': thumb, 'fanart': fanart, 'poster': thumb})
        VideoInfo(li, title=name)
        url = build_url(_ADDON_URL, mode='remote_xml', root=base_url)
        list_items.append((url, li, True))

    return list_items


def _browse_catalog(handle, catalog_url):
    """List all available trees from the remote index.xml catalog."""
    list_items = get_catalog_items(catalog_url)
    if not list_items:
        xbmcgui.Dialog().notification(
            'Remote XML', 'Could not fetch catalog — server unreachable?',
            xbmcgui.NOTIFICATION_ERROR, 4000,
        )
        return

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'files')


# ── tree navigation ────────────────────────────────────────────────────────────

def _browse_tree(handle, base_url, path):
    """Navigate a remote tree — mirrors local_browser._render_tree."""
    index = _fetch_xml('%s/_index.xml' % base_url)
    if index is None:
        xbmcgui.Dialog().notification(
            'Remote XML', 'Could not fetch tree index',
            xbmcgui.NOTIFICATION_ERROR, 4000,
        )
        return

    all_sections = [
        (s.get('label', ''), s.get('file', ''), int(s.get('items', 0)))
        for s in index.findall('section')
    ]
    dir_art = {
        d.get('label', ''): {'thumb': d.get('thumb', ''), 'fanart': d.get('fanart', '')}
        for d in index.findall('dir')
        if d.get('label')
    }

    if path:
        prefix = path + ' / '
        sub = [(lbl, f, n) for lbl, f, n in all_sections
               if lbl == path or lbl.startswith(prefix)]
    else:
        sub = all_sections

    seen       = set()
    list_items = []

    for label, xml_rel, _n in sub:
        remainder    = label[len(path):].lstrip(' /') if path else label
        if not remainder:
            continue
        next_segment = remainder.split(' / ')[0]
        next_path    = (path + ' / ' + next_segment) if path else next_segment

        if next_path in seen:
            continue
        seen.add(next_path)

        exact        = [f for lbl, f, _ in sub if lbl == next_path]
        has_children = any(lbl.startswith(next_path + ' / ') for lbl, _, _ in sub)

        if exact and not has_children:
            count    = next((n for lbl, _, n in sub if lbl == next_path), 0)
            url      = build_url(_ADDON_URL, mode='remote_xml',
                                 root=base_url, file=exact[0])
            lbl_text = '{} [COLOR dimgray]({})[/COLOR]'.format(next_segment, count)
        else:
            branch_count = sum(n for lbl, _, n in sub
                               if lbl == next_path or lbl.startswith(next_path + ' / '))
            url      = build_url(_ADDON_URL, mode='remote_xml',
                                 root=base_url, path=next_path)
            lbl_text = '{} [COLOR dimgray]({})[/COLOR]'.format(next_segment, branch_count)

        li  = xbmcgui.ListItem(lbl_text)
        art    = dir_art.get(next_path, {})
        thumb  = art.get('thumb') or art.get('fanart', '') or _DEFAULT_FOLDER
        fanart = art.get('fanart', '') or _DEFAULT_FANART
        li.setArt({
            'icon':   thumb,
            'thumb':  thumb,
            'fanart': fanart,
            'poster': thumb,
        })
        VideoInfo(li, title=next_segment)
        list_items.append((url, li, True))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'files')


# ── leaf renderer ──────────────────────────────────────────────────────────────

def _browse_leaf(handle, base_url, file_rel):
    """Show playable items from a remote section XML — mirrors local_browser._render_leaf."""
    url  = '%s/%s' % (base_url, file_rel.lstrip('/'))
    root = _fetch_xml(url)
    if root is None:
        return

    has_episodes = False
    list_items   = []

    for item in root.findall('item'):
        title       = (item.findtext('title')       or '').strip()
        if not title:
            continue
        year        = (item.findtext('year')        or '').strip()
        tmdb_id     = (item.findtext('tmdb')        or '').strip()
        season      = (item.findtext('season')      or '').strip()
        episode     = (item.findtext('episode')     or '').strip()
        description = (item.findtext('description') or '').strip()
        thumb       = (item.findtext('thumb')       or '').strip()
        fanart      = (item.findtext('fanart')      or '').strip()
        link        = (item.findtext('link')        or '').strip()
        # Strip any leftover <sublink> wrapper that leaked into the link text
        if '<sublink>' in link.lower():
            import re as _re
            _m = _re.search(r'<sublink>\s*(.+?)\s*</sublink>', link, _re.DOTALL | _re.IGNORECASE)
            link = _m.group(1).strip() if _m else ''
        media_type  = item.get('media_type', 'movie')

        # Resolve plays: (display_title, url) — <link> preferred; fall back to <sublink> elements.
        # Multiple <sublink name="..."> → one list item each, labelled "Title - name".
        # No link + tmdb ID → scrape mode (metadata-only items from TMDB expansion).
        if link:
            plays = [(title, link)]
        else:
            subs = [(s.get('name', '').strip(), (s.text or '').strip())
                    for s in item.findall('sublink')
                    if (s.text or '').strip()]
            if len(subs) == 1:
                plays = [(title, subs[0][1])]
            elif len(subs) > 1:
                plays = [('%s - %s' % (title, name) if name else title, url)
                         for name, url in subs]
            else:
                plays = []   # no link, no sublinks → scrape

        if season:
            has_episodes = True

        vi_kwargs = dict(title=title, plot=description, media_type=media_type)
        if year:    vi_kwargs['year']       = int(year)
        if tmdb_id: vi_kwargs['unique_ids'] = {'tmdb': tmdb_id}
        if season:  vi_kwargs['season']     = int(season)
        if episode: vi_kwargs['episode']    = int(episode)

        if plays:
            for play_title, play_link in plays:
                li = xbmcgui.ListItem(play_title)
                li.setArt({'thumb': thumb or _DEFAULT_POSTER, 'fanart': fanart or _DEFAULT_FANART, 'poster': thumb or _DEFAULT_POSTER})
                li.setProperty('IsPlayable', 'true')
                VideoInfo(li, **vi_kwargs)
                play_url = build_url(_ADDON_URL, mode='play', url=play_link,
                                     name=play_title, thumb=thumb, fanart=fanart)
                list_items.append((play_url, li, False))
        elif tmdb_id or title:
            # TMDB-expanded item with no stream URL — TV → season browser, movie → scraper
            li = xbmcgui.ListItem(title)
            li.setArt({'thumb': thumb or _DEFAULT_POSTER, 'fanart': fanart or _DEFAULT_FANART, 'poster': thumb or _DEFAULT_POSTER})
            VideoInfo(li, **vi_kwargs)
            if media_type == 'tv' and tmdb_id:
                target_url = build_url(_ADDON_URL, mode='browse_seasons', title=title, year=year,
                                       tmdb_id=tmdb_id, thumb=thumb, fanart=fanart)
                list_items.append((target_url, li, True))
            else:
                li.setProperty('IsPlayable', 'true')
                target_url = build_url(_ADDON_URL, mode='scrape', title=title, year=year,
                                       media_type=media_type, tmdb_id=tmdb_id,
                                       thumb=thumb, fanart=fanart)
                list_items.append((target_url, li, False))

    # ── Search entries ─────────────────────────────────────────────────────
    for srch in root.findall('search'):
        source    = (srch.get('source')     or 'tmdb').lower()
        label     = (srch.get('label')       or 'Search %s' % source.upper()).strip()
        mtype     = (srch.get('media_type')  or '').lower()
        thumb     = (srch.findtext('thumb')  or '').strip()
        fanart    = (srch.findtext('fanart') or '').strip()
        li = xbmcgui.ListItem('[B]%s[/B]' % label)
        li.setArt({'thumb': thumb or _DEFAULT_POSTER, 'fanart': fanart or _DEFAULT_FANART})
        _sk = dict(mode='xml_search', source=source)
        if mtype:
            _sk['media_type'] = mtype
        search_url = build_url(_ADDON_URL, **_sk)
        list_items.append((search_url, li, True))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'episodes' if has_episodes else 'movies')


# ── HTTP helper ────────────────────────────────────────────────────────────────

def _fetch_xml(url):
    """GET *url*, parse as XML, return ET root element or None on any failure."""
    try:
        from resources.lib import client
        r = client.get(url, timeout=_TIMEOUT)
        if r is None:
            return None
        text = r.text
        if text.startswith('\ufeff'):
            text = text[1:]
        return ET.fromstring(text)
    except Exception as e:
        log('[classysbase] remote_xml: fetch failed %s — %s' % (url, e), level='error')
        return None
