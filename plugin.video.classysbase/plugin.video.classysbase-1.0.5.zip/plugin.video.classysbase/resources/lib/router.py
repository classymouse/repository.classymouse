"""
URL router — the single entry point for every addon call.

Responsibilities:
    • Parse argv[2] into a params dict
    • Dispatch to the correct handler by mode=
    • Guarantee endOfDirectory is always called (try/finally)
    • Keep play and dev_panel outside that guarantee (they manage their own response)
"""
import sys
import traceback
from urllib.parse import parse_qsl

import xbmc
import xbmcplugin

from resources.lib.log import log


class Router:
    def __init__(self, argv):
        self.handle = int(argv[1])
        self.params = dict(parse_qsl(argv[2].lstrip('?')))

    def run(self):
        mode = self.params.get('mode', 'main')

        # ── modes that manage their own response ──────────────────────────────

        if mode == 'play':
            from resources.lib.player import play
            play(self.handle, self.params)
            return

        if mode == 'scrape':
            from resources.lib.player import scrape_and_play
            scrape_and_play(self.handle, self.params)
            return

        if mode == 'dev_panel':
            from resources.lib.keys import dev_panel
            dev_panel()
            return

        if mode == 'settings':
            import xbmcaddon
            xbmcaddon.Addon().openSettings()
            # settings is dialog-only; signal empty directory so Kodi doesn't error
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'pick_color':
            import xbmcaddon
            from resources.lib.colorpicker import pick_color
            target  = self.params.get('target', '')
            _addon  = xbmcaddon.Addon()
            current = _addon.getSetting(target) if target else 'FFED1C24'
            result  = pick_color(current or 'FFED1C24')
            if result and target:
                _addon.setSetting(target, result)
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_auth':
            from resources.lib.trakt_auth import run_auth
            run_auth()
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_disconnect':
            import xbmcgui
            import resources.lib.trakt_api as trakt
            from resources.lib.strings import _, S_ADDON_NAME, S_DISCONNECT_Q, S_DISCONNECT_HINT, S_DISCONNECTED
            if xbmcgui.Dialog().yesno(
                _(S_ADDON_NAME),
                '{}[CR]{}'.format(_(S_DISCONNECT_Q), _(S_DISCONNECT_HINT)),
            ):
                trakt.disconnect()
                xbmcgui.Dialog().notification(
                    _(S_ADDON_NAME), _(S_DISCONNECTED),
                    xbmcgui.NOTIFICATION_INFO, 2500,
                )
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_toggle':
            import xbmcgui
            import resources.lib.trakt_api as trakt
            p       = self.params
            action  = p.get('action', 'watched')   # 'watched' | 'unwatched'
            mtype   = p.get('media_type', 'movie')
            tmdb_id = p.get('tmdb_id', '')
            show_id = p.get('show_id', tmdb_id)
            season  = p.get('season', 0)
            episode = p.get('episode', 0)

            ok = False
            if mtype == 'movie':
                ok = (trakt.mark_movie_watched(tmdb_id) if action == 'watched'
                        else trakt.mark_movie_unwatched(tmdb_id))
            elif mtype == 'episode':
                ok = (trakt.mark_episode_watched(show_id, season, episode) if action == 'watched'
                        else trakt.mark_episode_unwatched(show_id, season, episode))
            elif mtype == 'season':
                ok = (trakt.mark_season_watched(show_id, season) if action == 'watched'
                        else trakt.mark_season_unwatched(show_id, season))
            elif mtype == 'tvshow':
                ok = (trakt.mark_show_watched(tmdb_id) if action == 'watched'
                        else trakt.mark_show_unwatched(tmdb_id))

            from resources.lib.strings import _, S_TRAKT, S_MARKED_WATCHED, S_MARKED_UNWATCHED, S_MARK_FAILED
            notif_ok  = _(S_MARKED_WATCHED) if action == 'watched' else _(S_MARKED_UNWATCHED)
            if ok:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), notif_ok,
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_MARK_FAILED),
                    xbmcgui.NOTIFICATION_ERROR, 3000,
                )
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        if mode == 'trakt_mark':
            import xbmcgui
            import resources.lib.trakt_api as trakt
            from resources.lib.tmdb import tmdb_id_from_title
            p          = self.params
            action     = p.get('action', 'watched')
            mtype      = p.get('media_type', 'episode')
            tmdb_id    = p.get('tmdb_id', '')
            show_title = p.get('show_title', '')
            season     = p.get('season', '')
            episode    = p.get('episode', '')
            log('[classysbase] trakt_mark: show={!r} S{} E{} action={}'.format(show_title, season, episode, action))
            from resources.lib.strings import _, S_TRAKT, S_TMDB_NOT_FOUND, S_MARKED_WATCHED, S_MARKED_UNWATCHED, S_MARK_FAILED, S_MISSING_SEASON
            if mtype == 'episode' and episode and not season:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_MISSING_SEASON) % show_title,
                    xbmcgui.NOTIFICATION_WARNING, 4000,
                )
                log('[classysbase] trakt_mark: REJECTED — episode=%s but no season for %r' % (episode, show_title))
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
                return
            if not tmdb_id and show_title:
                resolved = tmdb_id_from_title(show_title, 'tv')
                tmdb_id = str(resolved) if resolved else ''
            log('[classysbase] trakt_mark: tmdb_id=%s' % tmdb_id)
            if not tmdb_id:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_TMDB_NOT_FOUND) % show_title,
                    xbmcgui.NOTIFICATION_WARNING, 3000,
                )
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
                return
            ok = False
            if mtype == 'episode' and season and episode:
                ok = (trakt.mark_episode_watched(tmdb_id, season, episode) if action == 'watched'
                      else trakt.mark_episode_unwatched(tmdb_id, season, episode))
            elif mtype == 'season' and season:
                ok = (trakt.mark_season_watched(tmdb_id, season) if action == 'watched'
                      else trakt.mark_season_unwatched(tmdb_id, season))
            elif mtype == 'tvshow':
                ok = (trakt.mark_show_watched(tmdb_id) if action == 'watched'
                      else trakt.mark_show_unwatched(tmdb_id))
            elif mtype == 'movie':
                ok = (trakt.mark_movie_watched(tmdb_id) if action == 'watched'
                      else trakt.mark_movie_unwatched(tmdb_id))
            log('[classysbase] trakt_mark: ok=%s' % ok)
            notif_ok2 = _(S_MARKED_WATCHED) if action == 'watched' else _(S_MARKED_UNWATCHED)
            if ok:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), notif_ok2,
                    xbmcgui.NOTIFICATION_INFO, 2000,
                )
                xbmc.executebuiltin('Container.Refresh')
            else:
                xbmcgui.Dialog().notification(
                    _(S_TRAKT), _(S_MARK_FAILED),
                    xbmcgui.NOTIFICATION_ERROR, 3000,
                )
            xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            return

        # ── directory modes — endOfDirectory guaranteed via finally ───────────

        succeeded = True
        try:
            if mode == 'main':
                from resources.lib.scraper import refresh_settings_labels
                refresh_settings_labels()
                from resources.lib.menus import main_menu
                main_menu(self.handle)

            elif mode == 'tools':
                from resources.lib.menus import tools_menu
                tools_menu(self.handle)

            elif mode == 'jen':
                url = self.params.get('url', '')
                from resources.lib.parser import browse
                browse(self.handle, url, self.params)

            elif mode == 'local':
                from resources.lib.local_browser import browse as local_browse
                local_browse(self.handle, self.params)

            elif mode == 'remote_xml':
                from resources.lib.remote_xml_browser import browse as remote_browse
                remote_browse(self.handle, self.params)

            elif mode == 'xml_search':
                source = self.params.get('source', 'tmdb')
                import xbmc as _xk
                import xbmcgui
                from resources.lib.utils import build_url
                kb = _xk.Keyboard('', 'Search %s' % source.upper())
                kb.doModal()
                if kb.isConfirmed() and kb.getText().strip():
                    _query = kb.getText().strip()
                    from resources.lib.tmdb import _get as _tmdb_get
                    from resources.lib.infotag import VideoInfo as _VI
                    _filter_mtype = self.params.get('media_type', '').lower()
                    _data    = _tmdb_get('/search/multi', {'query': _query, 'include_adult': 'false'})
                    _results = (_data.get('results', []) if _data else [])
                    _adu     = sys.argv[0]
                    _items   = []
                    for _r in _results:
                        _mtype = _r.get('media_type', '')
                        if _mtype not in ('movie', 'tv'):
                            continue
                        if _filter_mtype and _mtype != _filter_mtype:
                            continue
                        _tid   = str(_r.get('id', ''))
                        _name  = _r.get('title') or _r.get('name') or ''
                        _year  = str(_r.get('release_date', _r.get('first_air_date', ''))[:4]).strip()
                        _lbl   = '{} ({})'.format(_name, _year) if _year else _name
                        _thumb  = ('https://image.tmdb.org/t/p/w500'  + _r['poster_path'])  if _r.get('poster_path')  else ''
                        _fanart = ('https://image.tmdb.org/t/p/w1280' + _r['backdrop_path']) if _r.get('backdrop_path') else ''
                        _li = xbmcgui.ListItem(_lbl)
                        _li.setArt({'thumb': _thumb, 'poster': _thumb, 'fanart': _fanart})
                        _vi = dict(title=_name, media_type='tvshow' if _mtype == 'tv' else 'movie')
                        if _year:
                            try: _vi['year'] = int(_year)
                            except ValueError: pass
                        if _tid:
                            _vi['unique_ids'] = {'tmdb': _tid}
                        _VI(_li, **_vi)
                        if _mtype == 'tv':
                            _url = build_url(_adu, mode='tmdb', tmdb_type='tv', tmdb_id=_tid, name=_name)
                            _items.append((_url, _li, True))
                        else:
                            _li.setProperty('IsPlayable', 'true')
                            _url = build_url(_adu, mode='scrape', title=_name, year=_year,
                                             tmdb_id=_tid, thumb=_thumb, fanart=_fanart)
                            _items.append((_url, _li, False))
                    xbmcplugin.addDirectoryItems(self.handle, _items, len(_items))
                    if _filter_mtype == 'tv':
                        xbmcplugin.setContent(self.handle, 'tvshows')
                    elif _filter_mtype == 'movie':
                        xbmcplugin.setContent(self.handle, 'movies')
                    else:
                        xbmcplugin.setContent(self.handle, 'videos')
                else:
                    succeeded = False

            elif mode == 'tmdb':
                from resources.lib.tmdb import render as tmdb_render
                tmdb_render(self.handle, self.params)

            elif mode == 'trakt_person':
                import re as _re
                import xbmcgui
                from resources.lib import trakt_api as _trakt
                from resources.lib.tmdb import render as tmdb_render
                from resources.lib.utils import build_url as _burl
                _trakt_url = self.params.get('url', '')
                _slug_m    = _re.search(r'/people/([^/]+)/(movies|shows)', _trakt_url)
                if _slug_m:
                    _slug  = _slug_m.group(1)
                    _media = _slug_m.group(2)  # 'movies' or 'shows'
                    _tmdb_pid, _headshot = _trakt.person_resolve(_slug)
                    if _tmdb_pid:
                        # Full TMDB metadata path
                        _np = dict(self.params)
                        _np['tmdb_type'] = 'person'
                        _np['tmdb_id']   = '%s/%s' % (_media, _tmdb_pid)
                        tmdb_render(self.handle, _np)
                    else:
                        # Fallback: basic Trakt listing without artwork
                        _pitems = _trakt.person_items(_trakt_url)
                        _adu    = sys.argv[0]
                        _plist  = []
                        for _pi in _pitems:
                            _pt    = _pi['title']
                            _py    = _pi['year']
                            _ptid  = str(_pi['tmdb_id']) if _pi['tmdb_id'] else ''
                            _pli   = xbmcgui.ListItem('{} ({})'.format(_pt, _py) if _py else _pt)
                            _isdir = _pi['media_type'] == 'tvshow'
                            _tgt   = (_burl(_adu, mode='tmdb', tmdb_type='tv', tmdb_id=_ptid, name=_pt)
                                      if _isdir and _ptid
                                      else _burl(_adu, mode='scrape', title=_pt, year=_py,
                                                 tmdb_id=_ptid, media_type='movie'))
                            if _tgt:
                                _plist.append((_tgt, _pli, _isdir))
                        xbmcplugin.addDirectoryItems(self.handle, _plist, len(_plist))

            elif mode == 'browse_seasons':
                import xbmcgui
                from resources.lib.tmdb import tv_seasons as _tv_seasons
                from resources.lib.infotag import VideoInfo
                from resources.lib.utils import build_url as _burl
                _p     = self.params
                _tid   = _p.get('tmdb_id', '')
                _title = _p.get('title', '')
                _year  = _p.get('year', '')
                _thumb = _p.get('thumb', '')
                _fanrt = _p.get('fanart', '')
                _seasons = _tv_seasons(_tid) if _tid else None
                if _seasons:
                    _slist = []
                    for _s in _seasons:
                        _sn    = _s['season_number']
                        _sname = _s['name']
                        _sli   = xbmcgui.ListItem(_sname)
                        _sli.setArt({'thumb':   _s.get('thumb')  or _thumb,
                                     'fanart':  _s.get('fanart') or _fanrt,
                                     'poster':  _s.get('thumb')  or _thumb})
                        VideoInfo(_sli, title=_sname, media_type='season',
                                  year=_s.get('year', ''), plot=_s.get('plot', ''),
                                  season=_sn, tvshowtitle=_title)
                        _surl = _burl(sys.argv[0], mode='browse_episodes',
                                      tmdb_id=_tid, title=_title, year=_year,
                                      season=str(_sn), thumb=_thumb, fanart=_fanrt)
                        _slist.append((_surl, _sli, True))
                    xbmcplugin.setContent(self.handle, 'seasons')
                    xbmcplugin.addDirectoryItems(self.handle, _slist, len(_slist))
                else:
                    succeeded = False

            elif mode == 'browse_episodes':
                import xbmcgui
                from resources.lib.tmdb import season_episodes_cached as _sea_eps
                from resources.lib.infotag import VideoInfo
                from resources.lib.utils import build_url as _burl
                _p     = self.params
                _tid   = _p.get('tmdb_id', '')
                _title = _p.get('title', '')
                _year  = _p.get('year', '')
                _sn    = _p.get('season', '1')
                _thumb = _p.get('thumb', '')
                _fanrt = _p.get('fanart', '')
                _eps   = _sea_eps(_tid, _sn) if _tid else None
                if _eps:
                    _elist = []
                    for _e in _eps:
                        _en     = _e['episode_number']
                        _etitle = _e.get('title') or ('Episode %d' % _en)
                        _label  = 'S%02dE%02d - %s' % (int(_sn), _en, _etitle)
                        _eli    = xbmcgui.ListItem(_label)
                        _eli.setArt({'thumb':  _e.get('thumb')  or _thumb,
                                     'fanart': _e.get('fanart') or _fanrt,
                                     'poster': _e.get('thumb')  or _thumb})
                        _eli.setProperty('IsPlayable', 'true')
                        VideoInfo(_eli, title=_etitle, media_type='episode',
                                  year=_e.get('year', ''), plot=_e.get('plot', ''),
                                  season=int(_sn), episode=_en,
                                  tvshowtitle=_title, rating=_e.get('rating', 0),
                                  first_aired=_e.get('first_aired', ''))
                        _eurl = _burl(sys.argv[0], mode='scrape',
                                      title=_title, year=_year, media_type='episode',
                                      tmdb_id=_tid, season=_sn, episode=str(_en),
                                      ep_title=_etitle, plot=_e.get('plot', ''),
                                      thumb=_thumb, fanart=_fanrt)
                        _elist.append((_eurl, _eli, False))
                    xbmcplugin.setContent(self.handle, 'episodes')
                    xbmcplugin.addDirectoryItems(self.handle, _elist, len(_elist))
                else:
                    succeeded = False

            else:
                log('Unknown mode: %s' % mode, level='warning')
                succeeded = False

        except Exception:
            log(traceback.format_exc(), level='error')
            succeeded = False

        finally:
            xbmcplugin.endOfDirectory(self.handle, succeeded=succeeded)
