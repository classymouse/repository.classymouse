"""
scraper.py — External scraper module adapter
=============================================

Bridges Classy's Base with installed third-party scraper modules so that
TMDB movie items can be resolved to actual stream URLs.

Supported module families
-------------------------
Convention A  (top-level sources() function, identical API):
    script.module.gearsscrapers
    script.module.viperscrapers
    script.module.homelanderscrapers

Convention B  (CocoScrapers flat provider list):
    script.module.cocoscrapers

Each individual provider class exposes:
    source().sources(data, hostDict) → list of source dicts

Returned source dict keys of interest:
    url      — magnet: URI or direct stream URL
    quality  — '4K' | '1080p' | '720p' | 'SD' | 'CAM'
    provider — scraper name string
    seeders  — int (torrent sources)
"""

import sys
import os
import importlib
from threading import Thread, Lock

import xbmcaddon

from resources.lib.log import log
from resources.lib import source_utils

# ── Known scraper modules ──────────────────────────────────────────────────────

_SCRAPERS = {
    'script.module.gearsscrapers': {
        'label':       'GearScrapers',
        'pkg':         'gearsscrapers',
        'convention':  'A',
        'setting_key': 'gears',
    },
    'script.module.viperscrapers': {
        'label':       'ViperScrapers',
        'pkg':         'viperscrapers',
        'convention':  'A',
        'setting_key': 'viper',
    },
    'script.module.homelanderscrapers': {
        'label':       'HomelanderScrapers',
        'pkg':         'homelanderscrapers',
        'convention':  'A',
        'setting_key': 'homelander',
    },
    'script.module.cocoscrapers': {
        'label':       'CocoScrapers',
        'pkg':         'cocoscrapers',
        'convention':  'B',
        'setting_key': 'coco',
    },
}

_QUALITY_RANK    = {'4K': 0, '2160p': 0, '1080p': 1, '720p': 2, 'SD': 3, 'CAM': 4}
_PROVIDER_TIMEOUT = 20   # seconds — per-module join timeout

# Quality filter maps  (settings enum index → _QUALITY_RANK threshold)
# max_q  "Any|1080p|720p"      → ceiling: exclude sources *better than* threshold
# min_q  "Any|720p|1080p|4K"  → floor:   exclude sources *worse  than* threshold
_MAX_Q_MAP = {'0': None, '1': 1, '2': 2}   # None = no ceiling
_MIN_Q_MAP = {'0': None, '1': 2, '2': 1, '3': 0}   # None = no floor

# ── Debrid service registry (read from resolveurl — no duplicate config) ──────

# Maps scraper 'debrid' field values → (short_label, resolver_id)
_DEBRID_ALIASES = {
    'premiumize':    ('PREM', 'PremiumizeMeResolver'),
    'premiumize.me': ('PREM', 'PremiumizeMeResolver'),
    'pm':            ('PREM', 'PremiumizeMeResolver'),
    'alldebrid':     ('AD',   'AllDebridResolver'),
    'all_debrid':    ('AD',   'AllDebridResolver'),
    'ad':            ('AD',   'AllDebridResolver'),
    'realdebrid':    ('RD',   'RealDebridResolver'),
    'real_debrid':   ('RD',   'RealDebridResolver'),
    'real-debrid':   ('RD',   'RealDebridResolver'),
    'rd':            ('RD',   'RealDebridResolver'),
    'torbox':        ('TB',   'TorBoxResolver'),
    'tb':            ('TB',   'TorBoxResolver'),
    'debridlink':    ('DL',   'DebridLinkResolver'),
    'debrid-link':   ('DL',   'DebridLinkResolver'),
    'dl':            ('DL',   'DebridLinkResolver'),
}

# resolver_id → credential setting key in resolveurl
_RESOLVER_CREDS = {
    'PremiumizeMeResolver': ('PremiumizeMeResolver_enabled', 'PremiumizeMeResolver_token',  'PREM'),
    'AllDebridResolver':    ('AllDebridResolver_enabled',    'AllDebridResolver_token',     'AD'),
    'RealDebridResolver':   ('RealDebridResolver_enabled',   'RealDebridResolver_token',    'RD'),
    'TorBoxResolver':       ('TorBoxResolver_enabled',       'TorBoxResolver_apikey',       'TB'),
    'DebridLinkResolver':   ('DebridLinkResolver_enabled',   'DebridLinkResolver_token',    'DL'),
}


def get_active_debrids():
    """
    Read resolveurl settings and return a dict of active (enabled + credentialed)
    debrid services: {resolver_id: short_label}.
    Returns {} if resolveurl is not installed.
    """
    try:
        ru = xbmcaddon.Addon('script.module.resolveurl')
    except Exception:
        return {}
    active = {}
    for resolver_id, (enabled_key, cred_key, short) in _RESOLVER_CREDS.items():
        try:
            if ru.getSetting(enabled_key) == 'true' and (ru.getSetting(cred_key) or ''):
                active[resolver_id] = short
        except Exception:
            pass
    return active

# ── Public API ─────────────────────────────────────────────────────────────────

def detect_installed():
    """Return addon IDs of recognised scraper modules that are installed."""
    out = []
    for addon_id in _SCRAPERS:
        try:
            xbmcaddon.Addon(addon_id)
            out.append(addon_id)
        except Exception:
            pass
    return out


def _count_providers(addon_ids):
    """Quick probe — return the total number of individual providers across all
    active scraper modules (used to show accurate progress fractions)."""
    total = 0
    for addon_id in addon_ids:
        info = _SCRAPERS.get(addon_id)
        if not info:
            continue
        lib_path = _lib_path(addon_id)
        if not lib_path:
            continue
        _ensure_path(lib_path)
        try:
            if info['convention'] == 'A':
                pkg = importlib.import_module(info['pkg'])
                total += len(pkg.sources(ret_all=True))
            elif info['convention'] == 'B':
                from cocoscrapers.sources_cocoscrapers import all_providers
                total += len(all_providers)
        except Exception:
            total += 1   # assume at least 1 if we can't probe
    return max(total, 1)


def refresh_settings_labels():
    """
    Probe each known scraper module and update its three settings entries:

        _{key}_available   hidden bool  — drives enable= on the checkbox
        use_{pkg}          checkbox     — auto-unchecked when module is gone
        _{key}_status      readonly text — coloured Installed / Not installed

    Called from the main menu so the user always sees current availability.
    """
    addon = xbmcaddon.Addon()
    for addon_id, info in _SCRAPERS.items():
        key = info['setting_key']
        pkg = info['pkg']
        try:
            xbmcaddon.Addon(addon_id)
            installed = True
        except Exception:
            installed = False

        addon.setSetting(f'_{key}_available', 'true' if installed else 'false')
        addon.setSetting(
            f'_{key}_status',
            '[COLOR lawngreen]Installed[/COLOR]' if installed
            else '[COLOR red]Not installed[/COLOR]',
        )
        # Auto-disable the toggle if the module has been uninstalled
        if not installed:
            addon.setSetting(f'use_{pkg}', 'false')


def scrape(title, year, media_type='movie', tmdb_id=None,
           season=None, episode=None, tvshowtitle=None,
           addon_ids=None, progress_dialog=None):
    """
    Scrape stream sources for a movie or TV episode.

    Parameters
    ----------
    title           : str
    year            : str or int
    media_type      : 'movie' | 'episode'
    tmdb_id         : str or None
    season          : str or int or None  (TV only)
    episode         : str or int or None  (TV only)
    tvshowtitle     : str or None          (TV only — show name)
    addon_ids       : list of addon IDs to use, or None → all installed
    progress_dialog : xbmcgui.DialogProgress or None (for live progress updates)

    Returns
    -------
    list of {'label': str, 'url': str, 'quality': str}
        Sorted best quality first (4K → 1080p → 720p → SD).
        Empty list when nothing was found or no scrapers are active.
    """
    if addon_ids is None:
        addon_ids = detect_installed()

    if not addon_ids:
        log('scraper: no scraper modules active', level='warning')
        return []

    data = {
        'title':      str(title),
        'year':       str(year),
        'aliases':    [str(title)],
        'media_type': str(media_type),
        'imdb':       '',
        'tmdb':       str(tmdb_id or ''),
    }
    if tvshowtitle is not None:
        data['tvshowtitle'] = str(tvshowtitle)
        data['aliases']     = [str(tvshowtitle)]
    if season is not None:
        data['season'] = str(season)
    if episode is not None:
        data['episode'] = str(episode)

    # Resolve IMDB ID from TMDB — required by Comet, Torrentio, and similar
    # API-based providers that use IMDB IDs for lookups.
    if data['tmdb'] and not data['imdb']:
        try:
            from resources.lib.tmdb import get_imdb_id as _get_imdb
            _mtype = 'tv' if media_type == 'episode' else 'movie'
            data['imdb'] = _get_imdb(data['tmdb'], _mtype) or ''
            if data['imdb']:
                log('scraper: resolved imdb=%s for tmdb=%s' % (data['imdb'], data['tmdb']))
        except Exception:
            pass

    all_raw = []
    lock    = Lock()

    # ── Dynamic progress ───────────────────────────────────────────────────────
    if progress_dialog:
        _n_total    = _count_providers(addon_ids)
        _prog_done  = [0]
        _prog_found = [0]
        _prog_lock  = Lock()

        def _on_provider_done(n_new=0):
            with _prog_lock:
                _prog_done[0]  += 1
                _prog_found[0] += n_new
                done  = _prog_done[0]
                found = _prog_found[0]
            pct = 5 + int(done / _n_total * 90)
            progress_dialog.update(
                pct,
                'Scraping\u2026  (%d / %d)  \u2014  %d source%s found'
                % (done, _n_total, found, 's' if found != 1 else ''),
            )

        progress_dialog.update(4, 'Scraping\u2026  (0 / %d)' % _n_total)
    else:
        _on_provider_done = None

    def _run(idx, addon_id):
        try:
            raw = _scrape_one(addon_id, data, _on_provider_done)
            if raw:
                with lock:
                    all_raw.extend(raw)
        except Exception as exc:
            log('scraper [{}] error: {}'.format(addon_id, exc), level='warning')

    threads = [Thread(target=_run, args=(i, aid)) for i, aid in enumerate(addon_ids)]
    for t in threads:
        t.start()
    for t in threads:
        t.join()

    if progress_dialog:
        from resources.lib.strings import _, S_SCRAPE_DONE
        progress_dialog.update(100, _(S_SCRAPE_DONE))

    # Read quality filter settings and apply them before returning
    is_tv = media_type == 'episode'
    addon = xbmcaddon.Addon()
    max_q_rank = _MAX_Q_MAP.get(addon.getSetting('max_q_tv' if is_tv else 'max_q'))
    min_q_rank = _MIN_Q_MAP.get(addon.getSetting('min_q_tv' if is_tv else 'min_q'))

    # Debrid cache check — annotates magnet sources with 'cached_by' list
    active_debrids = get_active_debrids()
    if active_debrids:
        source_utils.check_magnet_cache(all_raw, active_debrids)

    return _normalise(all_raw, max_q_rank=max_q_rank, min_q_rank=min_q_rank,
                      season=season, episode=episode, active_debrids=active_debrids)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _lib_path(addon_id):
    """Return the lib/ directory for a Kodi addon, or None."""
    try:
        path = xbmcaddon.Addon(addon_id).getAddonInfo('path')
        lib  = os.path.join(path, 'lib')
        return lib if os.path.isdir(lib) else path
    except Exception:
        return None


def _ensure_path(lib_path):
    if lib_path and lib_path not in sys.path:
        sys.path.insert(0, lib_path)


def _scrape_one(addon_id, data, on_done=None):
    """Return raw source dicts from one scraper module.  Never raises."""
    info = _SCRAPERS.get(addon_id)
    if not info:
        return []

    lib_path = _lib_path(addon_id)
    if not lib_path:
        return []

    _ensure_path(lib_path)

    try:
        if info['convention'] == 'A':
            return _scrape_convention_a(info['pkg'], data, on_done)
        elif info['convention'] == 'B':
            return _scrape_convention_b(lib_path, data, on_done)
    except Exception as exc:
        log('_scrape_one [{}] error: {}'.format(addon_id, exc), level='warning')

    return []


def _scrape_convention_a(pkg_name, data, on_done=None):
    """
    Convention A: call pkg.sources(ret_all=True) to get all providers as
    (name, class) tuples, then thread over each provider's sources(data, []).
    """
    try:
        pkg       = importlib.import_module(pkg_name)
        providers = pkg.sources(ret_all=True)
    except Exception as exc:
        log('convention-A import [{}]: {}'.format(pkg_name, exc), level='warning')
        return []

    results = []
    lock    = Lock()

    def _run_provider(cls):
        raw = []
        try:
            raw = cls().sources(data, []) or []
            if raw:
                with lock:
                    results.extend(raw)
        except Exception:
            pass    # silent per-provider failures
        finally:
            if on_done:
                try:
                    on_done(len(raw))
                except Exception:
                    pass

    threads = [Thread(target=_run_provider, args=(cls,)) for _, cls in providers]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=_PROVIDER_TIMEOUT)

    return results


def _scrape_convention_b(lib_path, data, on_done=None):
    """
    Convention B: CocoScrapers — enumerate torrent providers from the
    all_providers list and import each one individually.
    """
    _ensure_path(lib_path)

    try:
        from cocoscrapers.sources_cocoscrapers import all_providers
    except Exception as exc:
        log('convention-B import (cocoscrapers): %s' % exc, level='warning')
        return []

    results = []
    lock    = Lock()

    def _run_provider(name):
        raw = []
        try:
            mod = importlib.import_module(
                'cocoscrapers.sources_cocoscrapers.torrents.' + name
            )
            raw = mod.source().sources(data, []) or []
            if raw:
                with lock:
                    results.extend(raw)
        except Exception:
            pass
        finally:
            if on_done:
                try:
                    on_done(len(raw))
                except Exception:
                    pass

    threads = [Thread(target=_run_provider, args=(pn,)) for pn in all_providers]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=_PROVIDER_TIMEOUT)

    return results


def _normalise(raw_sources, max_q_rank=None, min_q_rank=None,
               season=None, episode=None, active_debrids=None):
    """
    Convert raw scraper dicts to uniform {'label', 'url', 'quality'} items.
    Deduplicates by URL, applies quality ceiling/floor, sorts best first.

    For episode sources the filename is validated against seas_ep_filter to
    drop wrong-episode results before they reach the dialog.
    Labels include a debrid tag ([CACHED:AD], [TORRENT], [DIRECT]) and, when
    the filename contains codec/format tokens, those are appended too.

    max_q_rank     : int or None
    min_q_rank     : int or None
    season/episode : for episode S/E filename filtering (both required)
    active_debrids : dict {resolver_id: short_label} — passed in from scrape()
    """
    if active_debrids is None:
        active_debrids = {}
    active_shorts = set(active_debrids.values())

    is_episode = (season is not None and episode is not None)

    out  = []
    seen = set()

    for r in raw_sources:
        url = r.get('url', '')
        if not url or url in seen:
            continue
        seen.add(url)

        quality = r.get('quality', 'SD')
        rank    = _QUALITY_RANK.get(quality, 99)

        # Quality ceiling — drop sources better than the configured max
        if max_q_rank is not None and rank < max_q_rank:
            continue
        # Quality floor — drop sources worse than the configured min
        if min_q_rank is not None and rank > min_q_rank:
            continue

        filename = _extract_filename(url)

        # ── Episode S/E filename filter ───────────────────────────────────────
        if is_episode and filename:
            if not source_utils.seas_ep_filter(season, episode, filename):
                continue   # wrong episode — skip

        provider = r.get('provider', '?')

        # ── Debrid tag ────────────────────────────────────────────────────────
        cached_by = r.get('cached_by')   # list set by check_magnet_cache, or None
        debrid_raw = (r.get('debrid') or r.get('debrid_provider') or
                      '').lower().replace(' ', '').replace('.', '')
        debrid_info = _DEBRID_ALIASES.get(debrid_raw)

        if cached_by is not None:
            # Cache check was run — show real cached status
            if cached_by:
                debrid_tag    = 'CACHED:' + '/'.join(cached_by)
                debrid_active = True
            else:
                debrid_tag    = 'TORRENT'   # magnet but not cached
                debrid_active = bool(active_shorts)
        elif debrid_info:
            # Scraper explicitly tagged a debrid service
            short_label, resolver_id = debrid_info
            debrid_tag    = short_label
            debrid_active = resolver_id in active_debrids
        elif url.lower().startswith('magnet:'):
            debrid_tag    = 'TORRENT'
            debrid_active = bool(active_shorts)
        else:
            debrid_tag    = 'DIRECT'
            debrid_active = True

        # ── Codec/format tags from filename ───────────────────────────────────
        codec_tag = source_utils.get_file_type(filename) if filename else ''

        if codec_tag:
            label = '[{}] [{}] [{}]  {}'.format(quality, debrid_tag, codec_tag, provider)
        else:
            label = '[{}] [{}]  {}'.format(quality, debrid_tag, provider)

        out.append({'label': label, 'url': url, 'quality': quality,
                    'filename': filename,
                    '_debrid_active': debrid_active, '_rank': rank})

    # Sort: cached/active-debrid sources first, then by quality rank
    out.sort(key=lambda x: (0 if x['_debrid_active'] else 1, x['_rank']))

    for item in out:
        item.pop('_debrid_active', None)
        item.pop('_rank', None)

    return out


def _extract_filename(url):
    """Best-effort: return a human-readable filename/release-name from a URL."""
    if not url:
        return ''
    low = url.lower()
    if low.startswith('magnet:'):
        try:
            from urllib.parse import parse_qsl
            qs = url.split('?', 1)[-1]
            dn = dict(parse_qsl(qs)).get('dn', '')
            return dn[:100] if dn else ''
        except Exception:
            return ''
    try:
        from urllib.parse import urlparse, unquote
        path = unquote(urlparse(url).path).rstrip('/')
        name = path.split('/')[-1]
        # Only return if it looks like a real filename (has an extension or dots)
        if name and ('.' in name or len(name) > 8):
            return name[:100]
    except Exception:
        pass
    return ''
