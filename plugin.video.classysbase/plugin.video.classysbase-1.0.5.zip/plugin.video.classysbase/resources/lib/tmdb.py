"""
tmdb.py — The Movie Database (TMDB) API client
===============================================

Thin, well-documented wrapper around the TMDB v3 REST API.
All HTTP calls are cached via resources.lib.cache.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Quick-start
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1. Register a free account at https://www.themoviedb.org/
2. Go to  Settings → API → Create → Developer
3. Copy your *v3 API key* (the long hex string, NOT the v4 read token)
4. In Kodi: Classy's Base → Settings → TMDB → API Key → paste it

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Supported Jen  <tmdb>  tag values
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  <tmdb>collection/{id}</tmdb>   →  all movies in a TMDB collection
  <tmdb>list/{id}</tmdb>         →  items in a custom TMDB list (mixed types)
  <tmdb>movie/{id}</tmdb>        →  single movie (detail page)
  <tmdb>tv/{id}</tmdb>           →  single TV show (detail page)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Returned item dict keys  (from all public functions)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  tmdb_id     int         TMDB numeric ID
  media_type  str         'movie' or 'tv'
  title       str         Display title
  year        str         4-digit year string, or ''
  plot        str         Overview / synopsis
  rating      float       Average vote (0.0–10.0)
  thumb       str         Full poster URL  (w342)
  fanart      str         Full backdrop URL (w780)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Error policy
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
All public functions return  None  (or empty list) on ANY error.
They never raise.  Errors are written to the Kodi log.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Cache lifetimes
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
  Browse (collection / list)  :  6 hours
  Item detail (movie / tv)    :  24 hours
"""

import re
import sys
import unicodedata

import xbmcaddon
import xbmcgui
import xbmcplugin

from resources.lib.cache import get as cached
from resources.lib.infotag import VideoInfo
from resources.lib.client import get as http_get
from resources.lib.log import log
from resources.lib.utils import build_url

# ── API constants ──────────────────────────────────────────────────────────────

TMDB_BASE     = 'https://api.themoviedb.org/3'
IMAGE_BASE    = 'https://image.tmdb.org/t/p'

# Image size presets — use the smallest that still looks sharp
POSTER_SIZE   = 'w342'       # ~342 px wide  — thumbnail / list view
BACKDROP_SIZE = 'w780'       # ~780 px wide  — fanart / background

# Cache lifetimes (hours)
_CACHE_BROWSE = 6
_CACHE_ITEM   = 24

# ── Image helper ───────────────────────────────────────────────────────────────

def img_url(path, size=POSTER_SIZE):
    """
    Build a full TMDB image CDN URL from a relative path.

    Parameters
    ----------
    path : str
        Relative path as returned by the API, e.g. '/abc123.jpg'.
        Pass an empty string or None to get ''.
    size : str
        One of the TMDB image size constants, e.g. 'w342', 'w780',
        'original'.  Default: POSTER_SIZE ('w342').

    Returns
    -------
    str
        Full URL, e.g. 'https://image.tmdb.org/t/p/w342/abc123.jpg'
        or '' if path is falsy.

    Examples
    --------
    >>> img_url('/abc123.jpg')
    'https://image.tmdb.org/t/p/w342/abc123.jpg'
    >>> img_url('/abc123.jpg', size='original')
    'https://image.tmdb.org/t/p/original/abc123.jpg'
    >>> img_url('')
    ''
    """
    if not path:
        return ''
    return '{}/{}{}'.format(IMAGE_BASE, size, path)


# ── Internal helpers ───────────────────────────────────────────────────────────

def _api_key():
    """
    Read the TMDB v3 API key from addon settings.

    Returns empty string if the setting is missing or blank.
    The caller is responsible for checking and notifying the user.
    """
    return xbmcaddon.Addon().getSetting('tmdb_api_key').strip()


def _get(endpoint, extra_params=None):
    """
    Make an authenticated GET request to the TMDB v3 API.

    Parameters
    ----------
    endpoint : str
        Path relative to TMDB_BASE, e.g. '/collection/151'.
    extra_params : dict, optional
        Extra query parameters merged on top of api_key and language.

    Returns
    -------
    dict | None
        Parsed JSON response body, or None on any error.

    Notes
    -----
    - Returns None and logs a warning if no API key is configured.
    - Returns None and logs specific messages for 401 / 404 / other errors.
    - Does NOT raise; all exceptions are caught and logged.
    """
    key = _api_key()
    if not key:
        log('TMDB: no API key — open Settings and add your TMDB v3 key',
            level='warning')
        return None

    params = {'api_key': key, 'language': 'en-US'}
    if extra_params:
        params.update(extra_params)

    try:
        from urllib.parse import urlencode
        url = '{}{}?{}'.format(TMDB_BASE, endpoint, urlencode(params))
    except Exception as e:
        log('TMDB: URL build error: %s' % e, level='error')
        return None

    response = http_get(url)
    if response is None:
        log('TMDB: network request failed for %s' % endpoint, level='error')
        return None

    if response.status_code == 401:
        log('TMDB: 401 Unauthorized — API key is wrong or expired. '
            'Update it in Settings.', level='error')
        from resources.lib.strings import _, S_ADDON_NAME, S_TMDB_BAD_KEY
        xbmcgui.Dialog().notification(
            _(S_ADDON_NAME), _(S_TMDB_BAD_KEY),
            xbmcgui.NOTIFICATION_ERROR, 6000
        )
        return None

    if response.status_code == 404:
        log('TMDB: 404 Not Found — %s' % endpoint, level='warning')
        return None

    if not response.ok:
        log('TMDB: HTTP {} for {}'.format(response.status_code, endpoint),
            level='error')
        return None

    try:
        return response.json()
    except Exception as e:
        log('TMDB: JSON decode error for {}: {}'.format(endpoint, e),
            level='error')
        return None


# ── Normalisation ─────────────────────────────────────────────────────────────

def _norm_movie(m):
    """
    Normalise a raw TMDB movie object to our flat item dict.

    Parameters
    ----------
    m : dict
        Raw movie object as returned by the TMDB API.

    Returns
    -------
    dict
        Keys: tmdb_id, media_type, title, year, plot, rating, thumb, fanart.
    """
    return {
        'tmdb_id':    m.get('id', ''),
        'media_type': 'movie',
        'title':      m.get('title') or m.get('original_title') or 'Unknown',
        'year':       (m.get('release_date') or '')[:4],
        'plot':       m.get('overview') or '',
        'tagline':    m.get('tagline') or '',
        'rating':     float(m.get('vote_average') or 0.0),
        'vote_count': int(m.get('vote_count') or 0),
        'thumb':      img_url(m.get('poster_path'),   POSTER_SIZE),
        'fanart':     img_url(m.get('backdrop_path'), BACKDROP_SIZE),
        'runtime':    int(m.get('runtime') or 0),
        'genres':     [g.get('name', '') for g in (m.get('genres') or [])],
        'imdb_id':    m.get('imdb_id') or '',
    }


def _norm_tv(t):
    """
    Normalise a raw TMDB TV show object to our flat item dict.

    Parameters
    ----------
    t : dict
        Raw TV show object as returned by the TMDB API.

    Returns
    -------
    dict
        Same keys as _norm_movie but media_type='tv'.
    """
    ext_ids      = t.get('external_ids') or {}
    runtime_list = t.get('episode_run_time') or []
    return {
        'tmdb_id':            t.get('id', ''),
        'media_type':         'tvshow',
        'title':              t.get('name') or t.get('original_name') or 'Unknown',
        'year':               (t.get('first_air_date') or '')[:4],
        'plot':               t.get('overview') or '',
        'tagline':            t.get('tagline') or '',
        'rating':             float(t.get('vote_average') or 0.0),
        'vote_count':         int(t.get('vote_count') or 0),
        'thumb':              img_url(t.get('poster_path'),   POSTER_SIZE),
        'fanart':             img_url(t.get('backdrop_path'), BACKDROP_SIZE),
        'genres':             [g.get('name', '') for g in (t.get('genres') or [])],
        'status':             t.get('status') or '',
        'number_of_seasons':  int(t.get('number_of_seasons') or 0),
        'number_of_episodes': int(t.get('number_of_episodes') or 0),
        'runtime':            int(runtime_list[0]) if runtime_list else 0,
        'imdb_id':            ext_ids.get('imdb_id') or '',
    }


def _norm_any(item):
    """
    Normalise a TMDB item that may be a movie or TV show.

    Checks the 'media_type' field, falling back to presence of 'name'
    (TV shows use 'name'; movies use 'title').
    """
    mt = item.get('media_type', '')
    if mt == 'tv' or (not mt and 'name' in item and 'title' not in item):
        return _norm_tv(item)
    return _norm_movie(item)


def _norm_season(s, show_data):
    """Normalise a TMDB season object to our flat season dict."""
    sn = s.get('season_number', 0)
    return {
        'media_type':    'season',
        'season_number': sn,
        'name':          s.get('name') or ('Specials' if sn == 0 else 'Season %d' % sn),
        'episode_count': s.get('episode_count', 0),
        'year':          (s.get('air_date') or '')[:4],
        'thumb':         img_url(s.get('poster_path'), POSTER_SIZE),
        'fanart':        img_url(show_data.get('backdrop_path'), BACKDROP_SIZE),
        'plot':          s.get('overview') or '',
        'show_id':       show_data.get('id', ''),
        'show_title':    show_data.get('name') or show_data.get('original_name') or '',
        'show_year':     (show_data.get('first_air_date') or '')[:4],
    }


def _norm_episode(e, show_data):
    """Normalise a TMDB episode object to our flat episode dict."""
    en = e.get('episode_number', 0)
    guests = [g.get('name', '') for g in (e.get('guest_stars') or [])[:3]]
    return {
        'media_type':     'episode',
        'season_number':  e.get('season_number', 0),
        'episode_number': en,
        'title':          e.get('name') or ('Episode %d' % en),
        'year':           (e.get('air_date') or '')[:4],
        'first_aired':    e.get('air_date') or '',
        'thumb':          img_url(e.get('still_path'), 'w300'),
        'fanart':         img_url(show_data.get('backdrop_path'), BACKDROP_SIZE),
        'plot':           e.get('overview') or '',
        'rating':         float(e.get('vote_average') or 0.0),
        'runtime':        int(e.get('runtime') or 0),
        'guest_stars':    guests,
        'show_id':        show_data.get('id', ''),
        'show_title':     show_data.get('name') or show_data.get('original_name') or '',
        'show_year':      (show_data.get('first_air_date') or '')[:4],
    }


# ── Title-search helpers (for plain-list Trakt matching) ───────────────────────

def _fetch_tmdb_id_by_title(title, media_type):
    """Cache-worker: search TMDB for *title*, return ID as str or None."""
    endpoint = '/search/tv' if media_type == 'tv' else '/search/movie'
    data = _get(endpoint, {'query': title, 'include_adult': 'false'})
    if not data:
        return None
    results = data.get('results', [])
    if not results:
        return None

    def _norm(s):
        s = unicodedata.normalize('NFD', s).encode('ascii', 'ignore').decode()
        s = re.sub(r'[^a-z0-9 ]', '', s.lower())
        return re.sub(r'\s+', ' ', s).strip()

    def _score(a, b):
        sa, sb = set(a.split()), set(b.split())
        if not sa or not sb:
            return 0.0
        return len(sa & sb) / len(sa | sb)

    q = _norm(title)
    scored = []
    for r in results:
        if media_type == 'tv':
            t, ot = r.get('name', ''), r.get('original_name', '')
        else:
            t, ot = r.get('title', ''), r.get('original_title', '')
        score = max(_score(q, _norm(t)), _score(q, _norm(ot)))
        scored.append((score, float(r.get('popularity', 0)), r['id']))

    scored.sort(reverse=True)
    return str(scored[0][2])


def tmdb_id_from_title(title, media_type='tv'):
    """Search TMDB for *title*, return its TMDB ID (int) or None. Cached 168 h."""
    from resources.lib import cache as _cache
    result = _cache.get(_fetch_tmdb_id_by_title, 168, title, media_type)
    return int(result) if result else None


# ── Public API ─────────────────────────────────────────────────────────────────

def collection(collection_id):
    """
    Fetch all movies in a TMDB collection, sorted by release date.

    A 'collection' groups related movies (e.g. a film franchise).
    Example: collection 151 = "Star Trek: The Original Movies"

    Parameters
    ----------
    collection_id : int | str
        TMDB collection ID.

    Returns
    -------
    list[dict] | None
        Sorted list of normalised movie dicts, or None on error.
        Each dict has keys: tmdb_id, media_type, title, year,
        plot, rating, thumb, fanart.
    """
    data = _get('/collection/%s' % collection_id)
    if not data:
        return None
    movies = data.get('parts') or []
    movies.sort(key=lambda m: m.get('release_date') or '')
    return [_norm_movie(m) for m in movies]


def tmdb_list(list_id):
    """
    Fetch all items from a custom TMDB list.

    Custom lists can mix movies and TV shows.
    Example: list 8580589 = a Star Trek TV shows list.

    Parameters
    ----------
    list_id : int | str
        TMDB list ID.

    Returns
    -------
    list[dict] | None
        List of normalised item dicts (media_type is 'movie' or 'tv'),
        or None on error.
    """
    data = _get('/list/%s' % list_id)
    if not data:
        return None
    return [_norm_any(item) for item in (data.get('items') or [])]


def movie(movie_id):
    """
    Fetch details for a single TMDB movie.

    Parameters
    ----------
    movie_id : int | str
        TMDB movie ID.

    Returns
    -------
    dict | None
        Normalised movie dict, or None on error.
    """
    data = _get('/movie/%s' % movie_id)
    return _norm_movie(data) if data else None


def tv(tv_id):
    """
    Fetch details for a single TMDB TV show.

    Parameters
    ----------
    tv_id : int | str
        TMDB TV show ID.

    Returns
    -------
    dict | None
        Normalised TV show dict, or None on error.
    """
    data = _get('/tv/%s' % tv_id)
    return _norm_tv(data) if data else None


def tv_seasons(tv_id):
    """
    Fetch the season list for a TMDB TV show, including season 0 (Specials).

    Parameters
    ----------
    tv_id : int | str
        TMDB TV show ID.

    Returns
    -------
    list[dict] | None
        List of normalised season dicts, or None on error.
    """
    data = _get('/tv/%s' % tv_id)
    if not data:
        return None
    seasons = data.get('seasons') or []
    return [_norm_season(s, data) for s in seasons]


def season_episodes(season_ref):
    """
    Fetch all episodes for one season of a TV show.

    Parameters
    ----------
    season_ref : str
        '<show_id>/<season_number>', e.g. '57243/1'.

    Returns
    -------
    list[dict] | None
        List of normalised episode dicts, or None on error.
    """
    parts = str(season_ref).split('/', 1)
    if len(parts) != 2:
        return None
    show_id, season_num = parts
    show_data = _get('/tv/%s' % show_id)
    if not show_data:
        return None
    data = _get('/tv/{}/season/{}'.format(show_id, season_num))
    if not data:
        return None
    episodes = data.get('episodes') or []
    return [_norm_episode(e, show_data) for e in episodes]


def _fetch_season_meta(show_id, season_num):
    """Cache-worker: fetch and normalise all episodes for one season."""
    return season_episodes('{}/{}'.format(show_id, season_num))


def season_episodes_cached(show_id, season_num):
    """Like season_episodes but results are cached for 168 h."""
    from resources.lib import cache as _cache
    return _cache.get(_fetch_season_meta, 168, str(show_id), str(season_num))


def company_movies(company_id):
    """
    Fetch movies produced by a TMDB company.

    company_id may arrive as 'movies/6677' (from a 3-part Jen tag
    'company/movies/6677') or as a plain '6677' — both are handled.

    Parameters
    ----------
    company_id : int | str
        TMDB company ID, optionally prefixed with 'movies/'.

    Returns
    -------
    list[dict] | None
        List of normalised movie dicts sorted by release date,
        or None on error.
    """
    real_id = str(company_id).split('/')[-1]
    data = _get('/company/%s/movies' % real_id)
    if not data:
        return None
    movies = data.get('results') or []
    movies.sort(key=lambda m: m.get('release_date') or '')
    return [_norm_movie(m) for m in movies]


def genre_items(genre_ref):
    """
    Fetch movies or TV shows for a TMDB genre via the discover endpoint.

    genre_ref is the tmdb_id portion of a 3-part Jen tag, e.g.:
        'movies/10752'  → /discover/movie?with_genres=10752
        'shows/10765'   → /discover/tv?with_genres=10765

    Parameters
    ----------
    genre_ref : str
        '<media_type>/<genre_id>' where media_type is 'movies' or 'shows'.

    Returns
    -------
    list[dict] | None
        List of normalised item dicts sorted by popularity, or None on error.
    """
    parts = str(genre_ref).split('/', 1)
    if len(parts) != 2:
        return None
    media_type, genre_id = parts
    if media_type == 'shows':
        endpoint  = '/discover/tv'
        norm_fn   = _norm_tv
    else:  # 'movies' or fallback
        endpoint  = '/discover/movie'
        norm_fn   = _norm_movie
    data = _get(endpoint, extra_params={'with_genres': genre_id,
                                        'sort_by': 'popularity.desc'})
    if not data:
        return None
    return [norm_fn(item) for item in (data.get('results') or [])]


def year_items(year_ref):
    """
    Fetch movies or TV shows released in a specific year via /discover.

    year_ref arrives as 'movies/2001' or 'shows/2001' (from a 3-part Jen tag
    like <tmdb>year/movies/2001</tmdb>).

    Uses primary_release_year for movies and first_air_date_year for shows.
    """
    parts = str(year_ref).split('/', 1)
    if len(parts) != 2:
        return None
    media_type, year = parts
    if media_type == 'shows':
        endpoint  = '/discover/tv'
        params    = {'first_air_date_year': year, 'sort_by': 'popularity.desc'}
        norm_fn   = _norm_tv
    else:  # 'movies' or fallback
        endpoint  = '/discover/movie'
        params    = {'primary_release_year': year, 'sort_by': 'popularity.desc'}
        norm_fn   = _norm_movie
    data = _get(endpoint, extra_params=params)
    if not data:
        return None
    return [norm_fn(item) for item in (data.get('results') or [])]


def person_credits(person_ref):
    """
    Fetch movies or TV shows for a TMDB person (actor, director, etc.).

    person_ref arrives as 'movies/{id}' or 'shows/{id}' (from a 3-part Jen
    tag like <tmdb>person/movies/1158</tmdb>).

    Results are sorted by release/air date descending.
    """
    parts = str(person_ref).split('/', 1)
    if len(parts) != 2:
        return None
    media_type, person_id = parts
    if media_type == 'shows':
        data = _get('/person/%s/tv_credits' % person_id)
        if not data:
            return None
        items = sorted(
            data.get('cast') or [],
            key=lambda t: t.get('first_air_date') or '',
            reverse=True,
        )
        return [_norm_tv(t) for t in items]
    else:  # 'movies' or fallback
        data = _get('/person/%s/movie_credits' % person_id)
        if not data:
            return None
        items = sorted(
            data.get('cast') or [],
            key=lambda m: m.get('release_date') or '',
            reverse=True,
        )
        return [_norm_movie(m) for m in items]


def _fetch_person_meta(person_id):
    """Return raw TMDB /person/{id} data (cached via person_portrait)."""
    return _get('/person/%s' % person_id) or {}


def _fetch_external_ids(tmdb_id, media_type='movie'):
    """Return raw TMDB external_ids data for a movie or TV show."""
    endpoint = '/tv/%s/external_ids' % tmdb_id if media_type == 'tv' else '/movie/%s/external_ids' % tmdb_id
    return _get(endpoint) or {}


def get_imdb_id(tmdb_id, media_type='movie'):
    """
    Return the IMDB ID string (e.g. 'tt0068646') for a TMDB movie or show ID.
    Returns '' if not found.  Result is cached for _CACHE_ITEM hours.
    """
    data = cached(_fetch_external_ids, _CACHE_ITEM, str(tmdb_id), media_type)
    return (data.get('imdb_id') or '') if isinstance(data, dict) else ''


def person_portrait(person_id):
    """
    Return the TMDB profile image URL for a person, or '' if not found.
    Result is cached for _CACHE_ITEM hours.
    """
    data = cached(_fetch_person_meta, _CACHE_ITEM, str(person_id))
    if isinstance(data, dict):
        return img_url(data.get('profile_path'), POSTER_SIZE) or ''
    return ''


def network_shows(network_ref):
    """
    Fetch TV shows airing on a TMDB network via /discover/tv.

    network_ref arrives as 'shows/<id>' (from <tmdb>network/shows/213</tmdb>)
    or as a plain numeric string — both are handled.

    Examples: 213 = Netflix, 2739 = Disney+, 49 = HBO.
    """
    real_id = str(network_ref).split('/')[-1]
    data = _get('/discover/tv', extra_params={
        'with_networks': real_id,
        'sort_by': 'popularity.desc',
    })
    if not data:
        return None
    return [_norm_tv(r) for r in (data.get('results') or [])]


def _tv_list(list_id):
    """
    Fetch a TMDB TV browse list: popular, top_rated, airing_today, on_the_air.

    These are paginated show lists returned by /tv/<list_id>.
    """
    data = _get('/tv/%s' % list_id)
    if not data:
        return None
    return [_norm_tv(r) for r in (data.get('results') or [])]


# Special tmdb_ids for the 'tv' type that are browse lists, not show IDs
_TV_LIST_IDS = frozenset(('popular', 'top_rated', 'airing_today', 'on_the_air'))


# ── Browse dispatcher ──────────────────────────────────────────────────────────

# Maps <tmdb> type strings to (fetch_function, cache_hours)
_FETCHERS = {
    'collection': (collection,      _CACHE_BROWSE),
    'list':       (tmdb_list,       _CACHE_BROWSE),
    'movie':      (movie,           _CACHE_ITEM),
    'tv':         (tv_seasons,      _CACHE_ITEM),
    'season':     (season_episodes, _CACHE_BROWSE),
    'company':    (company_movies,  _CACHE_BROWSE),
    'genre':      (genre_items,     _CACHE_BROWSE),
    'network':    (network_shows,   _CACHE_BROWSE),
    'year':       (year_items,      _CACHE_BROWSE),
    'person':     (person_credits,  _CACHE_BROWSE),
}


def browse(tmdb_type, tmdb_id):
    """
    Resolve a Jen <tmdb> tag to a list of items, with caching.

    This is the single entry point called by the router's 'tmdb' mode.
    It wraps the individual fetch functions with cache.get() so results
    are re-used within the configured lifetime.

    Parameters
    ----------
    tmdb_type : str
        One of: 'collection', 'list', 'movie', 'tv', 'company', 'genre'.
        Matches the prefix in a Jen <tmdb> tag value.
    tmdb_id : str | int
        The TMDB numeric ID.

    Returns
    -------
    list[dict] | None
        List of normalised item dicts, or None on error / unknown type.

    Examples
    --------
    browse('collection', 151)    →  Star Trek original movie series
    browse('list', 8580589)      →  custom Star Trek TV list
    """
    entry = _FETCHERS.get(tmdb_type)
    if not entry:
        log('TMDB: unknown type %r — supported: %s'
            % (tmdb_type, ', '.join(_FETCHERS)), level='warning')
        return None

    # TV show hierarchy uses media_store for status-aware TTLs and explicit keys.
    if tmdb_type == 'tv':
        # Special list IDs (popular, top_rated, …) are NOT show IDs.
        if str(tmdb_id) in _TV_LIST_IDS:
            from resources.lib import cache as _cache
            return _cache.get(_tv_list, _CACHE_BROWSE, str(tmdb_id))
        from resources.lib.media_store import fetch_seasons
        return fetch_seasons(tmdb_id)

    if tmdb_type == 'season':
        from resources.lib.media_store import fetch_season
        parts = str(tmdb_id).split('/', 1)
        if len(parts) != 2:
            return None
        return fetch_season(parts[0], parts[1])

    fetch_fn, hours = entry
    result = cached(fetch_fn, hours, tmdb_id)
    # movie() and tv() return a single dict; wrap so render() always gets a list
    if isinstance(result, dict):
        result = [result]
    return result


# ── Kodi directory renderer ────────────────────────────────────────────────────

def render(handle, params):
    """
    Fetch a TMDB resource and populate the Kodi directory listing.

    Called by the router when mode='tmdb'.  Reads tmdb_type and tmdb_id
    from params, fetches data via browse(), and adds ListItems to Kodi.

    Items are rendered as non-playable directory stubs for now.
    Future: wire each item to a scraper search so it becomes playable.

    Parameters
    ----------
    handle : int
        Kodi plugin handle (sys.argv[1]).
    params : dict
        URL params from the plugin call.  Expected keys:
            tmdb_type  — 'collection' | 'list' | 'movie' | 'tv'
            tmdb_id    — TMDB numeric ID (as string)
            name       — display title of the parent item (optional)
    """
    tmdb_type = params.get('tmdb_type', '')
    tmdb_id   = params.get('tmdb_id', '')

    log('[classysbase] tmdb.render → type=%s id=%s name=%s'
        % (tmdb_type, tmdb_id, params.get('name', '')))

    if not tmdb_type or not tmdb_id:
        log('TMDB render: missing tmdb_type or tmdb_id in params', level='error')
        return

    if not _api_key():
        # Surface the missing-key problem as a visible item in the list
        _render_no_key(handle)
        return

    # For season type, compose browse_id from show id + season number
    if tmdb_type == 'season':
        season_num = params.get('season', '')
        browse_id  = '{}/{}'.format(tmdb_id, season_num)
    else:
        browse_id = tmdb_id

    items = browse(tmdb_type, browse_id)

    if not items:
        log('TMDB: browse returned nothing for {}/{}'.format(tmdb_type, tmdb_id),
            level='warning')
        return

    # ── Trakt watched overlays (skipped silently if not authenticated) ─────────
    _trakt_auth     = False
    _trakt_movies   = set()   # tmdb_id strings of watched movies
    _trakt_episodes = {}      # {show_tmdb_str: {season_str: set(ep_str)}}
    try:
        import resources.lib.trakt_api as _trakt
        _trakt_auth = _trakt.is_authenticated()
        if _trakt_auth:
            _trakt_movies   = _trakt.get_watched_movies() or set()
            _trakt_episodes = _trakt.get_watched_shows()  or {}
    except Exception as _te:
        log('Trakt watched fetch skipped: %s' % _te, level='warning')

    # ── Temporary debug log — remove once TV show/season data is confirmed ─────
    if tmdb_type in ('tv', 'season') and items:
        log('DEBUG browse %s/%s → %d items | first: %s'
            % (tmdb_type, browse_id, len(items), str(items[0])[:500]), level='info')

    addon_url = sys.argv[0]
    list_items = []

    for item in items:
        media = item['media_type']

        if media == 'season':
            sn       = item['season_number']
            name     = item['name']
            ep_count = item['episode_count']
            label    = '%s  (%d ep.)' % (name, ep_count) if ep_count else name
            li = xbmcgui.ListItem(label)
            li.setArt({'thumb': item['thumb'], 'fanart': item['fanart']})
            VideoInfo(li,
                title=name,
                year=item['year'],
                plot=item['plot'],
                media_type='season',
                tvshowtitle=item['show_title'],
                season=sn,
            )
            target    = build_url(addon_url,
                                  mode='tmdb',
                                  tmdb_type='season',
                                  tmdb_id=item['show_id'],
                                  season=sn)
            is_folder = True
            if _trakt_auth and item.get('show_id'):
                from resources.lib.strings import _, S_TRAKT_SEASON_W, S_TRAKT_SEASON_UW
                li.addContextMenuItems([
                    (_(S_TRAKT_SEASON_W),
                     'RunPlugin(%s)' % build_url(addon_url,
                         mode='trakt_toggle', action='watched',
                         media_type='season', show_id=item['show_id'], season=sn)),
                    (_(S_TRAKT_SEASON_UW),
                     'RunPlugin(%s)' % build_url(addon_url,
                         mode='trakt_toggle', action='unwatched',
                         media_type='season', show_id=item['show_id'], season=sn)),
                ])

        elif media == 'episode':
            sn       = item['season_number']
            en       = item['episode_number']
            ep_title = item['title']
            label    = 'S%02dE%02d - %s' % (sn, en, ep_title)
            li = xbmcgui.ListItem(label)
            li.setArt({'thumb': item['thumb'], 'fanart': item['fanart']})
            _show_watched = _trakt_episodes.get(str(item['show_id']), {})
            _ep_watched   = str(en) in _show_watched.get(str(sn), set())
            VideoInfo(li,
                title=ep_title,
                year=item['year'],
                plot=item['plot'],
                rating=item['rating'],
                media_type='episode',
                tvshowtitle=item['show_title'],
                season=sn,
                episode=en,
                duration=item.get('runtime', 0) * 60,
                first_aired=item.get('year', ''),
                playcount=1 if _ep_watched else 0,
            )
            target    = build_url(addon_url,
                                  mode='scrape',
                                  title=item['show_title'],
                                  year=item['show_year'],
                                  season=sn,
                                  episode=en,
                                  ep_title=ep_title,
                                  plot=item.get('plot', ''),
                                  tmdb_id=item['show_id'],
                                  media_type='episode',
                                  fanart=item['fanart'],
                                  thumb=item['thumb'])
            is_folder = False
            if _trakt_auth and item.get('show_id'):
                from resources.lib.strings import _, S_TRAKT_WATCHED, S_TRAKT_UNWATCHED
                li.addContextMenuItems([
                    (_(S_TRAKT_WATCHED),
                     'RunPlugin(%s)' % build_url(addon_url,
                         mode='trakt_toggle', action='watched',
                         media_type='episode', show_id=item['show_id'],
                         season=sn, episode=en)),
                    (_(S_TRAKT_UNWATCHED),
                     'RunPlugin(%s)' % build_url(addon_url,
                         mode='trakt_toggle', action='unwatched',
                         media_type='episode', show_id=item['show_id'],
                         season=sn, episode=en)),
                ])

        else:
            # movie, or tv appearing in a mixed TMDB list
            title  = item['title']
            year   = item['year']
            label  = '{} ({})'.format(title, year) if year else title
            li = xbmcgui.ListItem(label)
            li.setArt({'thumb': item['thumb'], 'fanart': item['fanart'],
                       'poster': item['thumb']})
            VideoInfo(li,
                title=title,
                year=year,
                plot=item['plot'],
                tagline=item.get('tagline', ''),
                rating=item['rating'],
                media_type=media,
                duration=item.get('runtime', 0) * 60,
                genres=item.get('genres') or [],
                unique_ids={k: v for k, v in [
                    ('imdb', item.get('imdb_id', '')),
                    ('tmdb', str(item.get('tmdb_id', ''))),
                ] if v},
                playcount=1 if (media == 'movie' and str(item['tmdb_id']) in _trakt_movies) else 0,
            )
            if media == 'tvshow':
                # TV show from a list — drill down to its seasons
                target    = build_url(addon_url,
                                      mode='tmdb',
                                      tmdb_type='tv',
                                      tmdb_id=item['tmdb_id'],
                                      name=title)
                is_folder = True
                if _trakt_auth and item.get('tmdb_id'):
                    from resources.lib.strings import _, S_TRAKT_SHOW_W, S_TRAKT_SHOW_UW
                    li.addContextMenuItems([
                        (_(S_TRAKT_SHOW_W),
                         'RunPlugin(%s)' % build_url(addon_url,
                             mode='trakt_toggle', action='watched',
                             media_type='tvshow', tmdb_id=item['tmdb_id'])),
                        (_(S_TRAKT_SHOW_UW),
                         'RunPlugin(%s)' % build_url(addon_url,
                             mode='trakt_toggle', action='unwatched',
                             media_type='tvshow', tmdb_id=item['tmdb_id'])),
                    ])
            else:
                target    = build_url(addon_url,
                                      mode='scrape',
                                      title=title,
                                      year=year,
                                      tmdb_id=item['tmdb_id'],
                                      media_type=media,
                                      plot=item.get('plot', ''),
                                      fanart=item['fanart'],
                                      thumb=item['thumb'])
                is_folder = False
                if _trakt_auth and item.get('tmdb_id'):
                    from resources.lib.strings import _, S_TRAKT_WATCHED, S_TRAKT_UNWATCHED
                    li.addContextMenuItems([
                        (_(S_TRAKT_WATCHED),
                         'RunPlugin(%s)' % build_url(addon_url,
                             mode='trakt_toggle', action='watched',
                             media_type='movie', tmdb_id=item['tmdb_id'])),
                        (_(S_TRAKT_UNWATCHED),
                         'RunPlugin(%s)' % build_url(addon_url,
                             mode='trakt_toggle', action='unwatched',
                             media_type='movie', tmdb_id=item['tmdb_id'])),
                    ])

        list_items.append((target, li, is_folder))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    if tmdb_type == 'season':
        content = 'episodes'
    elif tmdb_type == 'tv':
        content = 'seasons'
    elif tmdb_type == 'collection':
        content = 'movies'
    else:
        content = 'files'
    xbmcplugin.setContent(handle, content)


def _render_no_key(handle):
    """Show a single explanatory item when no API key is configured."""
    li = xbmcgui.ListItem(
        '[COLOR yellow]No TMDB API key — open Settings to add one[/COLOR]'
    )
    xbmcplugin.addDirectoryItem(handle, '', li, False)
