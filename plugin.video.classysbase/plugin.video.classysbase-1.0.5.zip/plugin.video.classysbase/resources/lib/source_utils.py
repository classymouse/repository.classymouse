"""
source_utils.py — Source filtering, quality detection, debrid cache checking.

Functions adapted from script.module.thecrew (GPL-3.0) with all thecrew-specific
internal dependencies removed. Standalone — works with the standard library plus
the `requests` that ships with Kodi 19+.

Public API
----------
seas_ep_filter(season, episode, release_title) -> bool
    True  if release_title contains a S/E pattern that matches the requested
    season+episode (including pack-range filenames like S02E01-09).

get_file_type(url) -> str
    Returns a '/'-separated string of format/codec tags detected in the URL or
    display-name of a source, e.g. 'Bluray/HEVC/HDR/Atmos' or ''.

hash_from_magnet(magnet_uri) -> str | None
    Extract the torrent info-hash (lowercase hex) from a magnet: URI.

check_magnet_cache(raw_sources, active_debrids) -> raw_sources
    For every magnet source in raw_sources, hit the enabled debrid APIs in
    parallel and add a 'cached_by' key (list of short labels like ['AD','PREM'])
    to those whose hash is instantly available.  Modifies in-place and returns
    the same list so callers can chain it.
"""

import re
from html import unescape
from urllib.parse import unquote, parse_qsl
from threading import Thread, Lock

import xbmcaddon

from resources.lib.log import log


# ─── seas_ep_filter ───────────────────────────────────────────────────────────

def seas_ep_filter(season, episode, release_title, split=False, return_match=False):
    """
    Validate that a release filename contains a pattern for the requested
    season/episode.

    Handles:  S01E05, 1x05, season.1.episode.5, s1e1, and episode-pack ranges
              such as S01E01-09 or .2.1-9. (where the requested ep falls in range).

    Args:
        season        : int or str
        episode       : int or str
        release_title : filename / release-name to search
        split         : if True, return text after the matched pattern
        return_match  : if True, return the matched pattern string

    Returns:
        bool (default), str if split/return_match is True.
        When the release_title has no recognisable filename (empty), returns True
        so that we stay permissive and don't silently drop unknown sources.

    Adapted from script.module.thecrew source_utils.seas_ep_filter (GPL-3.0).
    """
    if not release_title:
        return True  # no filename to check — pass through

    try:
        season_int  = int(season)
        episode_int = int(episode)

        str_season, str_episode = str(season_int), str(episode_int)
        season_fill, episode_fill = str_season.zfill(2), str_episode.zfill(2)
        str_ep_plus_1  = str(episode_int + 1)
        str_ep_minus_1 = str(episode_int - 1)

        release_title = re.sub(
            r'[^A-Za-z0-9-]+', '.', unquote(release_title).replace("'", '')
        ).lower()

        # Pattern templates — <<S>> / <<E>> / <<E1>> / <<E2>> are placeholders
        t1 = r'(s<<S>>[.-]?e[p]?[.-]?<<E>>[.-])'
        t2 = r'(season[.-]?<<S>>[.-]?episode[.-]?<<E>>[.-])'
        t3 = r'(s<<S>>e<<E1>>[.-]?e?<<E2>>[.-])'
        t4 = r'([.-]<<S>>[.-]?<<E>>[.-])'
        t5 = r'(episode[.-]?<<E>>[.-])'
        t6 = r'([.-]e[p]?[.-]?<<E>>[.-])'
        t7 = (r'(^(?=.*\.e?0*<<E>>\.)(?:(?!((?:s|season)[.-]?\d+[.-x]?'
              r'(?:ep?|episode)[.-]?\d+)|\d+x\d+).)*$)')
        t8 = r'([s]?<<S>>x<<E>>[.-])'

        pats = []
        for s, e in [(season_fill, episode_fill), (str_season, episode_fill),
                     (season_fill, str_episode),  (str_season, str_episode)]:
            pats += [
                t1.replace('<<S>>', s).replace('<<E>>', e),
                t2.replace('<<S>>', s).replace('<<E>>', e),
                t4.replace('<<S>>', s).replace('<<E>>', e),
                t8.replace('<<S>>', s).replace('<<E>>', e),
            ]

        # Adjacent-episode bridge patterns (e.g. S01E04E05, S01E05E06)
        pats.append(t3.replace('<<S>>', season_fill)
                      .replace('<<E1>>', str_ep_minus_1.zfill(2))
                      .replace('<<E2>>', episode_fill))
        pats.append(t3.replace('<<S>>', season_fill)
                      .replace('<<E1>>', episode_fill)
                      .replace('<<E2>>', str_ep_plus_1.zfill(2)))
        pats.append(t5.replace('<<E>>', episode_fill))
        pats.append(t5.replace('<<E>>', str_episode))
        pats.append(t6.replace('<<E>>', episode_fill))
        pats.append(t7.replace('<<E>>', episode_fill))

        compiled = re.compile('|'.join(pats))

        if split:
            m = re.search(compiled, release_title)
            return release_title.split(m.group(), 1)[1] if m else release_title
        if return_match:
            m = re.search(compiled, release_title)
            return m.group() if m else None

        if re.search(compiled, release_title):
            return True

        # Pack-range patterns: S02E01-09, .2.1-9., s02e01-e09, etc.
        pack_pats = [
            r'[.-]' + season_fill + r'[.-](\d+)-(\d+)[.-]',
            r'[.-]' + str_season  + r'[.-](\d+)-(\d+)[.-]',
            r's' + season_fill + r'e(\d+)-e(\d+)[.-]',
            r's' + str_season  + r'e(\d+)-e(\d+)[.-]',
            r's' + season_fill + r'e(\d+)-(\d+)[.-]',
            r's' + str_season  + r'e(\d+)-(\d+)[.-]',
        ]
        for p in pack_pats:
            m = re.search(p, release_title)
            if m:
                try:
                    if int(m.group(1)) <= episode_int <= int(m.group(2)):
                        return True
                except (ValueError, IndexError):
                    continue

        return False

    except Exception:
        return True  # on any error, pass through


# ─── get_file_type ───────────────────────────────────────────────────────────

def get_file_type(url):
    """
    Detect codec/format/audio tags from a URL or display-name string.

    Returns a '/'-separated string, e.g. 'Bluray/HEVC/HDR/Atmos', or ''.
    Adapted from script.module.thecrew source_utils.get_file_type (GPL-3.0).
    """
    try:
        url = unescape(url)
        url = unquote(url)
        url = url.lower()
        url = re.sub(r'[^a-z0-9 ]+', ' ', url)
    except Exception:
        url = str(url)

    tags = []

    # Source / container
    if any(i in url for i in ['bluray', 'blu ray']):
        tags.append('Bluray')
    elif any(i in url for i in ['bdrip', 'bd rip', 'brrip', 'br rip']):
        tags.append('BDRip')
    if 'remux' in url:
        tags.append('Remux')
    if any(i in url for i in ['dvdrip', 'dvd rip']):
        tags.append('DVDRip')
    if any(i in url for i in ['webdl', 'web dl', 'webrip', 'web rip']):
        tags.append('WEB')
    if 'hdtv' in url:
        tags.append('HDTV')

    # Video codec
    if any(i in url for i in ['h 265', 'h265', 'x265', 'hevc']):
        tags.append('HEVC')
    elif any(i in url for i in ['h 264', 'h264', 'x264', 'avc']):
        tags.append('H264')
    if '10bit' in url or 'hi10p' in url:
        tags.append('10BIT')

    # HDR / colour
    if any(i in url for i in ['dolby vision', 'dolbyvision', 'dv ']):
        tags.append('DV')
    elif any(i in url for i in ['hdr10', ' hdr']):
        tags.append('HDR')
    if 'imax' in url:
        tags.append('IMAX')

    # Audio
    if 'atmos' in url:
        tags.append('Atmos')
    elif any(i in url for i in ['truehd', 'true hd']):
        tags.append('TrueHD')
    elif any(i in url for i in ['ddplus', 'eac3', 'ddp', 'dd plus']):
        tags.append('DD+')
    if any(i in url for i in ['dtsx', 'dts x']):
        tags.append('DTS:X')
    elif ' dts' in url:
        tags.append('DTS')
    if any(i in url for i in ['7 1', '8ch']):
        tags.append('7.1')
    elif any(i in url for i in ['5 1', '6ch']):
        tags.append('5.1')

    # Release flags
    if 'repack' in url:
        tags.append('REPACK')
    if 'proper' in url:
        tags.append('PROPER')

    return '/'.join(tags)


# ─── Magnet hash extraction ───────────────────────────────────────────────────

def hash_from_magnet(magnet):
    """
    Extract the info-hash (lowercase hex) from a magnet: URI.
    Returns None if the URI cannot be parsed.
    """
    try:
        qs = magnet.split('?', 1)[-1]
        xt = dict(parse_qsl(qs)).get('xt', '')
        if ':btih:' in xt:
            return xt.split(':btih:')[1].split('&')[0].lower()
    except Exception:
        pass
    return None


# ─── Debrid cache checking ────────────────────────────────────────────────────

def _rd_check(token, hashes):
    """Real-Debrid /torrents/instantAvailability — return set of cached hashes."""
    try:
        import requests
        url  = ('https://api.real-debrid.com/rest/1.0/torrents/instantAvailability/'
                + '/'.join(hashes))
        resp = requests.get(url, params={'auth_token': token}, timeout=15).json()
        # resp = {hash: {"rd": [{filename: {...}}]} or {}}
        return {h.lower() for h, v in resp.items()
                if isinstance(v, dict) and v.get('rd')}
    except Exception as e:
        log('debrid cache RD: {}'.format(e), level='warning')
        return set()


def _ad_check(token, hashes):
    """AllDebrid /magnet/instant — return set of cached hashes."""
    try:
        import requests
        resp = requests.post(
            'https://api.alldebrid.com/v4/magnet/instant',
            params={'agent': 'ClassysBase', 'apikey': token},
            data={'magnets[]': hashes},
            timeout=15,
        ).json()
        magnets = (resp.get('data') or {}).get('magnets') or []
        return {m['hash'].lower() for m in magnets if m.get('instant')}
    except Exception as e:
        log('debrid cache AD: {}'.format(e), level='warning')
        return set()


def _pm_check(token, hashes):
    """Premiumize /cache/check — return set of cached hashes."""
    try:
        import requests
        resp = requests.post(
            'https://www.premiumize.me/api/cache/check',
            headers={'Authorization': 'Bearer ' + token},
            data={'items[]': hashes},
            timeout=15,
        ).json()
        # 'response' is a positional bool list matching 'items[]'
        statuses = resp.get('response') or []
        return {hashes[i].lower()
                for i, ok in enumerate(statuses)
                if ok and i < len(hashes)}
    except Exception as e:
        log('debrid cache PM: {}'.format(e), level='warning')
        return set()


def _tb_check(token, hashes):
    """TorBox /torrents/checkcached — return set of cached hashes."""
    try:
        import requests
        resp = requests.get(
            'https://api.torbox.app/v1/api/torrents/checkcached',
            headers={'Authorization': 'Bearer ' + token},
            params={'hash': ','.join(hashes), 'format': 'list'},
            timeout=15,
        ).json()
        data = resp.get('data') or []
        if isinstance(data, list):
            # format=list → each item is either a plain hash string
            # or a dict with a 'hash' key, depending on TB API version
            cached = set()
            for item in data:
                if isinstance(item, str):
                    cached.add(item.lower())
                elif isinstance(item, dict):
                    h = item.get('hash') or item.get('Hash') or item.get('info_hash') or ''
                    if h:
                        cached.add(h.lower())
            return cached
        # format=object fallback → data is {hash: bool}
        return {h.lower() for h, v in data.items() if v}
    except Exception as e:
        log('debrid cache TB: {}'.format(e), level='warning')
        return set()


# Maps resolver_id → (check_function, credential_setting_key)
_DEBRID_CHECKERS = {
    'PremiumizeMeResolver': (_pm_check, 'PremiumizeMeResolver_token'),
    'AllDebridResolver':    (_ad_check, 'AllDebridResolver_token'),
    'RealDebridResolver':   (_rd_check, 'RealDebridResolver_token'),
    'TorBoxResolver':       (_tb_check, 'TorBoxResolver_apikey'),
}


def check_magnet_cache(raw_sources, active_debrids):
    """
    Hit enabled debrid cache-check APIs in parallel for all magnet sources.

    For each source with a magnet: URL, adds:
        source['cached_by'] = ['AD', 'PREM', ...]   (services that have it)
    Sources with no magnet URL or no recognised hash are not modified.

    Args:
        raw_sources    : list of raw scraper dicts (modified in-place)
        active_debrids : dict {resolver_id: short_label} from get_active_debrids()

    Returns raw_sources (same list, for chaining).
    """
    if not active_debrids:
        return raw_sources

    # Collect distinct hashes and map them back to source dicts
    hash_to_sources = {}
    for s in raw_sources:
        url = s.get('url', '')
        if url.lower().startswith('magnet:'):
            h = hash_from_magnet(url)
            if h:
                s['_hash'] = h
                hash_to_sources.setdefault(h, []).append(s)

    if not hash_to_sources:
        return raw_sources

    all_hashes = list(hash_to_sources.keys())

    # Read tokens from resolveurl (same source of truth as get_active_debrids)
    try:
        ru = xbmcaddon.Addon('script.module.resolveurl')
    except Exception:
        return raw_sources

    cached_sets  = {}   # short_label -> set of cached hashes
    results_lock = Lock()

    def _run(resolver_id, short, check_fn, cred_key):
        token = ru.getSetting(cred_key) or ''
        if not token:
            return
        found = check_fn(token, all_hashes)
        with results_lock:
            cached_sets[short] = found

    threads = []
    for resolver_id, short in active_debrids.items():
        entry = _DEBRID_CHECKERS.get(resolver_id)
        if entry:
            check_fn, cred_key = entry
            t = Thread(target=_run, args=(resolver_id, short, check_fn, cred_key))
            threads.append(t)

    for t in threads:
        t.start()
    for t in threads:
        t.join()

    # Annotate each magnet source
    for h, sources in hash_to_sources.items():
        cached_by = [short for short, cached_set in cached_sets.items()
                     if h in cached_set]
        for s in sources:
            s['cached_by'] = sorted(cached_by)  # deterministic order

    return raw_sources
