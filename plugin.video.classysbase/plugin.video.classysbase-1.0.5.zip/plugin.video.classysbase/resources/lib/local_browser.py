"""
local_browser.py — offline browsing of chains_export/ XML trees.

Navigates the hierarchy built by the TMDB pipeline without any HTTP calls.

URL params:
  mode=local
  root=   absolute path to a chains_export/<name>/ directory  (contains _index.xml)
  path=   virtual breadcrumb prefix, e.g. "4K Section / 4K Boxsets"  (absent = root)
  file=   relative path (forward-slash) to a leaf XML file  (absent = tree navigation)
"""
import os
import sys
import xml.etree.ElementTree as ET

import xbmcgui
import xbmcplugin

from resources.lib.infotag import VideoInfo
from resources.lib.log import log
from resources.lib.utils import build_url

_ADDON_URL = sys.argv[0]

# Default artwork — drop files in resources/artwork/ to activate
try:
    import xbmcaddon as _xa
    _ART = _xa.Addon('plugin.video.classysbase').getAddonInfo('path') + '/resources/artwork/'
except Exception:
    _ART = ''
_DEFAULT_POSTER = _ART + 'default_poster.jpg'
_DEFAULT_FANART = _ART + 'default_fanart.jpg'
_DEFAULT_FOLDER = _ART + 'default_folder.png'


def browse(handle, params):
    root_dir = params.get('root', '')
    path     = params.get('path', '')    # virtual breadcrumb
    xml_file = params.get('file', '')    # relative path to leaf XML (forward-slash)

    # Resolve Kodi special:// paths
    if root_dir.startswith('special://') or root_dir.startswith('plugin://'):
        try:
            import xbmcvfs
            root_dir = xbmcvfs.translatePath(root_dir)
        except Exception:
            pass

    if not root_dir or not os.path.isdir(root_dir):
        log('[classysbase] local_browser: root not found: %r' % root_dir, level='error')
        return

    if xml_file:
        _render_leaf(handle, root_dir, xml_file)
    else:
        _render_tree(handle, root_dir, path)


# ── index ──────────────────────────────────────────────────────────────────────

def _load_index(root_dir):
    idx_path = os.path.join(root_dir, '_index.xml')
    try:
        return ET.parse(idx_path).getroot()
    except Exception as e:
        log('[classysbase] local_browser: cannot parse _index.xml: %s' % e, level='error')
        return None


# ── tree navigation ────────────────────────────────────────────────────────────

def _render_tree(handle, root_dir, path):
    index = _load_index(root_dir)
    if index is None:
        return

    # All sections: (label, file_rel, item_count)
    all_sections = [
        (s.get('label', ''), s.get('file', ''), int(s.get('items', 0)))
        for s in index.findall('section')
    ]

    # Dir artwork lookup: path → {thumb, fanart}  (written by builder)
    dir_art = {
        d.get('label', ''): {'thumb': d.get('thumb', ''), 'fanart': d.get('fanart', '')}
        for d in index.findall('dir')
        if d.get('label')
    }

    # Restrict to sections under the current path
    if path:
        prefix = path + ' / '
        sub = [(lbl, f, n) for lbl, f, n in all_sections
               if lbl == path or lbl.startswith(prefix)]
    else:
        sub = all_sections

    # One directory entry per unique next-level segment
    seen       = set()
    list_items = []

    for label, xml_rel, _n in sub:
        remainder = label[len(path):].lstrip(' /') if path else label
        if not remainder:
            continue

        next_segment = remainder.split(' / ')[0]
        next_path    = (path + ' / ' + next_segment) if path else next_segment

        if next_path in seen:
            continue
        seen.add(next_path)

        exact       = [f for lbl, f, _ in sub if lbl == next_path]
        has_children = any(lbl.startswith(next_path + ' / ') for lbl, _, _ in sub)

        if exact and not has_children:
            # Leaf — direct link to item list
            count    = next((n for lbl, _, n in sub if lbl == next_path), 0)
            url      = build_url(_ADDON_URL, mode='local', root=root_dir, file=exact[0])
            lbl_text = '{} [COLOR dimgray]({})[/COLOR]'.format(next_segment, count)
        else:
            # Intermediate directory
            branch_count = sum(n for lbl, _, n in sub
                               if lbl == next_path or lbl.startswith(next_path + ' / '))
            url      = build_url(_ADDON_URL, mode='local', root=root_dir, path=next_path)
            lbl_text = '{} [COLOR dimgray]({})[/COLOR]'.format(next_segment, branch_count)

        li = xbmcgui.ListItem(lbl_text)
        art    = dir_art.get(next_path, {})
        thumb  = art.get('thumb') or art.get('fanart', '') or _DEFAULT_FOLDER
        fanart = art.get('fanart', '') or _DEFAULT_FANART
        li.setArt({
            'icon':   thumb,
            'thumb':  thumb,
            'fanart': fanart,
            'poster': thumb,
        })
        VideoInfo(li, title=next_segment)
        list_items.append((url, li, True))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'files')


# ── leaf renderer ──────────────────────────────────────────────────────────────

def _render_leaf(handle, root_dir, xml_rel):
    xml_path = os.path.join(root_dir, xml_rel.replace('/', os.sep))
    try:
        root = ET.parse(xml_path).getroot()
    except Exception as e:
        log('[classysbase] local_browser: cannot parse %s: %s' % (xml_path, e), level='error')
        return

    has_episodes = False
    list_items   = []

    for item in root.findall('item'):
        title       = (item.findtext('title')       or '').strip()
        if not title:
            continue
        year        = (item.findtext('year')        or '').strip()
        tmdb_id     = (item.findtext('tmdb')        or '').strip()
        season      = (item.findtext('season')      or '').strip()
        episode     = (item.findtext('episode')     or '').strip()
        description = (item.findtext('description') or '').strip()
        thumb       = (item.findtext('thumb')       or '').strip()
        fanart      = (item.findtext('fanart')      or '').strip()
        link        = (item.findtext('link')        or '').strip()
        # Strip any leftover <sublink> wrapper that leaked into the link text
        if '<sublink>' in link.lower():
            import re as _re
            _m = _re.search(r'<sublink>\s*(.+?)\s*</sublink>', link, _re.DOTALL | _re.IGNORECASE)
            link = _m.group(1).strip() if _m else ''
        media_type  = item.get('media_type', 'movie')

        # Resolve plays: (display_title, url) — <link> preferred; fall back to <sublink> elements.
        # Multiple <sublink name="..."> → one list item each, labelled "Title - name".
        # No link + tmdb ID → scrape mode (metadata-only items from TMDB expansion).
        if link:
            plays = [(title, link)]
        else:
            subs = [(s.get('name', '').strip(), (s.text or '').strip())
                    for s in item.findall('sublink')
                    if (s.text or '').strip()]
            if len(subs) == 1:
                plays = [(title, subs[0][1])]
            elif len(subs) > 1:
                plays = [('%s - %s' % (title, name) if name else title, url)
                         for name, url in subs]
            else:
                plays = []   # no link, no sublinks → scrape

        if season:
            has_episodes = True

        vi_kwargs = dict(title=title, plot=description, media_type=media_type)
        if year:    vi_kwargs['year']       = int(year)
        if tmdb_id: vi_kwargs['unique_ids'] = {'tmdb': tmdb_id}
        if season:  vi_kwargs['season']     = int(season)
        if episode: vi_kwargs['episode']    = int(episode)

        if plays:
            for play_title, play_link in plays:
                li = xbmcgui.ListItem(play_title)
                li.setArt({'thumb': thumb or _DEFAULT_POSTER, 'fanart': fanart or _DEFAULT_FANART, 'poster': thumb or _DEFAULT_POSTER})
                li.setProperty('IsPlayable', 'true')
                VideoInfo(li, **vi_kwargs)
                play_url = build_url(_ADDON_URL, mode='play', url=play_link,
                                     name=play_title, thumb=thumb, fanart=fanart)
                list_items.append((play_url, li, False))
        elif tmdb_id or title:
            # TMDB-expanded item with no stream URL — TV → season browser, movie → scraper
            li = xbmcgui.ListItem(title)
            li.setArt({'thumb': thumb or _DEFAULT_POSTER, 'fanart': fanart or _DEFAULT_FANART, 'poster': thumb or _DEFAULT_POSTER})
            VideoInfo(li, **vi_kwargs)
            if media_type == 'tv' and tmdb_id:
                target_url = build_url(_ADDON_URL, mode='browse_seasons', title=title, year=year,
                                       tmdb_id=tmdb_id, thumb=thumb, fanart=fanart)
                list_items.append((target_url, li, True))
            else:
                li.setProperty('IsPlayable', 'true')
                target_url = build_url(_ADDON_URL, mode='scrape', title=title, year=year,
                                       media_type=media_type, tmdb_id=tmdb_id,
                                       thumb=thumb, fanart=fanart)
                list_items.append((target_url, li, False))

    # ── Search entries ─────────────────────────────────────────────────────
    for srch in root.findall('search'):
        source    = (srch.get('source')     or 'tmdb').lower()
        label     = (srch.get('label')       or 'Search %s' % source.upper()).strip()
        mtype     = (srch.get('media_type')  or '').lower()
        thumb     = (srch.findtext('thumb')  or '').strip()
        fanart    = (srch.findtext('fanart') or '').strip()
        li = xbmcgui.ListItem('[B]%s[/B]' % label)
        li.setArt({'thumb': thumb or _DEFAULT_POSTER, 'fanart': fanart or _DEFAULT_FANART})
        _sk = dict(mode='xml_search', source=source)
        if mtype:
            _sk['media_type'] = mtype
        search_url = build_url(_ADDON_URL, **_sk)
        list_items.append((search_url, li, True))

    xbmcplugin.addDirectoryItems(handle, list_items, len(list_items))
    xbmcplugin.setContent(handle, 'episodes' if has_episodes else 'movies')
