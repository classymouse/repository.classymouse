"""
infotag.py — thin wrapper around Kodi's InfoTagVideo API (Kodi 20+).

Replaces the deprecated ListItem.setInfo('video', {...}) calls and the old
overlay integer constants (4/6) with the typed InfoTagVideo setters.
Kodi derives the watched/in-progress overlay automatically from playcount
and resume_point, so those no longer need to be set explicitly.

Usage:
    from resources.lib.infotag import VideoInfo
    VideoInfo(li, title='The Matrix', year=1999, media_type='movie', ...)
"""


class VideoInfo(object):
    """Apply video metadata to a ListItem via InfoTagVideo."""

    def __init__(self, listitem, **kwargs):
        tag = listitem.getVideoInfoTag()

        if 'title'        in kwargs: tag.setTitle(kwargs['title'] or '')
        if 'year'         in kwargs: tag.setYear(int(kwargs['year'] or 0))
        if 'plot'         in kwargs: tag.setPlot(kwargs['plot'] or '')
        if 'plot_outline' in kwargs: tag.setPlotOutline(kwargs['plot_outline'] or '')
        if 'tagline'      in kwargs: tag.setTagLine(kwargs['tagline'] or '')
        if 'rating'       in kwargs: tag.setRating(float(kwargs['rating'] or 0))
        if 'media_type'   in kwargs: tag.setMediaType(kwargs['media_type'])
        if 'genres'       in kwargs: tag.setGenres(list(kwargs['genres']))
        if 'unique_ids'   in kwargs: tag.setUniqueIDs(kwargs['unique_ids'])
        if 'duration'     in kwargs: tag.setDuration(int(kwargs['duration'] or 0))
        if 'episode'      in kwargs: tag.setEpisode(int(kwargs['episode'] or 0))
        if 'season'       in kwargs: tag.setSeason(int(kwargs['season'] or 0))
        if 'tvshowtitle'  in kwargs: tag.setTvShowTitle(kwargs['tvshowtitle'] or '')
        if 'first_aired'  in kwargs: tag.setFirstAired(kwargs['first_aired'] or '')
        if 'trailer'      in kwargs: tag.setTrailer(kwargs['trailer'] or '')

        # Watched state — replaces old overlay constants 4 (unwatched) / 6 (watched).
        # Kodi calculates the overlay icon automatically from playcount + resume_point.
        if 'playcount' in kwargs:
            tag.setPlaycount(int(kwargs['playcount'] or 0))
        if 'resume' in kwargs and 'duration' in kwargs:
            tag.setResumePoint(float(kwargs['resume'] or 0),
                               float(kwargs['duration'] or 0))
