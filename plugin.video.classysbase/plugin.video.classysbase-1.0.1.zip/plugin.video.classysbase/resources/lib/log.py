# -*- coding: utf-8 -*-
"""
log.py — Structured logger for Classy's Base
=============================================

Two output streams:

  classysbase.log  (same directory as kodi.log)
      ALL messages land here: INFO, WARNING, ERROR, and DEBUG.
      DEBUG messages only written when "Debug logging" is enabled in Settings.
      Use this file for day-to-day development — it contains ONLY our output.

  kodi.log  (Kodi's main log)
      Only WARNING and ERROR are forwarded here.
      This keeps kodi.log free of our INFO/DEBUG noise so the real Kodi
      errors remain easy to spot.

Usage
-----
    from resources.lib.log import log

    log('Fetched 42 items')                       # INFO
    log('Playlist empty',    level='warning')     # WARNING → both files
    log('Network failed',    level='error')       # ERROR   → both files
    log('Raw XML: ' + text,  level='debug')       # DEBUG   → classysbase.log only
                                                  #           (when debug=true)

Log file location
-----------------
    Windows : %APPDATA%\\Kodi\\classysbase.log
    Linux   : ~/.kodi/classysbase.log
    macOS   : ~/Library/Application Support/Kodi/classysbase.log

The file is appended to across plugin invocations (reuselanguageinvoker=false
means each call is a fresh process).  Clear it with:
    .\\tools\\restart_kodi_clean.ps1 -ClearCache
"""
import logging
import os

import xbmc
import xbmcaddon
import xbmcvfs

_ADDON_ID = 'plugin.video.classysbase'
_PREFIX   = "[Classy's Base]"
_LOGFILE  = 'classysbase.log'

# xbmc.log level map (WARNING + ERROR only — keeps kodi.log clean)
_XBMC_LEVELS = {
    'warning': xbmc.LOGWARNING,
    'error':   xbmc.LOGERROR,
}

# Python logging level map
_PY_LEVELS = {
    'debug':   logging.DEBUG,
    'info':    logging.INFO,
    'warning': logging.WARNING,
    'error':   logging.ERROR,
}

# Module-level logger — initialised once per Python process.
# With reuselanguageinvoker=false this is recreated on every plugin call,
# but FileHandler(mode='a') means we always append to the same file.
_logger = None


def _build_logger():
    """Create and configure the file-based Python logger."""
    global _logger

    try:
        # special://logpath/ resolves to the same folder as kodi.log
        log_dir = xbmcvfs.translatePath('special://logpath/')
        if not log_dir:
            log_dir = xbmcvfs.translatePath('special://home/')

        log_path = os.path.join(log_dir, _LOGFILE)

        logger = logging.getLogger(_ADDON_ID)
        logger.setLevel(logging.DEBUG)   # handler filters; we decide here
        logger.propagate = False         # don't bubble to root logger

        if not logger.handlers:          # guard against double-add on reimport
            handler = logging.FileHandler(log_path, mode='a', encoding='utf-8')
            handler.setFormatter(logging.Formatter(
                fmt='%(asctime)s  %(levelname)-8s  %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S',
            ))
            logger.addHandler(handler)

        _logger = logger

    except Exception as e:
        # Last resort: fall back to kodi.log only
        xbmc.log('%s logger init failed: %s' % (_PREFIX, e), xbmc.LOGERROR)
        _logger = None


def _debug_enabled():
    try:
        return xbmcaddon.Addon().getSetting('debug') == 'true'
    except Exception:
        return False


# ── Public API ─────────────────────────────────────────────────────────────────

def log(msg, level='info'):
    """
    Write a log message.

    Parameters
    ----------
    msg : str
        Message text.
    level : str
        'debug' | 'info' | 'warning' | 'error'  (default: 'info')

    Routing
    -------
    debug   → classysbase.log only  (only when debug=true in Settings)
    info    → classysbase.log only
    warning → classysbase.log  +  kodi.log
    error   → classysbase.log  +  kodi.log
    """
    lvl = (level or 'info').lower()

    # Drop debug messages when debug mode is off
    if lvl == 'debug' and not _debug_enabled():
        return

    # Ensure logger exists (once per process)
    if _logger is None:
        _build_logger()

    # Write to classysbase.log
    if _logger is not None:
        _logger.log(_PY_LEVELS.get(lvl, logging.INFO), str(msg))

    # Mirror WARNING / ERROR to kodi.log so they surface in Kodi's own viewer
    if lvl in _XBMC_LEVELS:
        xbmc.log('%s %s' % (_PREFIX, str(msg)), _XBMC_LEVELS[lvl])
