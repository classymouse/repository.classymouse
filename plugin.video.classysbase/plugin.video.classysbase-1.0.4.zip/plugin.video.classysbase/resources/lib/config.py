"""
config.py — Developer configuration loader
==========================================

Single source of truth for all developer-controlled settings (credentials,
branding, feature flags).  End-user preferences live in settings.xml.
Per-user secrets (OAuth tokens) live in keys.dat.

Loading priority
----------------
1.  Remote JSON at  config_url  (from local config.json)  — cached 24 h
2.  Local  resources/config.json                          — always present
3.  Hardcoded defaults below                              — last resort

Fork instructions
-----------------
Edit  resources/config.json  and set:
  • addon_id / addon_name   — your addon's identity
  • config_url              — URL of YOUR hosted config.json (can be empty
                              for fully offline / local-only deployments)
  • trakt_client_id/secret  — your Trakt app credentials
                              (or leave blank and put them in the remote file)
  • colors                  — hex AARRGGBB values for UI accents

That is literally the only file you need to touch.
"""

import json
import os
import time

import xbmcaddon
import xbmcvfs

from resources.lib.log import log

# ── hardcoded fallback defaults ────────────────────────────────────────────────
# These kick in only when BOTH the remote URL and the local config.json fail.
_DEFAULTS = {
    'addon_id':            'plugin.video.classysbase',
    'addon_name':          "Classy's Base",
    'config_url':          '',
    'trakt_client_id':     '',
    'trakt_client_secret': '',
    'colors': {
        'primary':   'FFED1C24',
        'highlight': 'FF00BFFF',
        'muted':     'FFAAAAAA',
    },
    'user_can_override_colors': True,
    'playlists': [],
}

# Remote config is cached for this many seconds
_REMOTE_TTL = 24 * 3600

# ── local config path ──────────────────────────────────────────────────────────

def _local_path():
    addon_path = xbmcvfs.translatePath(
        xbmcaddon.Addon().getAddonInfo('path')
    )
    return os.path.join(addon_path, 'resources', 'config.json')


def _cache_path():
    profile = xbmcvfs.translatePath(
        xbmcaddon.Addon().getAddonInfo('profile')
    )
    if not os.path.exists(profile):
        os.makedirs(profile)
    return os.path.join(profile, 'remote_config.json')


# ── loaders ────────────────────────────────────────────────────────────────────

def _load_local():
    """Read resources/config.json.  Returns {} on any error."""
    try:
        with open(_local_path(), encoding='utf-8') as fh:
            data = json.load(fh)
        # Strip comment keys
        return {k: v for k, v in data.items() if not k.startswith('_')}
    except Exception as e:
        log('config: local load failed: %s' % e, level='warning')
        return {}


def _load_remote(url):
    """
    Fetch the remote config JSON and cache it to profile/remote_config.json.

    Uses the cached copy if it is less than _REMOTE_TTL seconds old.
    Returns {} on any failure — the local file is the fallback.
    """
    cache = _cache_path()
    # Return cached version if still fresh
    if os.path.exists(cache):
        age = time.time() - os.path.getmtime(cache)
        if age < _REMOTE_TTL:
            try:
                with open(cache, encoding='utf-8') as fh:
                    return json.load(fh)
            except Exception:
                pass  # stale/corrupt — re-fetch

    try:
        import requests
        resp = requests.get(url, timeout=10)
        if resp.status_code == 200:
            data = resp.json()
            try:
                with open(cache, 'w', encoding='utf-8') as fh:
                    json.dump(data, fh)
            except Exception as e:
                log('config: cache write failed: %s' % e, level='warning')
            log('config: remote config refreshed from %s' % url)
            return data
        else:
            log('config: remote fetch HTTP %d — using local' % resp.status_code,
                level='warning')
    except Exception as e:
        log('config: remote fetch failed: %s — using local' % e, level='warning')
    return {}


# ── merged config (computed once per process) ──────────────────────────────────

_cache = None


def _load():
    global _cache
    if _cache is not None:
        return _cache

    # Start from hardcoded defaults
    merged = dict(_DEFAULTS)

    # Layer 1: local config.json
    local = _load_local()
    _deep_merge(merged, local)

    # Layer 2: remote config (only if a URL is configured)
    url = merged.get('config_url', '').strip()
    if url:
        remote = _load_remote(url)
        _deep_merge(merged, remote)

    _cache = merged
    return _cache


def _deep_merge(base, override):
    """Recursively merge *override* into *base* in-place."""
    for k, v in override.items():
        if isinstance(v, dict) and isinstance(base.get(k), dict):
            _deep_merge(base[k], v)
        elif v not in (None, ''):   # don't let empty strings wipe real values
            base[k] = v


# ── public API ─────────────────────────────────────────────────────────────────

def get(key, default=None):
    """
    Return a config value by key.

    Nested keys are supported with dot notation:
        config.get('colors.primary')   →  'FFED1C24'
    """
    cfg = _load()
    if '.' in key:
        parts = key.split('.', 1)
        sub = cfg.get(parts[0], {})
        if isinstance(sub, dict):
            return sub.get(parts[1], default)
        return default
    return cfg.get(key, default)


def reload():
    """
    Force a reload on the next get() call (e.g. after settings change).
    Also deletes the remote cache file so a fresh fetch happens.
    """
    global _cache
    _cache = None
    cache = _cache_path()
    try:
        if os.path.exists(cache):
            os.remove(cache)
    except Exception:
        pass
