"""
trakt_api.py — Trakt.tv API client
====================================

Credentials
-----------
  client_id / client_secret  →  Settings → Trakt  (settings.xml, hidden fields)
  access_token / refresh_token / expires_at  →  keys.py  (XOR-encrypted profile store)

Auth flow
---------
  OAuth2 Device Code — QR-code dialog, no browser popup needed.
  Call  run_auth()  in trakt_auth.py  to start the flow.

Watched state
-------------
  get_watched_movies()   →  set of TMDB movie ID strings
  get_watched_shows()    →  {show_tmdb_id_str: {season_str: set(episode_str)}}
  get_movie_playback()   →  {tmdb_id_str: progress_float (0–100)}
"""

import time

import requests

from resources.lib import config
from resources.lib.keys import get as key_get, set_key, delete as key_del
from resources.lib.log import log

_BASE = 'https://api.trakt.tv'


# ── credential helpers ─────────────────────────────────────────────────────────

def _client_id():
    return config.get('trakt_client_id', '')


def _client_secret():
    return config.get('trakt_client_secret', '')


def is_authenticated():
    """True if an access token is stored (does not validate the token)."""
    return bool(key_get('trakt_access_token'))


def disconnect():
    """Remove all stored Trakt tokens from the local encrypted store."""
    for k in ('trakt_access_token', 'trakt_refresh_token', 'trakt_expires_at'):
        key_del(k)


# ── token refresh ──────────────────────────────────────────────────────────────

def _do_refresh():
    """Exchange the stored refresh token for a new access + refresh token."""
    cid    = _client_id()
    secret = _client_secret()
    if not cid or not secret:
        return
    refresh_token = key_get('trakt_refresh_token')
    if not refresh_token:
        return
    try:
        resp = requests.post(
            _BASE + '/oauth/token',
            json={
                'refresh_token': refresh_token,
                'client_id':     cid,
                'client_secret': secret,
                'redirect_uri':  'urn:ietf:wg:oauth:2.0:oob',
                'grant_type':    'refresh_token',
            },
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            set_key('trakt_access_token',  data['access_token'])
            set_key('trakt_refresh_token', data['refresh_token'])
            expires_at = time.time() + int(data.get('expires_in', 7776000))
            set_key('trakt_expires_at', str(expires_at))
            log('Trakt token refreshed successfully')
        else:
            log('Trakt refresh HTTP %d' % resp.status_code, level='warning')
    except Exception as e:
        log('Trakt _do_refresh error: %s' % e, level='error')


# ── generic HTTP caller ────────────────────────────────────────────────────────

def _call(path, params=None, data=None, method='GET', with_auth=True):
    """
    Make one Trakt API call.

    Returns
    -------
    dict | list | bool | None
        Parsed JSON on success, True for 204 No Content,
        None on any error.
    """
    cid = _client_id()
    if not cid:
        log('Trakt: no Client ID — configure Settings → Trakt', level='warning')
        return None

    headers = {
        'Content-Type':    'application/json',
        'trakt-api-version': '2',
        'trakt-api-key':   cid,
    }
    if with_auth:
        token = key_get('trakt_access_token')
        if token:
            headers['Authorization'] = 'Bearer ' + token

    url = _BASE + '/' + path.lstrip('/')

    def _do(hdrs):
        try:
            if data is not None or method == 'POST':
                return requests.post(url, json=data, headers=hdrs, timeout=15)
            elif method == 'DELETE':
                return requests.delete(url, headers=hdrs, timeout=15)
            else:
                return requests.get(url, params=params or {}, headers=hdrs, timeout=15)
        except Exception as e:
            log('Trakt request error: %s' % e, level='error')
            return None

    resp = _do(headers)
    if resp is None:
        return None

    # One retry after 401 (token just expired)
    if resp.status_code == 401 and with_auth:
        _do_refresh()
        token = key_get('trakt_access_token')
        if token:
            headers['Authorization'] = 'Bearer ' + token
        resp = _do(headers)
        if resp is None:
            return None

    if resp.status_code == 204:
        return True

    if not resp.ok:
        log('Trakt %s %s → HTTP %d' % (method, path, resp.status_code), level='warning')
        return None

    try:
        return resp.json()
    except Exception as e:
        log('Trakt JSON decode error: %s' % e, level='error')
        return None


# ── device auth flow ───────────────────────────────────────────────────────────

def person_resolve(slug):
    """
    Resolve a Trakt person slug to their TMDB ID and headshot image URL.

    Calls GET /people/{slug}?extended=full.
    Returns (tmdb_id: int|None, headshot_url: str).
    Works with just the API key — no OAuth needed.
    """
    data = _call('/people/%s' % slug, params={'extended': 'full'})
    if not data:
        return None, ''
    tmdb_id   = (data.get('ids') or {}).get('tmdb')
    headshot  = ''
    headshots = (data.get('images') or {}).get('headshot') or []
    if headshots:
        first = headshots[0]
        if isinstance(first, dict):
            headshot = first.get('medium') or first.get('full') or ''
        elif isinstance(first, str):
            headshot = first
    return tmdb_id, headshot


def person_items(trakt_url):
    """
    Fetch a person's cast filmography from a Trakt people URL.

    trakt_url: full URL such as https://api.trakt.tv/people/Amy-Adams/movies
               or  https://api.trakt.tv/people/Amy-Adams/shows

    Returns a list of dicts with keys: title, year (str), tmdb_id (int|None),
    media_type ('movie' | 'tvshow').  Sorted by year descending.
    """
    path     = trakt_url.replace(_BASE, '')
    data     = _call(path) or {}
    is_shows = trakt_url.rstrip('/').endswith('/shows')
    items    = []
    for entry in (data.get('cast') or []):
        if is_shows:
            m = entry.get('show') or {}
            items.append({
                'title':      m.get('name') or m.get('title') or 'Unknown',
                'year':       str(m.get('year') or ''),
                'tmdb_id':    (m.get('ids') or {}).get('tmdb'),
                'media_type': 'tvshow',
            })
        else:
            m = entry.get('movie') or {}
            items.append({
                'title':      m.get('title') or 'Unknown',
                'year':       str(m.get('year') or ''),
                'tmdb_id':    (m.get('ids') or {}).get('tmdb'),
                'media_type': 'movie',
            })
    items.sort(key=lambda x: x['year'] or '', reverse=True)
    return items


def get_device_code():
    """
    Step 1 of device auth.  Returns the device code dict from Trakt, or None.

    The dict contains: device_code, user_code, verification_url,
    expires_in (seconds), interval (polling seconds).
    """
    cid = _client_id()
    if not cid:
        log('Trakt get_device_code: no Client ID', level='warning')
        return None
    try:
        resp = requests.post(
            _BASE + '/oauth/device/code',
            json={'client_id': cid},
            headers={
                'Content-Type':      'application/json',
                'trakt-api-version': '2',
                'trakt-api-key':     cid,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json()
        log('Trakt get_device_code HTTP %d' % resp.status_code, level='warning')
    except Exception as e:
        log('Trakt get_device_code error: %s' % e, level='error')
    return None


def poll_device_token(code_data):
    """
    Step 2 of device auth — call repeatedly until approved or expired.

    Returns
    -------
    dict   — token payload → auth succeeded, call save_token()
    False  — still pending (HTTP 400), keep polling
    None   — terminal failure (expired, denied, or network error)
    """
    cid    = _client_id()
    secret = _client_secret()
    if not cid or not secret:
        return None
    try:
        resp = requests.post(
            _BASE + '/oauth/device/token',
            json={
                'code':          code_data['device_code'],
                'client_id':     cid,
                'client_secret': secret,
            },
            headers={
                'Content-Type':      'application/json',
                'trakt-api-version': '2',
                'trakt-api-key':     cid,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            return resp.json()       # success
        if resp.status_code == 400:
            return False             # pending
        # 410 expired, 418 denied, 429 rate-limited → fatal
        log('Trakt poll_device_token HTTP %d' % resp.status_code, level='warning')
    except Exception as e:
        log('Trakt poll_device_token error: %s' % e, level='error')
    return None


def save_token(token_data):
    """Persist access + refresh tokens after a successful device auth."""
    set_key('trakt_access_token',  token_data['access_token'])
    set_key('trakt_refresh_token', token_data['refresh_token'])
    expires_at = time.time() + int(token_data.get('expires_in', 7776000))
    set_key('trakt_expires_at', str(expires_at))
    log('Trakt tokens saved (expires in %d days)' % (token_data.get('expires_in', 0) // 86400))


# ── watched state ──────────────────────────────────────────────────────────────

def get_watched_movies():
    """
    Return a set of TMDB movie ID strings for all movies the user has watched.
    Returns an empty set if not authenticated or on error.
    """
    if not is_authenticated():
        return set()
    data = _call('sync/watched/movies')
    if not data:
        return set()
    result = set()
    for item in data:
        tmdb = (item.get('movie') or {}).get('ids', {}).get('tmdb')
        if tmdb is not None:
            result.add(str(tmdb))
    return result


def get_watched_movie_titles():
    """
    Return a set of normalised lowercase movie titles the user has watched.
    Used for title-based matching in Jen-parsed lists that lack TMDB IDs.
    """
    if not is_authenticated():
        return set()
    data = _call('sync/watched/movies')
    if not data:
        return set()
    result = set()
    for item in data:
        title = (item.get('movie') or {}).get('title')
        if title:
            result.add(title.lower().strip())
    return result


def get_watched_shows():
    """
    Return a nested dict of watched episodes:
        {show_tmdb_id_str: {season_str: set(episode_str)}}
    Returns an empty dict if not authenticated or on error.
    """
    if not is_authenticated():
        return {}
    data = _call('sync/watched/shows')
    if not data:
        return {}
    result = {}
    for item in data:
        tmdb = (item.get('show') or {}).get('ids', {}).get('tmdb')
        if tmdb is None:
            continue
        sid = str(tmdb)
        result[sid] = {}
        for season in (item.get('seasons') or []):
            sn = str(season.get('number', ''))
            result[sid][sn] = {
                str(ep.get('number', ''))
                for ep in (season.get('episodes') or [])
            }
    return result


def get_movie_playback():
    """
    Return a dict of in-progress (paused) movies:
        {tmdb_id_str: progress_float}   (0.0–100.0 %)
    Returns an empty dict if not authenticated or on error.
    """
    if not is_authenticated():
        return {}
    data = _call('sync/playback/movies')
    if not data:
        return {}
    result = {}
    for item in data:
        tmdb = (item.get('movie') or {}).get('ids', {}).get('tmdb')
        if tmdb is not None:
            result[str(tmdb)] = float(item.get('progress', 0.0))
    return result


def get_show_playback():
    """
    Return in-progress episode data:
        {show_tmdb_id_str: {season_str: {episode_str: progress_float}}}
    progress is 0.0–100.0 %. Returns empty dict if not authenticated or on error.
    """
    if not is_authenticated():
        return {}
    data = _call('sync/playback/episodes')
    if not data:
        return {}
    result = {}
    for item in data:
        tmdb = (item.get('show') or {}).get('ids', {}).get('tmdb')
        ep   = item.get('episode') or {}
        sn   = str(ep.get('season', ''))
        en   = str(ep.get('number', ''))
        if tmdb is not None and sn and en:
            sid = str(tmdb)
            result.setdefault(sid, {}).setdefault(sn, {})[en] = float(item.get('progress', 0.0))
    return result


# ── write actions ──────────────────────────────────────────────────────────────

def mark_movie_watched(tmdb_id):
    """Add a movie to the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history', data={
        'movies': [{'ids': {'tmdb': int(tmdb_id)}}]
    }, method='POST')
    return result is not None


def mark_episode_watched(show_tmdb_id, season, episode):
    """Add one episode to the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history', data={
        'shows': [{
            'ids': {'tmdb': int(show_tmdb_id)},
            'seasons': [{
                'number': int(season),
                'episodes': [{'number': int(episode)}],
            }],
        }]
    }, method='POST')
    return result is not None


def mark_movie_unwatched(tmdb_id):
    """Remove a movie from the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history/remove', data={
        'movies': [{'ids': {'tmdb': int(tmdb_id)}}]
    }, method='POST')
    return result is not None


def mark_episode_unwatched(show_tmdb_id, season, episode):
    """Remove one episode from the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history/remove', data={
        'shows': [{
            'ids': {'tmdb': int(show_tmdb_id)},
            'seasons': [{
                'number': int(season),
                'episodes': [{'number': int(episode)}],
            }],
        }]
    }, method='POST')
    return result is not None


def mark_season_watched(show_tmdb_id, season):
    """Add all episodes of one season to the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history', data={
        'shows': [{
            'ids': {'tmdb': int(show_tmdb_id)},
            'seasons': [{'number': int(season)}],
        }]
    }, method='POST')
    return result is not None


def mark_season_unwatched(show_tmdb_id, season):
    """Remove all episodes of one season from the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history/remove', data={
        'shows': [{
            'ids': {'tmdb': int(show_tmdb_id)},
            'seasons': [{'number': int(season)}],
        }]
    }, method='POST')
    return result is not None


def mark_show_watched(show_tmdb_id):
    """Add all episodes of a show to the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history', data={
        'shows': [{'ids': {'tmdb': int(show_tmdb_id)}}]
    }, method='POST')
    return result is not None


def mark_show_unwatched(show_tmdb_id):
    """Remove all episodes of a show from the user's Trakt watched history."""
    if not is_authenticated():
        return False
    result = _call('sync/history/remove', data={
        'shows': [{'ids': {'tmdb': int(show_tmdb_id)}}]
    }, method='POST')
    return result is not None


# ── discovery endpoints ────────────────────────────────────────────────────────

def get_trending_movies(limit=20):
    """Return list of raw Trakt trending movie dicts."""
    return _call('movies/trending', params={'limit': limit}, with_auth=False) or []


def get_trending_shows(limit=20):
    """Return list of raw Trakt trending show dicts."""
    return _call('shows/trending', params={'limit': limit}, with_auth=False) or []


def get_popular_movies(limit=20):
    """Return list of raw Trakt popular movie dicts."""
    return _call('movies/popular', params={'limit': limit}, with_auth=False) or []


def get_popular_shows(limit=20):
    """Return list of raw Trakt popular show dicts."""
    return _call('shows/popular', params={'limit': limit}, with_auth=False) or []


def get_watchlist_movies():
    """Return the user's movie watchlist (requires auth)."""
    return _call('sync/watchlist/movies') or []


def get_watchlist_shows():
    """Return the user's TV show watchlist (requires auth)."""
    return _call('sync/watchlist/shows') or []


def search(query, media_type='movie', limit=20):
    """
    Search Trakt for movies or shows.

    Parameters
    ----------
    query : str
    media_type : str  — 'movie' or 'show'
    limit : int

    Returns list of raw Trakt search result dicts.
    """
    return _call(
        'search/%s' % media_type,
        params={'query': query, 'limit': limit},
        with_auth=False,
    ) or []
