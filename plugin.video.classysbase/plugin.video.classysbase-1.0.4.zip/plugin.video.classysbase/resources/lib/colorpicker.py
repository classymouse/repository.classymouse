"""
Custom colour-picker dialog for Kodi.

Usage
-----
    from resources.lib.colorpicker import pick_color
    argb = pick_color('FFED1C24')   # returns ARGB hex str, or None if cancelled

Layout: 8 columns × 8 rows = 64 swatches.
Row 0 is a greyscale ramp (black → white).
Rows 1-7 are hue families (red/orange/yellow/green/cyan/blue/magenta),
each ramp from very dark through pure hue to pastel.

The dialog is built entirely with xbmcgui controls and tiny PNGs generated
in pure Python (struct + zlib) — no image files need to be bundled.
"""
import os
import struct
import zlib
import colorsys

import xbmc
import xbmcgui
import xbmcvfs

# ── layout ─────────────────────────────────────────────────────────────────────
_COLS  = 8
_ROWS  = 8
_BOX_W = 24   # swatch width  (px at Kodi UI resolution)
_BOX_H = 30   # swatch height (px)
_GAP   = 3    # gap between swatches


# ── palette ────────────────────────────────────────────────────────────────────
def _generate_palette():
    """Return 64 ARGB-hex strings (no '0x' prefix)."""
    out = []

    # Row 0 – greyscale from black to white
    for i in range(_COLS):
        v = round(i * 255 / (_COLS - 1))
        out.append(f'FF{v:02X}{v:02X}{v:02X}')

    # Rows 1-7 – hue families, each column = brightness step
    for h_deg in (0, 30, 60, 120, 180, 240, 300):
        for i in range(_COLS):
            if i < 4:                           # dark  → full saturation
                val = 0.15 + i * 0.85 / 3
                r, g, b = colorsys.hsv_to_rgb(h_deg / 360, 1.0, val)
            else:                               # full  → pastel
                sat = max(1.0 - (i - 4) / 3.0, 0.0)
                r, g, b = colorsys.hsv_to_rgb(h_deg / 360, sat, 1.0)
            out.append(
                f'FF{round(r * 255):02X}{round(g * 255):02X}{round(b * 255):02X}'
            )

    return out   # 64 entries


# ── PNG helpers ────────────────────────────────────────────────────────────────
def _png_chunk(tag, data):
    payload = tag + data
    return (struct.pack('>I', len(data))
            + payload
            + struct.pack('>I', zlib.crc32(payload) & 0xFFFFFFFF))


def _make_swatch_png(r, g, b, focused=False):
    """
    Generate a 16×16 RGB PNG of a solid colour.
    When *focused* is True a 2-px white border is drawn inside the edges.
    """
    W = H = 16
    rows = []
    for row in range(H):
        line = b'\x00'   # PNG filter byte = None
        for col in range(W):
            on_border = focused and (
                row < 2 or row >= H - 2 or col < 2 or col >= W - 2
            )
            line += b'\xff\xff\xff' if on_border else bytes([r, g, b])
        rows.append(line)

    return (
        b'\x89PNG\r\n\x1a\n'
        + _png_chunk(b'IHDR', struct.pack('>IIBBBBB', W, H, 8, 2, 0, 0, 0))
        + _png_chunk(b'IDAT', zlib.compress(b''.join(rows), 6))
        + _png_chunk(b'IEND', b'')
    )


# ── dialog ─────────────────────────────────────────────────────────────────────
class _ColorPickerDialog(xbmcgui.WindowDialog):

    _BACK_IDS = frozenset((10, 92))   # ACTION_PREVIOUS_MENU, ACTION_NAV_BACK

    def __init__(self, palette, current):
        super().__init__()
        self.chosen = None

        self._palette = palette
        # Normalise: strip optional '0x' prefix, uppercase, pad to 8 chars
        cur = (current or 'FFED1C24').upper().replace('0X', '').lstrip('0')
        self._current = cur.zfill(8) if len(cur) <= 8 else 'FFED1C24'

        self._sw_map = {}   # control-id → ARGB string

        tmp_base = xbmcvfs.translatePath('special://temp/classysbase_picker/')
        self._tmp = tmp_base.rstrip('/\\')
        os.makedirs(self._tmp, exist_ok=True)

        self._png_n  = {}   # ARGB → path of normal  PNG
        self._png_f  = {}   # ARGB → path of focused PNG
        self._png_bg = ''   # white PNG used for background panel

        self._write_pngs()
        self._build_ui()

    # ── asset preparation ──────────────────────────────────────────────────────

    def _write_pngs(self):
        # Background: white square (colorDiffuse will tint it dark)
        wp = os.path.join(self._tmp, '_white.png')
        if not os.path.exists(wp):
            with open(wp, 'wb') as fh:
                fh.write(_make_swatch_png(255, 255, 255))
        self._png_bg = wp

        for argb in self._palette:
            r = int(argb[2:4], 16)
            g = int(argb[4:6], 16)
            b = int(argb[6:8], 16)
            np_ = os.path.join(self._tmp, f'{argb}_n.png')
            fp_ = os.path.join(self._tmp, f'{argb}_f.png')
            if not os.path.exists(np_):
                with open(np_, 'wb') as fh:
                    fh.write(_make_swatch_png(r, g, b, focused=False))
            if not os.path.exists(fp_):
                with open(fp_, 'wb') as fh:
                    fh.write(_make_swatch_png(r, g, b, focused=True))
            self._png_n[argb] = np_
            self._png_f[argb] = fp_

    # ── UI layout ──────────────────────────────────────────────────────────────

    def _build_ui(self):
        sw = int(xbmc.getInfoLabel('System.ScreenWidth')  or 0) or 1920
        sh = int(xbmc.getInfoLabel('System.ScreenHeight') or 0) or 1080

        grid_w = _COLS * _BOX_W + (_COLS - 1) * _GAP   # 219
        grid_h = _ROWS * _BOX_H + (_ROWS - 1) * _GAP   # 261

        dlg_w  = grid_w + 48          # + left/right padding
        dlg_h  = grid_h + 106         # title(40) + grid + footer(60) + pad(6)
        ox     = (sw - dlg_w) // 2
        oy     = (sh - dlg_h) // 2

        # ── background panel (white PNG × dark colorDiffuse = near-black 86% α)
        self.addControl(xbmcgui.ControlImage(
            ox, oy, dlg_w, dlg_h,
            self._png_bg,
            colorDiffuse='0xDD101010',
        ))

        # ── title
        self.addControl(xbmcgui.ControlLabel(
            ox + 12, oy + 8, dlg_w - 24, 28,
            'Pick a colour',
            textColor='0xFFFFFFFF',
            font='font13',
        ))

        # ── swatch grid
        grid_x = ox + (dlg_w - grid_w) // 2
        grid_y = oy + 44

        btns = []
        for idx, argb in enumerate(self._palette):
            row, col = divmod(idx, _COLS)
            bx = grid_x + col * (_BOX_W + _GAP)
            by = grid_y + row * (_BOX_H + _GAP)
            btn = xbmcgui.ControlButton(
                bx, by, _BOX_W, _BOX_H, '',
                focusTexture   = self._png_f[argb],
                noFocusTexture = self._png_n[argb],
            )
            self.addControl(btn)
            self._sw_map[btn.getId()] = argb
            btns.append(btn)

        # ── footer: OK / Cancel
        footer_y = grid_y + grid_h + 14
        btn_w    = 76
        btn_h    = 28

        self._ok = xbmcgui.ControlButton(
            ox + dlg_w - 2 * (btn_w + 8), footer_y, btn_w, btn_h, 'OK')
        self._cancel = xbmcgui.ControlButton(
            ox + dlg_w - (btn_w + 8),     footer_y, btn_w, btn_h, 'Cancel')
        self.addControl(self._ok)
        self.addControl(self._cancel)

        # ── footer: colour preview
        self._preview = xbmcgui.ControlLabel(
            ox + 10, footer_y + 4,
            dlg_w - 2 * (btn_w + 8) - 20, btn_h,
            self._preview_text(),
            textColor='0xFFFFFFFF',
            font='font12',
        )
        self.addControl(self._preview)

        # ── keyboard navigation
        # Swatch grid wraps left/right within rows; last row's ↓ → OK button
        for idx, btn in enumerate(btns):
            r, c = divmod(idx, _COLS)
            left  = btns[r * _COLS + (c - 1)]      if c > 0         else btns[r * _COLS + _COLS - 1]
            right = btns[r * _COLS + (c + 1)]      if c < _COLS - 1 else btns[r * _COLS]
            up    = btns[(r - 1) * _COLS + c]      if r > 0         else btns[(_ROWS - 1) * _COLS + c]
            down  = btns[(r + 1) * _COLS + c]      if r < _ROWS - 1 else self._ok
            btn.setNavigation(up, down, left, right)

        # OK: ↑ → bottom-left swatch, ↓ → top-left swatch, ←/→ ↔ Cancel
        self._ok.setNavigation(
            btns[(_ROWS - 1) * _COLS],
            btns[0],
            self._cancel, self._cancel,
        )
        self._cancel.setNavigation(
            btns[(_ROWS - 1) * _COLS + _COLS - 1],
            btns[_COLS - 1],
            self._ok, self._ok,
        )

        # ── initial focus: jump to the current colour if it's in the palette
        try:
            start = self._palette.index(self._current)
        except ValueError:
            start = 0
        self.setFocus(btns[start])

    # ── helpers ────────────────────────────────────────────────────────────────

    def _preview_text(self):
        return f'[COLOR {self._current}]██[/COLOR]  {self._current}'

    # ── events ─────────────────────────────────────────────────────────────────

    def onControl(self, control):
        cid = control.getId()
        if cid in self._sw_map:
            self._current = self._sw_map[cid]
            self._preview.setLabel(self._preview_text())
        elif control == self._ok:
            self.chosen = self._current
            self.close()
        elif control == self._cancel:
            self.close()

    def onAction(self, action):
        if action.getId() in self._BACK_IDS:
            self.close()


# ── public API ─────────────────────────────────────────────────────────────────
def pick_color(current='FFED1C24'):
    """
    Display the colour-picker dialog.
    Returns the selected ARGB hex string, or None if the user cancelled.
    """
    palette = _generate_palette()
    dlg     = _ColorPickerDialog(palette, current)
    dlg.doModal()
    result  = dlg.chosen
    del dlg
    return result
